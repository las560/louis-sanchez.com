/**
 * MainMenuViewController.h
**/

#import "AboutViewController.h"
#import "InstructionsViewController.h"
#import "BoardViewController.h"

@interface MainMenuViewController : UIViewController {
  UIView *selectBoardSize;
}

@property(nonatomic, retain) UIView *selectBoardSize;

- (IBAction)about:(UIButton *)button;
- (IBAction)viewInstructions:(UIButton *)button;
- (IBAction)playGame:(UIButton *)button;
- (IBAction)selectBoardSize:(UIButton *)sender;

@end