/**
 * BoardViewController.m
**/

#import "BoardViewController.h"

@implementation BoardViewController

@synthesize generatorBoardSize;
@synthesize boardSize;
@synthesize savedGameBoard;
@synthesize grid;
@synthesize board;
@synthesize cages2;
@synthesize revealBoardAlert;
@synthesize clearBoardAlert;

// Returns the BoardViewController initialized with the given board size.
- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize {
  [super init];
  boardSize = aBoardSize;
  savedGameBoard = nil;
  grid = [[NSMutableArray alloc] initWithObjects:nil];
  board = [[NSMutableArray alloc] initWithObjects:nil];
  cages2 = [[NSMutableArray alloc] initWithObjects:nil];
  [board addObject:[NSString stringWithFormat:@"%d", aBoardSize]];
  return self;
}

// Returns the BoardViewController initialized with the given saved game board.
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame {
  [super init];
  savedGameBoard = [[UIView alloc] initWithFrame:CGRectMake(0.0, 80.0, 320.0, 320.0)];
  boardSize = [[savedGame objectAtIndex:0] integerValue];
  grid = [[NSMutableArray alloc] initWithObjects:nil];
  board = [[NSMutableArray alloc] initWithObjects:nil];
  cages2 = [[NSMutableArray alloc] initWithObjects:nil];
  [board addObject:[NSString stringWithFormat:@"%d", boardSize]];
  
  [savedGameBoard setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  for (NSInteger index = 1; index < pow(boardSize, 2.0)+1; index++) {
    NSArray *boxData = [NSArray arrayWithArray:[[savedGame objectAtIndex:index] componentsSeparatedByString:@" "]];
    NSInteger number = [[boxData objectAtIndex:0] integerValue];
    NSInteger targetNumber = [[boxData objectAtIndex:1] integerValue];
    NSInteger operation = [[boxData objectAtIndex:2] integerValue];
    Borders borders = BordersMake([[boxData objectAtIndex:3] boolValue], [[boxData objectAtIndex:4] boolValue], [[boxData objectAtIndex:5] boolValue], [[boxData objectAtIndex:6] boolValue]);
    BoxView *box = [[BoxView alloc] initForBoardSize:boardSize withIndex:(index-1) andNumber:number andTargetNumber:targetNumber andOperation:operation andBorders:borders];
    [savedGameBoard addSubview:box];
    [board addObject:box];
    [grid addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
  }
  return self;
}

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  [[self view] setFrame:[[UIScreen mainScreen] applicationFrame]];
  [[self view] setBackgroundColor:[UIColor colorWithRed:150/255.0 green:120/255.0 blue:182/255.0 alpha:1.0]]; // lavender
  
  UIButton *mainMenu = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenu addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  [mainMenu setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenu setFrame:CGRectMake(20.0, 20.0, 120.0, 40.0)];
  [[self view] addSubview:mainMenu];
  
  UIButton *clearBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [clearBoard addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [clearBoard setTitle:@"Clear Board" forState:UIControlStateNormal];
  [clearBoard setFrame:CGRectMake(180.0, 20.0, 120.0, 40.0)];
  [[self view] addSubview:clearBoard];
  
  UIButton *revealBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [revealBoard addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [revealBoard setTitle:@"Reveal Board" forState:UIControlStateNormal];
  [revealBoard setFrame:CGRectMake(20.0, 420.0, 120.0, 40.0)];
  [[self view] addSubview:revealBoard];
  
  generatorBoardSize = (boardSize + 2);
	UIView *aBoard = [[UIView alloc] initWithFrame:CGRectMake(0.0, 80.0, 320.0, 320.0)];
  [[self view] addSubview:aBoard];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
  
  revealBoardAlert = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
  [revealBoardAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]]; // vermillion
  UILabel *confirm = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 10.0, 300.0, 300.0)];
  [confirm setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirm setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirm setLineBreakMode:UILineBreakModeWordWrap];
  [confirm setNumberOfLines:4];
  [confirm setTextAlignment:UITextAlignmentCenter];
  [confirm setTextColor:[UIColor blackColor]];
  [confirm setText:@"Are you sure you want to reveal the board?\n\nYou CANNOT undo this action!"];
  [revealBoardAlert addSubview:confirm];
  UIButton *yes = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yes addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [yes setTitle:@"YES" forState:UIControlStateNormal];
  [yes setFrame:CGRectMake(20.0, 240.0, 120.0, 40.0)];
  [revealBoardAlert addSubview:yes];
  UIButton *no = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [no addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [no setTitle:@"CANCEL" forState:UIControlStateNormal];
  [no setFrame:CGRectMake(180.0, 240.0, 120.0, 40.0)];
  [revealBoardAlert addSubview:no];
  
  clearBoardAlert = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
  [clearBoardAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]]; // vermillion
  UILabel *confirm2 = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 10.0, 300.0, 300.0)];
  [confirm2 setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirm2 setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirm2 setLineBreakMode:UILineBreakModeWordWrap];
  [confirm2 setNumberOfLines:4];
  [confirm2 setTextAlignment:UITextAlignmentCenter];
  [confirm2 setTextColor:[UIColor blackColor]];
  [confirm2 setText:@"Are you sure you want to clear the board?\n\nYou CANNOT undo this action!"];
  [clearBoardAlert addSubview:confirm2];
  UIButton *yes2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yes2 addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [yes2 setTitle:@"YES" forState:UIControlStateNormal];
  [yes2 setFrame:CGRectMake(20.0, 240.0, 120.0, 40.0)];
  [clearBoardAlert addSubview:yes2];
  UIButton *no2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [no2 addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [no2 setTitle:@"CANCEL" forState:UIControlStateNormal];
  [no2 setFrame:CGRectMake(180.0, 240.0, 120.0, 40.0)];
  [clearBoardAlert addSubview:no2];
  
  NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter addObserver:self selector:@selector(saveBoard:) name:UIApplicationWillTerminateNotification object:nil];
  
  Cage *cage = [Cage new];
  [cage initWithSize: generatorBoardSize];
  
  [cage create_Groupings_For_Cages_With_BoardSize: generatorBoardSize];
	[cage printCage];
  
  if (savedGameBoard != nil) {
    [[self view] addSubview:savedGameBoard];
  }
  else {
	grid = [self generateGridWithBoardSize:boardSize];
	  [grid retain];
    UIView *aBoard = [[UIView alloc] initWithFrame:CGRectMake(0.0, 80.0, 320.0, 320.0)];
    [aBoard setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
    
    BOOL north, south, east, west;
	int holder;
    for (NSInteger index = 0; index < pow((double)boardSize, 2.0); index++) {
      north = YES; south = YES; east = YES; west = YES;
      NSArray *arr;
      for (int i = 0; i < [[cage cages] count]; i++) {
        NSArray *arr2 = [[cage cages] objectAtIndex:i];
        for (int j = 0; j < [arr2 count]; j++) {
		  if ([[arr2 objectAtIndex:j] integerValue] == index) {
            arr = [NSArray arrayWithArray:arr2];
			holder = j;
          }
        }
      }
     // NSLog(@"HERE: %d, %d, %d, %@", index, [cage count], [arr count], arr);
      
      if ([arr containsObject:[NSNumber numberWithInteger:index-boardSize]]) {
        north = NO;
      }
      if ([arr containsObject:[NSNumber numberWithInteger:index+boardSize]]) {
        south = NO;
      }
      if ([arr containsObject:[NSNumber numberWithInteger:index+1]]) {
        east = NO;
      }
      if ([arr containsObject:[NSNumber numberWithInteger:index-1]]) {
        west = NO;
      }
	  BoxView *box;
	  NSInteger op;
	  NSInteger first;
	  NSInteger second;
	  NSInteger third;
	  NSInteger targetNum;
	  // test for first member in the cage
	  if ([[arr objectAtIndex: holder] isEqualTo: [arr objectAtIndex: 0]]) {
		  printf("%i is equal to %i\n", [[arr objectAtIndex: holder] integerValue], [[arr objectAtIndex: 0] integerValue]);
		// generate target number and operator	
		if ([arr count] == 1) {
			box = [[BoxView alloc] initForBoardSize:boardSize withIndex:index andNumber:NOTHING andTargetNumber:[[grid objectAtIndex: [[arr objectAtIndex: 0] integerValue]] integerValue] andOperation:NOTHING andBorders:BordersMake(north, south, east, west)];
			[box setController:self];
		}
		else if ([arr count] == 2) {	
		  // can generate addition/subtraction/multiplication/division
		  op = (arc4random() % 4) + 1;
		  first = [[grid objectAtIndex: [[arr objectAtIndex: 0] integerValue]] integerValue]; 
		  second = [[grid objectAtIndex: [[arr objectAtIndex: 1] integerValue]] integerValue];
	
		  printf("op = %i\n", op);
		  printf("first = %i\n", first);
		  printf("second = %i\n", second);
		  if (op == 1)
		    targetNum = first + second;		
		  else if (op == 2) {
		    if (first > second)
			  targetNum = first - second;
		    else
			  targetNum = second - first;
		  }
		  else if (op == 3) 
		    targetNum = first * second;		
		  else if (op == 4) {
			// test if division is possible.  sometimes it might not be
		    if (first % second == 0) {
			  targetNum = first / second;
			  printf("%i \% %i = %i\n", first, second, (first%second));
			  printf("%i / %i = %i\n", first, second, targetNum);
			}
		    else if (second % first == 0) {
			  targetNum = second / first;
			  printf("%i \% %i = %i\n", second, first, (second%first));
			  printf("%i / %i = %i\n", second, first, targetNum);
			}
			  // division is not possible: redo algorithm excluding division
			else {
			  op = (arc4random() % 3) + 1;
			  printf("second op = %i\n", op);
			  if (op == 1)
				targetNum = first + second;			
			  else if (op == 2) {
			    if (first > second)
				  targetNum = first - second;
			    else
				  targetNum = second - first;
		      }
		      else if (op == 3)
				targetNum = first * second;	
		    }
	      }
		  box = [[BoxView alloc] initForBoardSize:boardSize withIndex:index andNumber:NOTHING andTargetNumber:targetNum andOperation:op andBorders:BordersMake(north, south, east, west)];
		}
		else if ([arr count] == 3) {
		  // can only generate addition and multiplication
		  op = (arc4random() % 2);
		  if (op == 0)
			op = 1;			// additiion
		  else if (op == 1)	// multiplication
			op = 3;
		  if (op == 1) {
			first = [[grid objectAtIndex: [[arr objectAtIndex: 0] integerValue]] integerValue]; 
			second = [[grid objectAtIndex: [[arr objectAtIndex: 1] integerValue]] integerValue];
			third = [[grid objectAtIndex: [[arr objectAtIndex: 2] integerValue]] integerValue];
			targetNum = first + second + third;		
		  }
		  else if (op == 3) {
			first = [[grid objectAtIndex: [[arr objectAtIndex: 0] integerValue]] integerValue]; 
			second = [[grid objectAtIndex: [[arr objectAtIndex: 1] integerValue]] integerValue];
			third = [[grid objectAtIndex: [[arr objectAtIndex: 2] integerValue]] integerValue];
			targetNum = first * second * third;		
		  }
		  box = [[BoxView alloc] initForBoardSize:boardSize withIndex:index andNumber:NOTHING andTargetNumber:targetNum andOperation:op andBorders:BordersMake(north, south, east, west)];
	    }
      }
	  else {
		  box = [[BoxView alloc] initForBoardSize:boardSize withIndex:index andNumber:NOTHING andTargetNumber:NOTHING andOperation:0 andBorders:BordersMake(north, south, east, west)];
	  }
	  [aBoard addSubview:box];
		
      [board addObject:box];
	  
    }
    
    [[self view] addSubview:aBoard];
  }
}

// Brings up an alert window regarding revealing the board. It waits for the user's input.
- (IBAction)revealBoard:(UIButton *)button {
  if ([button currentTitle] == @"Reveal Board") {
    NSString *alertSoundPath = [[NSBundle mainBundle] pathForResource:@"error-beep_deep" ofType:@"wav"];
    SystemSoundID alertSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:alertSoundPath], &alertSound);
    AudioServicesPlaySystemSound(alertSound);
    [alertSoundPath release];
    
    [[self view] addSubview:revealBoardAlert];
  }
  else if ([button currentTitle] == @"YES") {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_01" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
	  NSLog(@"%@", grid);
	  for (NSInteger f = 1; f < boardSize*boardSize+1; f++) {
		  NSInteger num = [[grid objectAtIndex:f-1] integerValue];
		  NSLog(@"%d", num);
		  [[[board objectAtIndex:f] number] setText:[NSString stringWithFormat:@"%d", num]];
	  }
    [revealBoardAlert removeFromSuperview];
  }
  else {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_02" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    [revealBoardAlert removeFromSuperview];
  }
}

// Brings up an alert window regarding clearing the board. It waits for the user's input.
- (IBAction)clearBoard:(UIButton *)button {
  if ([button currentTitle] == @"Clear Board") {
    NSString *alertSoundPath = [[NSBundle mainBundle] pathForResource:@"error-beep_deep" ofType:@"wav"];
    SystemSoundID alertSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:alertSoundPath], &alertSound);
    AudioServicesPlaySystemSound(alertSound);
    [alertSoundPath release];
    
    [[self view] addSubview:clearBoardAlert];
  }
  else if ([button currentTitle] == @"YES") {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_01" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    for (NSInteger f = 1; f < boardSize*boardSize+1; f++) {
      [[[board objectAtIndex:f] number] setText:@""];
    }
    [clearBoardAlert removeFromSuperview];
  }
  else {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_02" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    [clearBoardAlert removeFromSuperview];
  }
}

// Removes the instructions view, thus returning to the main menu.
- (IBAction)returnToMainMenu:(UIButton *)button {
  NSString *closeWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"window-transition_close" ofType:@"wav"];
  SystemSoundID closeWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:closeWindowSoundPath], &closeWindowSound);
  AudioServicesPlaySystemSound(closeWindowSound);
  [closeWindowSoundPath release];
  
  [[self view] removeFromSuperview];
}

// Saves the current board.
- (void)saveBoard:(NSNotification *)notification {
  NSString *savedGamePath = [[NSBundle mainBundle] pathForResource:@"SavedGame" ofType:@"txt"];
  NSString *boardData = [board componentsJoinedByString:@"\n"];
  //NSLog(@"%@", cage);
  /*
  NSString *cagesData = [NSString stringWithFormat:@"%d\n", [cage count]];
  for (NSInteger index = 0; index < [cage count]; index++) {
    NSArray *arr = [NSArray arrayWithArray:[cage objectAtIndex:index]];
    NSString *aCage = [arr componentsJoinedByString:@" "];
    if (index != [cage count]-1) {
      [aCage stringByAppendingString:@"\n"];
    }
    [cagesData stringByAppendingString:aCage];
  }
   */
  //[boardData stringByAppendingString:cagesData];
  [boardData writeToFile:savedGamePath atomically:YES encoding:NSUTF8StringEncoding error:NULL];
  //*/
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

- (void)checkVictory {
	BOOL flag = YES;
	for (int i = 1; i < boardSize*boardSize+1; i++) {
		if ([[[[board objectAtIndex:i] number] text] integerValue] != [[grid objectAtIndex:i-1] integerValue]) {
			flag = NO;
		}
	}
	if (flag) {
		NSString *closeWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"applause_light" ofType:@"wav"];
		SystemSoundID closeWindowSound;
		AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:closeWindowSoundPath], &closeWindowSound);
		AudioServicesPlaySystemSound(closeWindowSound);
		[closeWindowSoundPath release];
	}
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
  [[NSNotificationCenter defaultCenter] removeObserver:self];
  [savedGameBoard release];
  [grid release];
  [board release];
  [cages2 release];
  [revealBoardAlert release];
  [clearBoardAlert release];
}

- (NSMutableArray *)generateGridWithBoardSize:(NSInteger)aBoardSize {
	NSMutableArray *digits = [NSMutableArray arrayWithObjects:nil];
	NSMutableArray *shifts = [NSMutableArray arrayWithObjects:nil];
	for (NSInteger digit = 1; digit <= aBoardSize; digit++) {
		[digits addObject:[NSNumber numberWithInteger:digit]];
		[shifts addObject:[NSNumber numberWithInteger:digit]];
	}
	[shifts removeLastObject];
	
	NSMutableArray *row = [NSMutableArray arrayWithObjects:nil];
	for (NSInteger index = 0; index < aBoardSize; index++) {
		NSInteger digit = arc4random()%[digits count];
		[row addObject:[digits objectAtIndex:digit]];
		[digits removeObjectAtIndex:digit];
	}
	
	NSMutableArray *grid1 = [NSMutableArray arrayWithObjects:nil];
	[grid1 addObjectsFromArray:row];
	for (NSInteger shift = 0; shift < aBoardSize-1; shift++) {
		NSMutableArray *shiftedRow = [NSMutableArray arrayWithArray:row];
		NSInteger times = arc4random()%[shifts count];
		[grid1 addObjectsFromArray:[self rotateArray:shiftedRow thisManyTimes:[[shifts objectAtIndex:times] integerValue]]];
		[shifts removeObjectAtIndex:times];
	}
	
	 NSLog(@"HERE: ");
	 for (NSInteger f = 0; f < [grid1 count]; f++) {
	 if (f % aBoardSize == 0) {
	 printf("\n");
	 }
	 printf("%d ", [[grid1 objectAtIndex:f] integerValue]);
	 }
	 printf("\n\n\n");
	 
	 NSLog(@"HERE: ");
	 for (NSInteger f = 0; f < [grid1 count]; f++) {
	 if (f % aBoardSize == 0) {
	 printf("\n");
	 }
	 printf("%d ", [[grid1 objectAtIndex:f] integerValue]);
	 }
	 printf("\n\n\n");
	
	return grid1;
}
- (NSMutableArray *)rotateArray:(NSMutableArray *)anArray thisManyTimes:(NSInteger)times {
	if (times < 0) {
		for (NSInteger count = 0; count < times; count++) {
			[anArray insertObject:[anArray lastObject] atIndex:0];
			[anArray removeLastObject];
		}
	}
	else if (times > 0) {
		for (NSInteger count = 0; count < times; count++) {
			[anArray addObject:[anArray objectAtIndex:0]];
			[anArray removeObjectAtIndex:0];
		}
	}
	return anArray;
}
@end
