/**
 * BoardViewController.h
**/

#import "BoxView.h"
#import "Cage.h"

@interface BoardViewController : UIViewController {
  NSInteger generatorBoardSize;
  NSInteger boardSize;
  
  UIView *savedGameBoard;
  UIView *revealBoardAlert;
  UIView *clearBoardAlert;
  
  NSMutableArray *grid;
  NSMutableArray *board;
  NSMutableArray *cages2;
}

@property(nonatomic) NSInteger generatorBoardSize;
@property(nonatomic) NSInteger boardSize;

@property(nonatomic, retain) UIView *savedGameBoard;
@property(nonatomic, retain) NSMutableArray *grid;
@property(nonatomic, retain) NSMutableArray *board;
@property(nonatomic, retain) NSMutableArray *cages2;
@property(nonatomic, retain) UIView *revealBoardAlert;
@property(nonatomic, retain) UIView *clearBoardAlert;

- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize;
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame;
- (IBAction)revealBoard:(UIButton *)button;
- (IBAction)clearBoard:(UIButton *)button;
- (IBAction)returnToMainMenu:(UIButton *)button;
- (void)saveBoard:(NSNotification *)notification;


- (NSMutableArray *)generateGridWithBoardSize:(NSInteger)aBoardSize;
- (NSMutableArray *)rotateArray:(NSMutableArray *)anArray thisManyTimes:(NSInteger)times;
- (void)checkVictory;



@end