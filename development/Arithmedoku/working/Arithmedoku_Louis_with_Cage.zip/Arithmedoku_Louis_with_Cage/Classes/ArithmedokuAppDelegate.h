/**
 * ArithmedokuAppDelegate.h
**/

#import "MainMenuViewController.h"

@interface ArithmedokuAppDelegate : NSObject <UIApplicationDelegate> {
  UIWindow *window;
  MainMenuViewController *mainMenu;
}

@property(nonatomic, retain) IBOutlet UIWindow *window;
@property(nonatomic, retain) IBOutlet MainMenuViewController *mainMenu;

@end