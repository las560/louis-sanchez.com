/**
 * BoardViewController.h
**/

#import "Generators.h"

@interface BoardViewController : UIViewController {
  Generators *generators;
  NSInteger boardSize;
  UIView *savedGameBoard;
  NSMutableArray *board;
  UIView *revealBoardAlert;
  UIView *clearBoardAlert;
}

@property(nonatomic, retain) Generators *generators;
@property(nonatomic) NSInteger boardSize;
@property(nonatomic, retain) UIView *savedGameBoard;
@property(nonatomic, retain) NSMutableArray *board;
@property(nonatomic, retain) UIView *revealBoardAlert;
@property(nonatomic, retain) UIView *clearBoardAlert;

- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize;
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame;
- (void)checkBoard;
- (IBAction)revealBoard:(UIButton *)button;
- (IBAction)clearBoard:(UIButton *)button;
- (IBAction)returnToMainMenu:(UIButton *)button;
- (void)saveBoard:(NSNotification *)notification;

@end