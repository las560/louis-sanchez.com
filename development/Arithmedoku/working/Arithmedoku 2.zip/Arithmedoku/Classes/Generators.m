/**
 * Generators.m
**/

#import "Generators.h"

@implementation Generators

//
- (NSMutableArray *)generateBoardWithBoardSize:(NSInteger)boardSize {
  NSMutableArray *grid = [self generateGridWithBoardSize:boardSize];
  NSMutableArray *cages = [self generateCagesWithGrid:grid withBoardSize:boardSize];
  //return [self generateBoardWithGrid:grid andCages:cages];
  return grid;
}

//
- (NSMutableArray *)generateGridWithBoardSize:(NSInteger)boardSize {
  NSMutableArray *digits = [NSMutableArray arrayWithObjects:nil];
  NSMutableArray *shifts = [NSMutableArray arrayWithObjects:nil];
  for (NSInteger digit = 1; digit <= boardSize; digit++) {
    [digits addObject:[NSNumber numberWithInteger:digit]];
    [shifts addObject:[NSNumber numberWithInteger:digit]];
  }
  [shifts removeLastObject];
  
  NSMutableArray *row = [NSMutableArray arrayWithObjects:nil];
  for (NSInteger index = 0; index < boardSize; index++) {
    NSInteger digit = arc4random()%[digits count];
    [row addObject:[digits objectAtIndex:digit]];
    [digits removeObjectAtIndex:digit];
  }
  
  NSMutableArray *grid = [NSMutableArray arrayWithObjects:nil];
  [grid addObjectsFromArray:row];
  for (NSInteger shift = 0; shift < boardSize-1; shift++) {
    NSMutableArray *shiftedRow = [NSMutableArray arrayWithArray:row];
    NSInteger times = arc4random()%[shifts count];
    [grid addObjectsFromArray:[self rotateArray:shiftedRow thisManyTimes:[[shifts objectAtIndex:times] integerValue]]];
    [shifts removeObjectAtIndex:times];
  }
  
  /*
  NSLog(@"HERE: ");
  for (NSInteger f = 0; f < [grid count]; f++) {
    if (f % boardSize == 0) {
      printf("\n");
    }
    printf("%d ", [[grid objectAtIndex:f] integerValue]);
  }
  printf("\n\n\n");

  NSArray *h = [NSArray arrayWithArray:grid];
  
  grid = [h sortedArrayUsingSelector:@selector(compare:)];
  
  NSLog(@"HERE: ");
  for (NSInteger f = 0; f < [grid count]; f++) {
    if (f % boardSize == 0) {
      printf("\n");
    }
    printf("%d ", [[grid objectAtIndex:f] integerValue]);
  }
  printf("\n\n\n");
  */
  
  return grid;
}

//
- (NSMutableArray *)generateCagesWithGrid:(NSMutableArray *)grid withBoardSize:(NSInteger)boardSize {
  NSInteger cageSizeMax;
  switch (boardSize) {
    case 4:
    case 5: cageSizeMax = 3; break;
    case 6:
    case 7: cageSizeMax = 4; break;
    case 8:
    case 9: cageSizeMax = 5; break;
    default: NSLog(@"Invalid boardSize, %d, found at: Generators.m- generateCagesWithGrid:withBoardSize:", boardSize);
      cageSizeMax = 0; break;
  }
  
  NSMutableArray *indexes = [NSMutableArray arrayWithObjects:nil];
  for (NSInteger index = 0; index < boardSize*boardSize; index++) {
    [indexes addObject:[NSNumber numberWithInteger:index]];
  }
  
  NSMutableArray *cages = [NSMutableArray arrayWithObjects:nil];
  for (NSInteger index = 0; index < [grid count]; index++) {
    NSInteger cageSize = arc4random()%cageSizeMax+1;
    /*
    NSInteger neighbors = 0;
    if ([indexes containsObject:[NSNumber numberWithInteger:index-boardSize]]) {
      neighbors++;
    }
    if ([indexes containsObject:[NSNumber numberWithInteger:index+boardSize]]) {
      neighbors++;
    }
    if ([indexes containsObject:[NSNumber numberWithInteger:index-1]]) {
      neighbors++;
    }
    if ([indexes containsObject:[NSNumber numberWithInteger:index+1]]) {
      neighbors++;
    }
    neighbors = neighbors > cageSizeMax ? cageSizeMax : neighbors;
    
    NSInteger cageSize = arc4random()%neighbors+1;
    */
    
  }
  
  return [NSArray arrayWithObjects:nil];
}

//
- (NSMutableArray *)generateBoardWithGrid:(NSMutableArray *)grid andCages:(NSMutableArray *)cages {
  /*
  for (NSInteger index = 1; index < boardSize*boardSize+1; index++) {
    NSArray *boxData = [NSArray arrayWithArray:[[savedGame objectAtIndex:index] componentsSeparatedByString:@" "]];
    NSInteger digit = [[boxData objectAtIndex:0] integerValue];
    NSInteger number = [[boxData objectAtIndex:1] integerValue];
    NSInteger targetNumber = [[boxData objectAtIndex:2] integerValue];
    NSInteger operation = [[boxData objectAtIndex:3] integerValue];
    Borders borders = BordersMake([[boxData objectAtIndex:4] boolValue], [[boxData objectAtIndex:5] boolValue], [[boxData objectAtIndex:6] boolValue], [[boxData objectAtIndex:7] boolValue]);
    BoxView *box = [[BoxView alloc] initForBoardSize:boardSize withIndex:(index-1) andDigit:digit andNumber:number andTargetNumber:targetNumber andOperation:operation andBorders:borders];
    [savedGameBoard addSubview:box];
    [board addObject:box];
  }
  */
  return [NSArray arrayWithObjects:nil];
}

//
- (NSMutableArray *)rotateArray:(NSMutableArray *)array thisManyTimes:(NSInteger)times {
  if (times < 0) {
    for (NSInteger count = 0; count < times; count++) {
      [array insertObject:[array lastObject] atIndex:0];
      [array removeLastObject];
    }
  }
  else if (times > 0) {
    for (NSInteger count = 0; count < times; count++) {
      [array addObject:[array objectAtIndex:0]];
      [array removeObjectAtIndex:0];
    }
  }
  return array;
}

@end