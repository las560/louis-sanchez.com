/**
 * AboutViewController.h
**/

#import <AudioToolbox/AudioToolbox.h>
#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController {
}

- (IBAction)returnToMainMenu:(UIButton *)button;

@end