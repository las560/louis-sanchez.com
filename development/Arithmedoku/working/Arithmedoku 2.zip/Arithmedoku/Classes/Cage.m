/**
 * Cage.m
**/

#import "Cage.h"

@implementation Cage

@synthesize cage;

- (Cage *)initWithMembers:(NSMutableArray *)members {
}

@end