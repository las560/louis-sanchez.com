/**
 * BoardViewController.h
**/

#import <math.h>
#import <stdlib.h>
#import <UIKit/UIKit.h>
#import "BoxView.h"

@interface BoardViewController : UIViewController {
  NSInteger boardSize;
  UIView *savedGameView;
  NSMutableArray *grid;
  NSMutableArray *cages;
  NSMutableArray *board2;
  UIView *revealAlert;
  UIView *clearAlert;
}

@property(nonatomic) NSInteger boardSize;
@property(nonatomic, retain) UIView *savedGameView;
@property(nonatomic, retain) NSMutableArray *grid;
@property(nonatomic, retain) NSMutableArray *cages;
@property(nonatomic, retain) NSMutableArray *board2;
@property(nonatomic, retain) UIView *revealAlert;
@property(nonatomic, retain) UIView *clearAlert;

- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize;
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame;
- (IBAction)returnToMainMenu:(id)sender;
- (IBAction)revealBoard:(id)sender;
- (IBAction)revealBoard2;
- (IBAction)revealBoard3;
- (IBAction)clearBoard:(id)sender;
- (IBAction)clearBoard2;
- (IBAction)clearBoard3;
- (void)saveBoard:(NSNotification *)notification;

@end