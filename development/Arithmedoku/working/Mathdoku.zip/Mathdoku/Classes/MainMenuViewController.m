/**
 * MainMenuViewController.m
**/

#import "MainMenuViewController.h"

@implementation MainMenuViewController

@synthesize chooseBoardSize;
@synthesize boardSize;

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  [[self view] setFrame:[[UIScreen mainScreen] applicationFrame]];
  [[self view] setBackgroundColor:[UIColor colorWithRed:0.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  
  [self setBoardSize:4];
  
  [self setChooseBoardSize:[[UIView alloc] initWithFrame:CGRectMake(15.0, 440.0, 290.0, 30.0)]];
  [chooseBoardSize setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [chooseBoardSize setHidden:YES];
  
  UILabel *chooseBoardSizeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 80.0, 30.0)];
  [chooseBoardSizeLabel setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [chooseBoardSizeLabel setFont:[UIFont boldSystemFontOfSize:14.0]];
  [chooseBoardSizeLabel setLineBreakMode:UILineBreakModeClip];
  [chooseBoardSizeLabel setTextColor:[UIColor blackColor]];
  [chooseBoardSizeLabel setText:@"Board size:"];
  [chooseBoardSize addSubview:chooseBoardSizeLabel];
  
  for (NSInteger size = 4; size < 10; size++) {
    UIButton *sizeButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [sizeButton setFrame:CGRectMake(85.0+((size-4)*35), 0.0, 30.0, 30.0)];
    [sizeButton setTitle:[NSString stringWithFormat:@"%d×%d", size, size] forState:UIControlStateNormal];
    [sizeButton addTarget:self action:@selector(playGame:) forControlEvents:UIControlEventTouchDown];
    [chooseBoardSize addSubview:sizeButton];
  }
  [[self view] addSubview:chooseBoardSize];
  
  UIImageView *logo = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, 320.0, 320.0)];
  [logo setImage:[UIImage imageNamed:@"logo-medium.png"]];
  [[self view] addSubview:logo];
  
  UILabel *authors = [[UILabel alloc] initWithFrame:CGRectMake(60.0, 330.0, 200.0, 60.0)];
  [authors setBackgroundColor:[UIColor colorWithWhite:0.0 alpha:0.0]];
  [authors setFont:[UIFont boldSystemFontOfSize:24.0]];
  [authors setNumberOfLines:2];
  [authors setTextAlignment:UITextAlignmentCenter];
  [authors setTextColor:[UIColor blackColor]];
  [authors setText:@"Salvatore DiLeo Louis Sanchez"];
  [[self view] addSubview:authors];
  
  UIButton *viewInstructions = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [viewInstructions setFrame:CGRectMake(40.0, 400.0, 100.0, 30.0)];
  [viewInstructions setTitle:@"Instructions" forState:UIControlStateNormal];
  [viewInstructions addTarget:self action:@selector(viewInstructions:) forControlEvents:UIControlEventTouchDown];
  [[self view] addSubview:viewInstructions];
  
  UIButton *playGame = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [playGame setFrame:CGRectMake(180.0, 400.0, 100.0, 30.0)];
  [playGame setTitle:@"Play Game" forState:UIControlStateNormal];
  [playGame addTarget:self action:@selector(chooseBoardSize:) forControlEvents:UIControlEventTouchDown];
  [[self view] addSubview:playGame];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
  NSString *savedGamePath = [[NSBundle mainBundle] pathForResource:@"SavedGame" ofType:@"txt"];
  NSString *savedGameData = [NSString stringWithContentsOfFile:savedGamePath];
  NSArray *savedGame = [NSArray arrayWithArray:[savedGameData componentsSeparatedByString:@"\n"]];
  for (NSInteger f = 0; f < [savedGame count]; f++) {
    NSLog(@"%@\n", [savedGame objectAtIndex:f]);
  }
  NSInteger size = [[savedGame objectAtIndex:0] integerValue];
  if (size != 0) {
    [self setBoardSize:size];
    BoardViewController *board = [[BoardViewController alloc] initWithSavedGame:savedGame];
    [[self view] addSubview:[board view]];
  }
}

// Returns a Boolean value indicating whether the view controller supports the specified orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations.
  return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [chooseBoardSize release];
  [super dealloc];
}

//
- (IBAction)viewInstructions:(id)sender {
  [chooseBoardSize setHidden:YES];
  InstructionsViewController *instructions = [[InstructionsViewController alloc] init];
  [[self view] addSubview:[instructions view]];
}

//
- (IBAction)chooseBoardSize:(id)sender {
  [chooseBoardSize setHidden:NO];
}

//
- (IBAction)playGame:(id)sender {
  [chooseBoardSize setHidden:YES];
  [self setBoardSize:[[[sender currentTitle] substringToIndex:1] integerValue]];
  BoardViewController *board = [[BoardViewController alloc] initWithBoardSize:boardSize];
  [[self view] addSubview:[board view]];
}

@end