/**
 * BoxView.h
**/

#import <math.h>
#import <stdlib.h>
#import <UIKit/UIKit.h>

#define NOTHING 0
#define ADDITION 1
#define SUBTRACTION 2
#define MULTIPLICATION 3
#define DIVISION 4

struct Borders {
  BOOL north;
  BOOL south;
  BOOL east;
  BOOL west;
};
typedef struct Borders Borders;

@interface BoxView : UIView {
  NSInteger boardSize;
  NSInteger index;
  NSInteger targetNumber;
  NSInteger operation;
  Borders borders;
  UILabel *number;
  CGPoint origin;
}

@property(nonatomic) NSInteger boardSize;
@property(nonatomic) NSInteger index;
@property(nonatomic) NSInteger targetNumber;
@property(nonatomic) NSInteger operation;
@property(nonatomic) Borders borders;
@property(nonatomic, retain) IBOutlet UILabel *number;
@property(nonatomic) CGPoint origin;

- (BoxView *)initForBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex andNumber:(NSInteger)aNumber andTargetNumber:(NSInteger)aTargetNumber andOperation:(NSInteger)anOperation andBorders:(Borders)someBorders;
- (CGRect)getBoxFrameForBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex;
- (UIButton *)getHurtBoxForBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex;
- (UILabel *)getLabelForNumber:(NSInteger)aNumber forBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex;
- (UILabel *)getLabelForTargetNumber:(NSInteger)aTargetNumber andOperation:(NSInteger)anOperation forBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex;
- (UIImage *)scaleImage:(UIImage *)image toSize:(CGSize)size;
- (IBAction)incrementNumber:(id)sender;
- (IBAction)drag:(UIButton *)sender;
- (IBAction)drop:(UIButton *)sender;
- (double)displacementFromOrigin:(CGPoint)point;
- (void)changeNumberTo:(NSInteger)aNumber;
Borders BordersMake(BOOL north, BOOL south, BOOL east, BOOL west);

@end