/**
 * BoardViewController.m
**/

#import "BoardViewController.h"

@implementation BoardViewController

@synthesize boardSize;
@synthesize savedGameView;
@synthesize grid;
@synthesize cages;
@synthesize board2;
@synthesize revealAlert;
@synthesize clearAlert;

//
- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize {
  [super init];
  [self setSavedGameView:nil];
  grid = [[NSMutableArray alloc] initWithObjects:nil];
  cages = [[NSMutableArray alloc] initWithObjects:nil];
  board2 = [[NSMutableArray alloc] initWithObjects:nil];
  [self setBoardSize:aBoardSize];
  [grid addObject:[NSString stringWithFormat:@"%d", aBoardSize]];
  return self;
}

//
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame {
  [super init];
  grid = [[NSMutableArray alloc] initWithObjects:nil];
  cages = [[NSMutableArray alloc] initWithObjects:nil];
  board2 = [[NSMutableArray alloc] initWithObjects:nil];
  boardSize = [[savedGame objectAtIndex:0] integerValue];
  [grid addObject:[NSString stringWithFormat:@"%d", boardSize]];
  savedGameView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 80.0, 320.0, 320.0)];
  [savedGameView setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  for (NSInteger index = 1; index < pow((double)boardSize, 2.0)+1; index++) {
    NSArray *boxData = [NSArray arrayWithArray:[[savedGame objectAtIndex:index] componentsSeparatedByString:@" "]];
    NSInteger number = [[boxData objectAtIndex:0] integerValue];
    NSInteger targetNumber = [[boxData objectAtIndex:1] integerValue];
    NSInteger operation = [[boxData objectAtIndex:2] integerValue];
    Borders borders = BordersMake([[boxData objectAtIndex:3] boolValue], [[boxData objectAtIndex:4] boolValue], [[boxData objectAtIndex:5] boolValue], [[boxData objectAtIndex:6] boolValue]);
    BoxView *box = [[BoxView alloc] initForBoardSize:boardSize withIndex:(index-1) andNumber:number andTargetNumber:targetNumber andOperation:operation andBorders:borders];
    [savedGameView addSubview:box];
    [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
  }
  return self;
}

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  [[self view] setFrame:[[UIScreen mainScreen] applicationFrame]];
  [[self view] setBackgroundColor:[UIColor colorWithRed:150/255.0 green:120/255.0 blue:182/255.0 alpha:1.0]]; // lavender
  
  UIButton *mainMenu = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenu addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  [mainMenu setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenu setFrame:CGRectMake(20.0, 20.0, 120.0, 40.0)];
  [[self view] addSubview:mainMenu];
  
  UIButton *clearBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [clearBoard addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [clearBoard setTitle:@"Clear Board" forState:UIControlStateNormal];
  [clearBoard setFrame:CGRectMake(180.0, 20.0, 120.0, 40.0)];
  [[self view] addSubview:clearBoard];
  
  UIButton *revealBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [revealBoard addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [revealBoard setTitle:@"Reveal Board" forState:UIControlStateNormal];
  [revealBoard setFrame:CGRectMake(20.0, 420.0, 120.0, 40.0)];
  [[self view] addSubview:revealBoard];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
  
  revealAlert = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
  [revealAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]];
  UILabel *confirm = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 10.0, 300.0, 300.0)];
  [confirm setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirm setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirm setLineBreakMode:UILineBreakModeWordWrap];
  [confirm setNumberOfLines:4];
  [confirm setTextAlignment:UITextAlignmentCenter];
  [confirm setTextColor:[UIColor blackColor]];
  [confirm setText:@"Are you sure you want to reveal the board?\nYou CANNOT undo this action!"];
  [revealAlert addSubview:confirm];
  UIButton *yes = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yes addTarget:self action:@selector(revealBoard2) forControlEvents:UIControlEventTouchDown];
  [yes setTitle:@"YES" forState:UIControlStateNormal];
  [yes setFrame:CGRectMake(20.0, 240.0, 120.0, 40.0)];
  [revealAlert addSubview:yes];
  UIButton *no = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [no addTarget:self action:@selector(revealBoard3) forControlEvents:UIControlEventTouchDown];
  [no setTitle:@"NO" forState:UIControlStateNormal];
  [no setFrame:CGRectMake(180.0, 240.0, 120.0, 40.0)];
  [revealAlert addSubview:no];
  
  clearAlert = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
  [clearAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]];
  UILabel *confirm2 = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 10.0, 300.0, 300.0)];
  [confirm2 setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirm2 setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirm2 setLineBreakMode:UILineBreakModeWordWrap];
  [confirm2 setNumberOfLines:4];
  [confirm2 setTextAlignment:UITextAlignmentCenter];
  [confirm2 setTextColor:[UIColor blackColor]];
  [confirm2 setText:@"Are you sure you want to clear the board?\nYou CANNOT undo this action!"];
  [clearAlert addSubview:confirm2];
  UIButton *yes2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yes2 addTarget:self action:@selector(clearBoard2) forControlEvents:UIControlEventTouchDown];
  [yes2 setTitle:@"YES" forState:UIControlStateNormal];
  [yes2 setFrame:CGRectMake(20.0, 240.0, 120.0, 40.0)];
  [clearAlert addSubview:yes2];
  UIButton *no2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [no2 addTarget:self action:@selector(clearBoard3) forControlEvents:UIControlEventTouchDown];
  [no2 setTitle:@"NO" forState:UIControlStateNormal];
  [no2 setFrame:CGRectMake(180.0, 240.0, 120.0, 40.0)];
  [clearAlert addSubview:no2];
  
  NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter addObserver:self selector:@selector(saveBoard:) name:UIApplicationWillTerminateNotification object:nil];
  
  if (savedGameView != nil) {
    [[self view] addSubview:savedGameView];
  }
  else {
    UIView *board = [[UIView alloc] initWithFrame:CGRectMake(0.0, 80.0, 320.0, 320.0)];
    [board setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  
    /*
    for (NSInteger index = 0; index < pow((double)boardSize, 2.0); index++) {
      BoxView *box = [[BoxView alloc] initForBoardSize:boardSize withIndex:index andNumber:0 andTargetNumber:(arc4random()%1001) andOperation:(arc4random()%5) andBorders:BordersMake(arc4random()%2, arc4random()%2, arc4random()%2, arc4random()%2)];
      [board addSubview:box];
      [grid addObject:box];
      [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize]];
    }
    //*/
    BoxView *box = [[BoxView alloc] initForBoardSize:9 withIndex:0 andNumber:0 andTargetNumber:13 andOperation:ADDITION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:1 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:2 andNumber:0 andTargetNumber:20 andOperation:MULTIPLICATION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:3 andNumber:0 andTargetNumber:21 andOperation:MULTIPLICATION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:4 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:5 andNumber:0 andTargetNumber:4 andOperation:DIVISION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:6 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:7 andNumber:0 andTargetNumber:54 andOperation:MULTIPLICATION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:8 andNumber:0 andTargetNumber:8 andOperation:SUBTRACTION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:9 andNumber:0 andTargetNumber:17 andOperation:ADDITION andBorders:BordersMake(YES, NO, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:10 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:11 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:12 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:13 andNumber:0 andTargetNumber:19 andOperation:ADDITION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:14 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, NO, NO, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:15 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:16 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:17 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:18 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:19 andNumber:0 andTargetNumber:21 andOperation:MULTIPLICATION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:20 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:21 andNumber:0 andTargetNumber:16 andOperation:MULTIPLICATION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:22 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, NO, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:23 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:24 andNumber:0 andTargetNumber:17 andOperation:ADDITION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:25 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:26 andNumber:0 andTargetNumber:14 andOperation:ADDITION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:27 andNumber:0 andTargetNumber:63 andOperation:MULTIPLICATION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:28 andNumber:0 andTargetNumber:4 andOperation:DIVISION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:29 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:30 andNumber:0 andTargetNumber:54 andOperation:MULTIPLICATION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:31 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:32 andNumber:0 andTargetNumber:5 andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:33 andNumber:0 andTargetNumber:1120 andOperation:MULTIPLICATION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:34 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:35 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:36 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:37 andNumber:0 andTargetNumber:6 andOperation:MULTIPLICATION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:38 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:39 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:40 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:41 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, NO, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:42 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:43 andNumber:0 andTargetNumber:5 andOperation:ADDITION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:44 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:45 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:46 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:47 andNumber:0 andTargetNumber:5 andOperation:SUBTRACTION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:48 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:49 andNumber:0 andTargetNumber:2 andOperation:SUBTRACTION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:50 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:51 andNumber:0 andTargetNumber:2 andOperation:DIVISION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:52 andNumber:0 andTargetNumber:2 andOperation:SUBTRACTION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:53 andNumber:0 andTargetNumber:2 andOperation:SUBTRACTION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:54 andNumber:0 andTargetNumber:1 andOperation:SUBTRACTION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:55 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:56 andNumber:0 andTargetNumber:144 andOperation:MULTIPLICATION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:57 andNumber:0 andTargetNumber:90 andOperation:MULTIPLICATION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:58 andNumber:0 andTargetNumber:20 andOperation:ADDITION andBorders:BordersMake(YES, NO, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:59 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, NO, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:60 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:61 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:62 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:63 andNumber:0 andTargetNumber:1 andOperation:SUBTRACTION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:64 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:65 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:66 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:67 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:68 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:69 andNumber:0 andTargetNumber:6 andOperation:MULTIPLICATION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:70 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:71 andNumber:0 andTargetNumber:1 andOperation:SUBTRACTION andBorders:BordersMake(YES, NO, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:72 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:73 andNumber:0 andTargetNumber:4 andOperation:SUBTRACTION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:74 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:75 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:76 andNumber:0 andTargetNumber:3 andOperation:DIVISION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:77 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:78 andNumber:0 andTargetNumber:2 andOperation:DIVISION andBorders:BordersMake(YES, YES, NO, YES)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:79 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(YES, YES, YES, NO)];
    [board addSubview:box];
      [grid addObject:box];
    [board2 addObject:[NSNumber numberWithInteger:arc4random()%boardSize+1]];
    box = [[BoxView alloc] initForBoardSize:9 withIndex:80 andNumber:0 andTargetNumber:NOTHING andOperation:NOTHING andBorders:BordersMake(NO, YES, YES, YES)];
    [board addSubview:box];
    [[self view] addSubview:board];
  }
}

// Returns a Boolean value indicating whether the view controller supports the specified orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations.
  return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
  [[NSNotificationCenter defaultCenter] removeObserver:self];
  [savedGameView release];
  [grid release];
  [cages release];
  [board2 release];
}

//
- (IBAction)returnToMainMenu:(id)sender {
  [[self view] removeFromSuperview];
}

//
- (IBAction)revealBoard:(id)sender {
  [[self view] addSubview:revealAlert];
}

//
- (IBAction)revealBoard2 {
  [revealAlert removeFromSuperview];
  for (NSInteger f = 1; f < [grid count]; f++) {
    [[[grid objectAtIndex:f] number] setText:[NSString stringWithFormat:@"%d", [[board2 objectAtIndex:f-1] integerValue]]];
  }
}

//
- (IBAction)revealBoard3 {
  [revealAlert removeFromSuperview];
}

//
- (IBAction)clearBoard:(id)sender {
  [[self view] addSubview:clearAlert];
}

//
- (IBAction)clearBoard2 {
  [clearAlert removeFromSuperview];
  for (NSInteger f = 1; f < [grid count]; f++) {
    [[[grid objectAtIndex:f] number] setText:@""];
  }
}

//
- (IBAction)clearBoard3 {
  [clearAlert removeFromSuperview];
}

//
- (void)saveBoard:(NSNotification *)notification {
  NSString *savedGamePath = [[NSBundle mainBundle] pathForResource:@"SavedGame" ofType:@"txt"];
  //NSString *savedGameData = @"4\n4 8 3 1 1 0 1\n2 0 0 1 1 1 0\n3 4 1 1 1 0 1\n1 0 0 1 1 1 0\n3 10 1 1 1 0 1\n4 0 0 1 0 1 0\n1 4 3 1 0 0 1\n2 0 0 1 1 1 0\n1 1 0 1 1 1 1\n3 0 0 0 1 1 1\n2 0 0 0 1 1 1\n4 11 1 1 0 1 1\n2 3 1 1 1 0 1\n1 0 0 1 1 1 0\n4 0 0 1 1 0 1\n3 0 0 0 1 1 0\n8\n0 1\n2 3\n4 5\n6 7\n8 9\n10 11\n12 13\n14 15";
  NSString *savedGameData = [grid componentsJoinedByString:@"\n"];
  NSLog(@"%@", savedGameData);
  [savedGameData writeToFile:savedGamePath atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}

@end
