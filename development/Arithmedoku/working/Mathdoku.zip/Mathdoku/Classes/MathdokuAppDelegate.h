/**
 * MathdokuAppDelegate.h
**/

#import <UIKit/UIKit.h>
#import "MainMenuViewController.h"

@interface MathdokuAppDelegate : NSObject <UIApplicationDelegate> {
  UIWindow *window;
  MainMenuViewController *mainMenu;
}

@property(nonatomic, retain) IBOutlet UIWindow *window;
@property(nonatomic, retain) IBOutlet MainMenuViewController *mainMenu;

@end