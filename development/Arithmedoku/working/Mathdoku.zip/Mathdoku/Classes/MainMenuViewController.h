/**
 * MainMenuViewController.h
**/

#import <UIKit/UIKit.h>
#import "InstructionsViewController.h"
#import "BoardViewController.h"

@interface MainMenuViewController : UIViewController {
  UIView *chooseBoardSize;
  NSInteger boardSize;
}

@property(nonatomic, retain) UIView *chooseBoardSize;
@property(nonatomic) NSInteger boardSize;

- (IBAction)viewInstructions:(id)sender;
- (IBAction)chooseBoardSize:(id)sender;
- (IBAction)playGame:(id)sender;

@end