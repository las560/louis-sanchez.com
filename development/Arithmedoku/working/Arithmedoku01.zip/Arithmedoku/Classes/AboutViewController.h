/**
 * AboutViewController.h
**/

#import <AudioToolbox/AudioToolbox.h>

@interface AboutViewController : UIViewController {
}

- (IBAction)returnToMainMenu:(UIButton *)button;

@end