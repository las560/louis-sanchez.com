/**
 * ArithmedokuAppDelegate.m
**/

#import "ArithmedokuAppDelegate.h"

@implementation ArithmedokuAppDelegate

@synthesize window;
@synthesize mainMenu;

// Tells the delegate when the application has finished launching.
- (void)applicationDidFinishLaunching:(UIApplication *)application {
  [[UIApplication sharedApplication] setStatusBarHidden:YES animated:NO];
  mainMenu = [[MainMenuViewController alloc] init];
  [window addSubview:[mainMenu view]];
  [window makeKeyAndVisible];
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [window release];
  [mainMenu release];
  [super dealloc];
}

@end