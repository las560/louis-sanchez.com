/**
 * BoardViewController.h
**/

#import "BoxView.h"

@interface BoardViewController : UIViewController {
  NSInteger generatorBoardSize;
  NSInteger boardSize;
  UIView *savedGameBoard;
  NSMutableArray *grid;
  NSMutableArray *board;
  NSMutableArray *cages2;
  UIView *revealBoardAlert;
  UIView *clearBoardAlert;
  
  NSMutableArray *cage;
	NSMutableArray *allBoxes;
	NSMutableArray *array;
}

@property(nonatomic) NSInteger generatorBoardSize;
@property(nonatomic) NSInteger boardSize;
@property(nonatomic, retain) UIView *savedGameBoard;
@property(nonatomic, retain) NSMutableArray *grid;
@property(nonatomic, retain) NSMutableArray *board;
@property(nonatomic, retain) NSMutableArray *cages2;
@property(nonatomic, retain) UIView *revealBoardAlert;
@property(nonatomic, retain) UIView *clearBoardAlert;

@property (nonatomic, retain) NSMutableArray *cage;
@property (nonatomic, retain) NSMutableArray *allBoxes;
@property (nonatomic, retain) NSMutableArray *array;

- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize;
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame;
- (IBAction)revealBoard:(UIButton *)button;
- (IBAction)clearBoard:(UIButton *)button;
- (IBAction)returnToMainMenu:(UIButton *)button;
- (void)saveBoard:(NSNotification *)notification;

int convertIndexes(int index, int size);
void printNumbers(int a[], int size);
- (void) printCage;
- (void) printArray: (NSInteger) size;
- (NSMutableArray*) create_Groupings_for_Cage: (NSMutableArray*) cages with: (NSMutableArray*) boxes withBoardSize: (int) size;
- (NSMutableArray *)generateGridWithBoardSize:(NSInteger)aBoardSize;
- (NSMutableArray *)rotateArray:(NSMutableArray *)anArray thisManyTimes:(NSInteger)times;
- (void)checkVictory;



@end