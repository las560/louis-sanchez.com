//
//  InstructionsViewController.h
//  iPhone_Final_Project
//
//  Created by scholar on 4/16/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface InstructionsViewController : UIViewController {

}

- (IBAction) returnToMenu: (id) sender;

@end
