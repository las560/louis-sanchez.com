//
//  BoardViewController.m
//  iPhone_Final_Project
//
//  Created by scholar on 4/16/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BoardViewController.h"


@implementation BoardViewController
@synthesize box1;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	box1 = [BoxView boxViewWithTargetNumber: 4 andOperation: @"+" andBorderNorth: YES andBorderSouth: NO andBorderEast: YES andBorderWest: YES];
	[self.view addSubview: box1];
	[self randomizeBoard];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (IBAction) returnToMenu: (id) sender {
	[UIView beginAnimations:Nil context:Nil];
	[UIView setAnimationDuration:1.0];
	[UIView setAnimationTransition:UIViewAnimationTransitionCurlDown forView:self.view cache:YES];
	[self.view removeFromSuperview];
	[UIView commitAnimations];
}

- (void) randomizeBoard {
	// Set all elements in array to 0 (zero)
	for(int i = 0 ; i < 4 ; i++) {
		for(int j = 0 ; j < 4 ; j++) {
			array[i][j] = 0;
		}
	}	
	// Begin randomizing
	BOOL used = YES;
	int flag = 0;
	for( int i = 0 ; i < 4 ; i++) {
		for( int j = 0 ; j < 4 ; j++) {
			used = YES;
			while (used == YES) {
				// get random number that is non-zero
				int num = arc4random() % 5;
				while (num == 0)
					num = arc4random() % 5;
				// first check the entire row
				for (int column = 0 ; column < 4 ; column++) {
					// check to skip over selected cell
					if (column == j)
						continue;
					else if (array[i][column] == num) {
						flag = 0;
						break;
					}
					else
						flag = 1;
				}
				// check to see if loop was broken
				if (flag == 0)
					continue;
				// now check entire column
				for (int row = 0 ; row < 4; row++) {
					if (row == i)
						continue;
					else if (array[row][j] == num) {
						flag = 0;
						break;
					}
					else
						flag = 2;
				}
				if (flag == 0)
					continue;
				else {
					used = NO;
					array[i][j] = num;
					NSLog(@"%i ", array[i][j]);
				}
			}
		}
		NSLog(@"");
	}	
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [super dealloc];
}

@end
