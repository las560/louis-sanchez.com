//
//  iPhone_Final_ProjectAppDelegate.h
//  iPhone_Final_Project
//
//  Created by scholar on 4/16/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainMenuViewController;

@interface iPhone_Final_ProjectAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MainMenuViewController *menu;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MainMenuViewController *menu;

@end

