/**
 * BoxView.h
**/

@interface BoxView : UIView {
	IBOutlet UILabel *number;
	UILabel *targetNumber;
	UILabel *operation;
	UIImageView *borderNorth;
	UIImageView *borderSouth;
	UIImageView *borderEast;
	UIImageView *borderWest;
	NSInteger visitCount;
}

@property(nonatomic, retain) IBOutlet UILabel *number;
@property(nonatomic, retain) UILabel *targetNumber;
@property(nonatomic, retain) UILabel *operation;
@property(nonatomic, retain) UIImageView *borderNorth;
@property(nonatomic, retain) UIImageView *borderSouth;
@property(nonatomic, retain) UIImageView *borderEast;
@property(nonatomic, retain) UIImageView *borderWest;
@property(nonatomic) NSInteger visitCount;

+ (BoxView *)boxViewWithTargetNumber:(NSInteger)targetNumber andOperation:(NSString *)operation andBorderNorth:(BOOL)borderNorth andBorderSouth:(BOOL)borderSouth andBorderEast:(BOOL)borderEast andBorderWest:(BOOL)borderWest;

@end
