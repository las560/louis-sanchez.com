/**
 * BoxView.h
**/

#import "BoxView.h"

@implementation BoxView

@synthesize number;
@synthesize targetNumber;
@synthesize operation;
@synthesize borderNorth;
@synthesize borderSouth;
@synthesize borderEast;
@synthesize borderWest;
@synthesize visitCount;

+ (BoxView *)boxViewWithTargetNumber:(NSString *)targetNumber andOperation:(NSString *)operation andBorderNorth:(BOOL)borderNorth andBorderSouth:(BOOL)borderSouth andBorderEast:(BOOL)borderEast andBorderWest:(BOOL)borderWest {
  // Each box for a 4x4 board is 60x60 pixels. It must be generalized for nxn board sizes.

	CGRect rect1 = CGRectMake(50, 50, 60, 60);
	BoxView *boxView = [[BoxView alloc] initWithFrame: rect1];
	boxView.backgroundColor = [UIColor grayColor];

	NSLog(@"%@", [boxView center]);
	
	[boxView setNumber: [[UILabel alloc] initWithFrame: CGRectMake(0, 0, 25, 25)]];
	[boxView addSubview: [boxView number]];
//	[[boxView number] setCenter:(CGPoint){CGRectGetMidX(rect1), CGRectGetMidY(rect1)}];
	[[boxView number] setCenter: [boxView center]];
	[boxView number].textColor=[UIColor whiteColor];
	[boxView number].backgroundColor=[UIColor whiteColor];
	[boxView number].hidden=NO;

/*	[[boxView targetNumber] setText:targetNumber];
	[[boxView targetNumber] setTextAlignment:UITextAlignmentRight];
	[[boxView targetNumber] initWithFrame: CGRectMake(50, 50, 25, 25)]; // Guesstimate-- it must be in top-left box corner	
	
	[[boxView operation] setText:operation];
	[[boxView operation] setCenter:(CGPoint){-40,-50}]; // Guesstimate-- it must directly to the right of the target number

	[[boxView borderNorth] setHidden:!borderNorth];
	[[boxView borderNorth] setCenter:(CGPoint){0,-60}];

	[[boxView borderSouth] setHidden:!borderSouth];
	[[boxView borderSouth] setCenter:(CGPoint){0,60}];

	[[boxView borderEast] setHidden:!borderEast];
	[[boxView borderEast] setCenter:(CGPoint){60,0}];

	[[boxView borderWest] setHidden:!borderWest];
	[[boxView borderWest] setCenter:(CGPoint){-60,0}]; */

	[boxView autorelease];
	
	return boxView;
}

- (void)incrementVisitCount {
  visitCount+=1;
}

- (void)dealloc {
  [number release];
  [targetNumber release];
  [operation release];
  [borderNorth release];
  [borderSouth release];
  [borderEast release];
  [borderWest release];
  [super dealloc];
}
@end