//
//  MainMenuViewController.h
//  iPhone_Final_Project
//
//  Created by scholar on 4/16/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class InstructionsViewController;
@class BoardViewController;
@class BoxView;

@interface MainMenuViewController : UIViewController {
	InstructionsViewController *instructions;
	BoardViewController *board;
	
}

@property (nonatomic, retain) IBOutlet InstructionsViewController *instructions;
@property (nonatomic, retain) IBOutlet BoardViewController *board;

- (IBAction) viewInstructions: (id) sender;
- (IBAction) playGame: (id) sender;

@end

