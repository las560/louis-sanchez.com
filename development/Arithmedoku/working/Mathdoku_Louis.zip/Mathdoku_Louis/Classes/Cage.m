/**
 * Cage.m
**/

#import "Cage.h"

@implementation Cage

@end