//
//  testBox.h
//  Mathdoku
//
//  Created by scholar on 4/29/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface testBox : NSObject {
	NSInteger index;
	NSInteger group_number;
}

@property (nonatomic) NSInteger index;
@property (nonatomic) NSInteger group_number;

- (testBox*) initWithIndex: (NSInteger) index1 andGroup_number: (NSInteger) group_number1;
+ (testBox*) initWithIndex: (NSInteger) index1 andGroup_number: (NSInteger) group_number1;

@end
