/**
 * BoxView.m
**/

#import "BoxView.h"

@implementation BoxView

@synthesize number;
@synthesize boardIndex;
@synthesize numberTarget;
@synthesize mathOperation;

//
- (id)initForBoardSize:(NSInteger)boardSize withIndex:(NSInteger)index andTargetNumber:(NSInteger)targetNumber andOperation:(NSInteger)operation andBorders:(Borders)borders {
  CGRect frame = [self getFrameOfComponent:boxComponent forBoardSize:boardSize withIndex:index];
  [self initWithFrame:frame];
  [self setBackgroundColor:[UIColor whiteColor]];
  
  [self setBoardIndex:index];
  [self setNumberTarget:targetNumber];
  [self setMathOperation:operation];
  
  UIImageView *outline = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"outline_platinum.png"] toSize:CGSizeMake(frame.size.width, frame.size.height)]];
  [self addSubview:outline];
  
  if (borders.north) {
    UIImageView *north = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"border_black_north.png"] toSize:CGSizeMake(frame.size.width, frame.size.height)]];
    [self addSubview:north];
  }
  if (borders.south) {
    UIImageView *south = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"border_black_south.png"] toSize:CGSizeMake(frame.size.width, frame.size.height)]];
    [self addSubview:south];
  }
  if (borders.east) {
    UIImageView *east = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"border_black_east.png"] toSize:CGSizeMake(frame.size.width, frame.size.height)]];
    [self addSubview:east];
  }
  if (borders.west) {
    UIImageView *west = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"border_black_west.png"] toSize:CGSizeMake(frame.size.width, frame.size.height)]];;
    [self addSubview:west];
  }
  
  UILabel *target = [[UILabel alloc] initWithFrame:[self getFrameOfComponent:targetNumberComponent forBoardSize:boardSize withIndex:index]];
  //[target setAdjustsFontSizeToFitWidth:YES];
  //[target setMinimumFontSize:1.0];
  [target setTextAlignment:UITextAlignmentRight];
  [target setFont:[UIFont systemFontOfSize:10.0]];
  [target setText:[NSString stringWithFormat:@"%d", 12]];
  //[self insertSubview:target atIndex:0];
  [self addSubview:target];
  
  UILabel *oper = [[UILabel alloc] initWithFrame:[self getFrameOfComponent:operationComponent forBoardSize:boardSize withIndex:index]];
  [oper setTextAlignment:UITextAlignmentCenter];
  [oper setFont:[UIFont systemFontOfSize:10.0]];
  [oper setText:@"+"];
  [self addSubview:oper];
  
  return self;
}

//
- (CGRect)getFrameOfComponent:(NSInteger)component forBoardSize:(NSInteger)boardSize withIndex:(NSInteger)index {
  if (component == boxComponent) {
    if (boardSize == 4) return CGRectMake(80.0*(index%4), 80.0*(index/4)+80.0, 80.0, 80.0);
    else if (boardSize == 5) return CGRectMake(64.0*(index%5), 64.0*(index/5)+80.0, 64.0, 64.0);
    else if (boardSize == 6) return CGRectMake(53.0*(index%6)+1.0, 53.0*(index/6)+80.0, 53.0, 53.0);
    else if (boardSize == 7) return CGRectMake(45.0*(index%7)+2.0, 45.0*(index/7)+80.0, 45.0, 45.0);
    else if (boardSize == 8) return CGRectMake(40.0*(index%8), 40.0*(index/8)+80.0, 40.0, 40.0);
    else if (boardSize == 9) return CGRectMake(35.0*(index%9)+2.0, 35.0*(index/9)+80.0, 35.0, 35.0);
    else NSLog(@"Invalid board size, %d, found at: BoxView- getFrameForBoardSize:andIndex:", boardSize);
  }
  else if (component == targetNumberComponent) {
    if (boardSize == 4) return CGRectMake(80.0*(index%4), 80.0*(index/4)+80.0, 80.0, 80.0);
    else if (boardSize == 5) return CGRectMake(64.0*(index%5), 64.0*(index/5)+80.0, 64.0, 64.0);
    else if (boardSize == 6) return CGRectMake(3.0, 3.0, 12.0, 8.0);
    //else if (boardSize == 7) return CGRectMake(45.0*(index%7)+2.0, 45.0*(index/7)+80.0, 45.0, 45.0);
    //else if (boardSize == 8) return CGRectMake(40.0*(index%8), 40.0*(index/8)+80.0, 40.0, 40.0);
    //else if (boardSize == 9) return CGRectMake(35.0*(index%9)+2.0, 35.0*(index/9)+80.0, 35.0, 35.0);
    else NSLog(@"Invalid board size, %d, found at: BoxView- getFrameForBoardSize:andIndex:", boardSize);
  }
  else if (component == operationComponent) {
    if (boardSize == 4) return CGRectMake(80.0*(index%4), 80.0*(index/4)+80.0, 80.0, 80.0);
    else if (boardSize == 5) return CGRectMake(64.0*(index%5), 64.0*(index/5)+80.0, 64.0, 64.0);
    else if (boardSize == 6) return CGRectMake(18.0, 3.0, 6.0, 8.0);
    //else if (boardSize == 7) return CGRectMake(45.0*(index%7)+2.0, 45.0*(index/7)+80.0, 45.0, 45.0);
    //else if (boardSize == 8) return CGRectMake(40.0*(index%8), 40.0*(index/8)+80.0, 40.0, 40.0);
    //else if (boardSize == 9) return CGRectMake(35.0*(index%9)+2.0, 35.0*(index/9)+80.0, 35.0, 35.0);
    else NSLog(@"Invalid board size, %d, found at: BoxView- getFrameForBoardSize:andIndex:", boardSize);
  }
  else NSLog(@"Invalid component, %d, found at: BoxView- getFrameForBoardSize:andIndex:", component);
  return CGRectMake(0.0, 0.0, 0.0, 0.0);
}

//
- (UIImage *)scaleImage:(UIImage *)image toSize:(CGSize)size {
  UIGraphicsBeginImageContext(size);
  [image drawInRect:CGRectMake(0.0, 0.0, size.width, size.height)];
  UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
  UIGraphicsEndImageContext();
  //[scaledImage autorelease];
  return scaledImage;
}

//
Borders BordersMake(BOOL north, BOOL south, BOOL east, BOOL west) {
  Borders borders;
  borders.north = north;
  borders.south = south;
  borders.east = east;
  borders.west = west;
  return borders;
}

/*
// Initializes and returns a newly allocated view object with the specified frame rectangle.
- (id)initWithFrame:(CGRect)frame {
  if (self = [super initWithFrame:frame]) {
    // Initialization code.
  }
  return self;
}

// Draws the receiver’s image within the passed-in rectangle.
- (void)drawRect:(CGRect)rect {
  // Drawing code.
}
 */

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
  [number release];
}

- (void) printBox {
	NSLog(@"I am a box at index: %i", [self boardIndex]);
}

@end