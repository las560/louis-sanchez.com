//
//  testBox.m
//  Mathdoku
//
//  Created by scholar on 4/29/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "testBox.h"


@implementation testBox
@synthesize index, group_number;

- (testBox*) initWithIndex: (NSInteger) index1 andGroup_number: (NSInteger) group_number1 {
	testBox* box = [testBox new];
	[box setIndex: index1];
	[box setGroup_number: group_number1];
	return box;
}

+ (testBox*) initWithIndex: (NSInteger) index1 andGroup_number: (NSInteger) group_number1 {
	testBox* box = [testBox initWithIndex: index1 andGroup_number: group_number1];
	return box;
}
@end
