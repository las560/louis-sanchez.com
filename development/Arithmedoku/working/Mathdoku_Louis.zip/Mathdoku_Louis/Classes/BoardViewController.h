/**
 * BoardViewController.h
**/

#import <UIKit/UIKit.h>
#import "BoxView.h"
#import "testBox.h"

#define additionOperation 0
#define subtractionOperation 1
#define multiplicationOperation 2
#define noOperation 3

@interface BoardViewController : UIViewController {
	NSMutableArray *cage;
	NSMutableArray *allBoxes;
	NSInteger boardSize;
	NSMutableArray *array;
}

int convertIndexes(int index, int size);
void printNumbers(int a[], int size);
//void printArray(a, int size);
- (void) printCage;
- (void) printArray: (NSInteger) size;
- (IBAction)returnToMainMenu:(id)sender;
- (NSMutableArray*) create_Groupings_for_Cage: (NSMutableArray*) cages with: (NSMutableArray*) boxes withBoardSize: (int) size;
@property (nonatomic, retain) NSMutableArray *cage;
@property (nonatomic, retain) NSMutableArray *allBoxes;
@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic) NSInteger boardSize;
@end