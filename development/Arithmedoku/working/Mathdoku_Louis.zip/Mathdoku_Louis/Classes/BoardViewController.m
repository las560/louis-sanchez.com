/**
 * BoardViewController.m
**/

#import "BoardViewController.h"


@implementation BoardViewController
@synthesize cage, allBoxes, array, boardSize;

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  UIView *view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
  [view setBackgroundColor:[UIColor colorWithRed:.150 green:.120 blue:.182 alpha:1.0]]; // lavender
  
  UIButton *mainMenu = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenu addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  [mainMenu setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenu setFrame:CGRectMake(20.0, 20.0, 120.0, 40.0)];
  [view addSubview:mainMenu];
  
	[self setBoardSize: (9 + 2)];
	NSInteger f;
	NSInteger g;
	;
	// init array2
	
	array = [[NSMutableArray alloc] init];
	for (f = 0; f < boardSize; f++) {
		NSMutableArray *array2  = [[NSMutableArray alloc] init];
		for (g = 0; g < boardSize; g++) {
			[array2 addObject: [NSNumber numberWithInt: 0]];
		}
		[array addObject: array2];
		[array2 release];
	}		
	
	// Init allBoxes for size n.  The boxViews will be grouped into cages by the indexes of this array [0, (n * n)]
	allBoxes = [NSMutableArray arrayWithCapacity: (boardSize * boardSize)];
	// Init Cage to size 10.  May not need to use the entire array.  50 is a safe number for a 4x4 board	
	cage = [NSMutableArray arrayWithCapacity: 50];
	
  for (f = 0; f < (boardSize * boardSize); f++) {
    BoxView *box = [[BoxView alloc] initForBoardSize:4 withIndex:f andTargetNumber:3 andOperation:additionOperation andBorders:BordersMake(YES, YES, YES, YES)];
	  NSNumber *num = [NSNumber numberWithInteger: f];
	  [allBoxes addObject: num];  
	[view addSubview:box];
  }
	
	[self setView:view];
  [view release];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
	cage = [self create_Groupings_for_Cage: cage with: allBoxes withBoardSize: boardSize];
	[self printCage];
	//NSInteger practice1 = [[[cage objectAtIndex: 1] objectAtIndex: 1] boardIndex];
	//NSInteger practice2 = [[[cage objectAtIndex: 1] objectAtIndex: 2] boardIndex];
	//NSLog(@"Cage 1: first member has index %i", practice1);
	//NSLog(@"Cage 1: first member has index %i", practice2);

}

// Returns a Boolean value indicating whether the view controller supports the specified orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations.
  return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
}

//
- (IBAction)returnToMainMenu:(id)sender {
  [[self view] removeFromSuperview];
}

- (NSMutableArray*) create_Groupings_for_Cage: (NSMutableArray*) cages with: (NSMutableArray*) boxes withBoardSize: (int) n {
/*	int array[] = new int[1n];
	for (i = 0; i < array.length; i++)
		array[i] = 0;
	for (i = 0; i <= 15; i++) {
		random = randomGenerator.nextInt(2);
		index = randomGenerator.nextInt(1n);
		while (array[index] != 0)
			index = randomGenerator.nextInt(1n);
		array[index] = 1;
		if (random == 0)
			System.out.println("Cage of 2 for index: " + index + "\n");
		else if (random == 1)
			System.out.println("Cage of 3 for index: " + index + "\n");
	}	*/
	
	
	int i, j, k, random, index, group, counter, real_index1, real_index2, real_index3, pure_index2, pure_index3;
	int size = (n * n);
	int numbers[size];
	BOOL foundNeighbor = NO;
	NSMutableArray* cage_group;
	// set numbers array to zero
	for (i = 0; i < size; i++) {
		numbers[i] = 0;
	}
	NSLog(@"n equals %i", n);
	NSLog(@"size of board equals %i", size);
	printNumbers(numbers, size);
	
	// set all borders to zero and inside boxes to 1
	NSNumber* zero = [NSNumber numberWithInt: 0];
	NSNumber* one = [NSNumber numberWithInt: 1];

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (i == 0 || j == 0) {// top border and bottom borders
				[[array objectAtIndex: i] replaceObjectAtIndex: j withObject: zero];
				printf("array[%i][%i] = 0   ", i, j);
			}	
			else if (i == (n - 1) || j == (n - 1)) {		// left and right borders
				[[array objectAtIndex: i] replaceObjectAtIndex: j withObject: zero];
				printf("array[%i][%i] = 0   ", i, j);
			}
			else {				// inner boxes
				[[array objectAtIndex: i] replaceObjectAtIndex: j withObject: one];
				printf("array[%i][%i] = 1   ", i, j);
			}
			NSLog(@" ");
		}
	}
	NSLog(@"n equals %i", n);
	[self printArray: n];
	
	// begin cage generating
	for (i = 0; i < size; i++) {
		foundNeighbor = NO;				// security
		random = arc4random() % 2;		// random number from [0, 1]
		index = arc4random() % size;		// random number from [0, 35]
		while (numbers[index] != 0)
			index = arc4random() % size;		// random number from [0, 1]
		// 1 - number has been used but NOT necessarily grouped yet
		numbers[index] = 1;
		
		NSLog(@"index chosen: %i", index);
		NSLog(@"group chosen: %i", (random + 2));
		NSLog(@"coordinates: [%i, %i]", (index / n), (index % n));
		NSLog(@" ");
		
		// test to see if the index chosen is out of bounds
		if ([[[array objectAtIndex: (index / n)] objectAtIndex: (index % n)] integerValue] == 0) {
			numbers[index] = -1;
			[self printArray: n];
			continue;
		}
		// if index is chosen to be grouped in a cage of 2
		if (random == 0) {
			//NSLog(@"Cage of 2 for index: %i", index);
			group = 2;
			NSNumber *group1 = [NSNumber numberWithInt: group];
			[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: group1];
			//NSLog(@"index: %i and coordinates: [%i , %i] ", index, (index / n), (index % n));
			// increment group counter for that group
			counter = 1;
				
			// test to see if the indexes neighbors are possible group member
			for (k = -1; k <= 1; k+=2) {
				if ([[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] == group)	{	// check if left and right neighbors are definite candidates for grouping
					counter++;											// increment group counter for that group
					// test to see if group can be locked
					if (counter == group && [[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] == group) {
						// convert to the proper indexes
						real_index1 = convertIndexes(index, n);
						real_index2 = convertIndexes((index + k), n);
						
						NSLog(@"index: %i", index);
						NSLog(@"index + i: %i", index + k);
						NSLog(@"real_index1: %i", real_index1);
						NSLog(@"real_index2: %i", real_index2);
											
						// store boxView references in cage groups
						cage_group = [NSMutableArray arrayWithCapacity: 2];
						[cage_group addObject: [boxes objectAtIndex: real_index1]];
						[cage_group addObject: [boxes objectAtIndex: real_index2]];
						[cages addObject: cage_group];
						foundNeighbor = YES;
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: ((index % n) + k) withObject: zero];	// remove data from array
						
						// 2 - numbers are DONE completely
						numbers[index] = 2;
						numbers[index + k] = 2;
						break;
					}
				}
			}
			if (foundNeighbor == YES) {
				foundNeighbor = NO;
				[self printArray: n];
				continue;
			}
			for (k = -1; k <= 1; k+=2) {
				if ([[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] == group)	{	// check if top and bottom neighbors are definite candidates for grouping
					counter++;											// increment group counter for that group
					// test to see if group can be locked
					if (counter == group && [[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] == group) {
						// convert to the proper indexes
						real_index1 = convertIndexes(index, n);
						real_index2 = convertIndexes((index + (n * k)), n);
						
						NSLog(@"index: %i", index);
						NSLog(@"index + (n * i): %i", (index + (n * k)));
						NSLog(@"real_index1: %i", real_index1);
						NSLog(@"real_index2: %i", real_index2);
					
						// store boxView references in cage groups
						cage_group = [NSMutableArray arrayWithCapacity: 2];
						[cage_group addObject: [boxes objectAtIndex: real_index1]];
						[cage_group addObject: [boxes objectAtIndex: real_index2]];
						[cages addObject: cage_group];
						foundNeighbor = YES;
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: ((index / n) + k)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						
						// 2 - numbers are DONE completely
						numbers[index] = 2;
						numbers[(index + (n * k))] = 2;
						break;
					}
				}
			}	
			if (foundNeighbor == YES) {
				foundNeighbor = NO;
				[self printArray: n];
				continue;
			}
			// if no groupings were made check for other FORCED groupings
			NSLog(@"TESTING FOR FORCED GROUPS*******************");
			counter = 1;
//			NSLog(@"Forced groupings must be checked");
//			NSLog(@"group = %i", group);
			for (k = -1; k <= 1; k+=2) {
//				NSLog(@"Checking... index: %i", (index + (n * k)));
//				NSLog(@"index: %i has value of %i", (index + (n * k)), array[(index / n) + k][(index % n)]);
				if ([[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] > group)	{	// check if top and bottom neighbors are possible candidates for grouping
					counter++;											// increment group counter for that group
					// test to see if group can be locked
					if (counter == group && [[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] > group) {
						// convert to the proper indexes
						real_index1 = convertIndexes(index, n);
						real_index2 = convertIndexes((index + (n * k)), n);
						
					//	NSLog(@"index: %i", index);
					//	NSLog(@"index + (n * i): %i", (index + (n * k)));
					//	NSLog(@"real_index1: %i", real_index1);
					//	NSLog(@"real_index2: %i", real_index2);
					
						// store boxView references in cage groups
						cage_group = [NSMutableArray arrayWithCapacity: 2];
						[cage_group addObject: [boxes objectAtIndex: real_index1]];
						[cage_group addObject: [boxes objectAtIndex: real_index2]];
						[cages addObject: cage_group];
						foundNeighbor = YES;
						
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: ((index / n) + k)] replaceObjectAtIndex:	(index % n) withObject: zero];	// remove data from array
						
						// 2 - numbers are DONE completely
						numbers[index] = 2;
						numbers[(index + (n * k))] = 2;
						break;
					}
				}
			}			
			if (foundNeighbor == YES) {
				foundNeighbor = NO;
				[self printArray: n];
				continue;
			}
			for (k = -1; k <= 1; k+=2) {
				NSLog(@"Checking... index: %i", index + k);
				NSLog(@"index: %i has value of %i", index + k, [[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue]);
				if ([[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] > group)	{	// check if left and right neighbors are possible candidates for grouping
					counter++;											// increment group counter for that group
					// test to see if group can be locked
					if (counter == group && [[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] > group) {
						// convert to the proper indexes
						real_index1 = convertIndexes(index, n);
						real_index2 = convertIndexes((index + k), n);
						
						NSLog(@"index: %i", index);
						NSLog(@"index + i: %i", index + k);
						NSLog(@"real_index1: %i", real_index1);
						NSLog(@"real_index2: %i", real_index2);
					
						// store boxView references in cage groups
						cage_group = [NSMutableArray arrayWithCapacity: 2];
						[cage_group addObject: [boxes objectAtIndex: real_index1]];
						[cage_group addObject: [boxes objectAtIndex: real_index2]];
						[cages addObject: cage_group];
						foundNeighbor = YES;
						
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: ((index % n) + k) withObject: zero];	// remove data from array
						
						// 2 - numbers are DONE completely
						numbers[index] = 2;
						numbers[index + k] = 2;
						break;
					}
				}
			}
		}

		// else if index is chosen to be grouped in a cage of 3
		else if (random == 1) {
			//NSLog(@"Cage of 3 for index: %i", index);
			group = 3;
			NSNumber *group1 = [NSNumber numberWithInt: group];
			[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: group1];
			//NSLog(@"index: %i and coordinates: [%i , %i] ", index, (index / n), (index % n));
			// increment group counter for that group
			counter = 1;
				
			// test to see if the indexes neighbors are possible group member
			for (k = -1; k <= 1; k+=2) {
				if ([[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] == group)	{	// check if left and right neighbors are definite candidates for grouping
					counter++;											// increment group counter for that group
					NSLog(@"counter: %i", counter);
					// test to see if one possible neighbor is found
					if (counter == (group - 1) && [[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] == group) {
						NSLog(@"found first neighbor for group of 3");
						real_index2 = convertIndexes((index + k), n);
						pure_index2 = index + k;
						NSLog(@"pure_index2: %i", pure_index2);
						NSLog(@"retesting for neighbors of pure_index2...");
						// now retest for the neighbor we just found left and right
						for (j = -1; j <= 1; j+=2) {
							NSLog(@"testing... pure_index3 at %i", pure_index2 + j);
							
							if ([[[array objectAtIndex: (pure_index2 / n)] objectAtIndex: ((pure_index2 % n) + j)] integerValue] == group && ((pure_index2 % n) + j != index % n))	{	// check if left and right neighbors are definite candidates for grouping
								NSLog(@"Success at this index");
								counter++;									// increment group counter for that group
								real_index3 = convertIndexes((pure_index2 + j), n);
								pure_index3 = pure_index2 + j;
								break;
							}
							else
								NSLog(@"Fail at this index, retesting");
						}
						if (counter == group) {
							// store boxView references in cage groups
							real_index1 = convertIndexes(index, n);
							cage_group = [NSMutableArray arrayWithCapacity: 3];
							[cage_group addObject: [boxes objectAtIndex: real_index1]];
							[cage_group addObject: [boxes objectAtIndex: real_index2]];
							[cage_group addObject: [boxes objectAtIndex: real_index3]];
							[cages addObject: cage_group];
							foundNeighbor = YES;
							
							NSLog(@"Turn the following coordinates to 0");
							NSLog(@"[%i , %i]", (index / n), (index % n));
							NSLog(@"[%i , %i]", (index / n), (pure_index2 % n));
							NSLog(@"[%i , %i]", (index / n), (pure_index3 % n));
							
							[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
							[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
							[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index3 % n) withObject: zero];	// remove data from array
							
							// 2 - numbers are DONE completely
							numbers[index] = 2;
							numbers[pure_index2] = 2;
							numbers[pure_index3] = 2;
							
							NSLog(@"Found completed group");
							NSLog(@"pure_index1: %i", index);
							NSLog(@"pure_index2: %i", pure_index2);
							NSLog(@"pure_index3: %i", pure_index3);
							NSLog(@"real_index1: %i", real_index1);
							NSLog(@"real_index2: %i", real_index2);
							NSLog(@"real_index3: %i", real_index3);
							break;
						}
						// retest for the neighbor we just found up and down
						else {
							for (j = -1; j <= 1; j+=2) {
								NSLog(@"testing... pure_index3 at %i", pure_index2 + (n * j));
								if ([[[array objectAtIndex: ((pure_index2 / n) + j)] objectAtIndex: (pure_index2 % n)] integerValue] == group)	{	// check if top and bottom neighbors are definite candidates for grouping
									NSLog(@"Success at this index");
									counter++;									// increment group counter for that group
									real_index3 = convertIndexes((pure_index2 + (n * j)), n);
									pure_index3 = pure_index2 + (n * j);
									break;
								}
								else
									NSLog(@"Fail at this index, retesting");
							}
							if (counter == group) {
								// store boxView references in cage groups
								real_index1 = convertIndexes(index, n);
								cage_group = [NSMutableArray arrayWithCapacity: 3];
								[cage_group addObject: [boxes objectAtIndex: real_index1]];
								[cage_group addObject: [boxes objectAtIndex: real_index2]];
								[cage_group addObject: [boxes objectAtIndex: real_index3]];
								[cages addObject: cage_group];
								foundNeighbor = YES;
								
								[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
								[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
								[[array objectAtIndex: (pure_index3 / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
								
								NSLog(@"Turn the following coordinates to 0");
								NSLog(@"[%i , %i]", (index / n), (index % n));
								NSLog(@"[%i , %i]", (index / n), (pure_index2 % n));
								NSLog(@"[%i , %i]", (pure_index3 / n), (pure_index2 % n));
								
								// 2 - numbers are DONE completely
								numbers[index] = 2;
								numbers[pure_index2] = 2;
								numbers[pure_index3] = 2;
								
								NSLog(@"Found completed group");
								NSLog(@"pure_index1: %i", index);
								NSLog(@"pure_index2: %i", pure_index2);
								NSLog(@"pure_index3: %i", pure_index3);
								NSLog(@"real_index1: %i", real_index1);
								NSLog(@"real_index2: %i", real_index2);
								NSLog(@"real_index3: %i", real_index3);
								break;
							}
						}
					}
					// test to see if group can be locked (STILL LEFT AND RIGHT)
					
					else if (counter == group && [[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] == group) {
						NSLog(@"counter: %i", counter);
						NSLog(@"group: %i", group);
						// convert to the proper indexes
						real_index1 = convertIndexes(index, n);
						real_index3 = convertIndexes((index + k), n);
						pure_index3 = (index + k);
						
						NSLog(@"index: %i", index);
						NSLog(@"index + i: %i", index + k);
						NSLog(@"index + i: %i", pure_index2);
						NSLog(@"real_index1: %i", real_index1);
						NSLog(@"real_index2: %i", real_index2);
						NSLog(@"real_index3: %i", real_index3);
						
						// store boxView references in cage groups
						cage_group = [NSMutableArray arrayWithCapacity: 3];
						[cage_group addObject: [boxes objectAtIndex: real_index1]];
						[cage_group addObject: [boxes objectAtIndex: real_index2]];
						[cage_group addObject: [boxes objectAtIndex: real_index3]];
						[cages addObject: cage_group];
						foundNeighbor = YES;
						
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index3 % n) withObject: zero];	// remove data from array
						
						// 2 - numbers are DONE completely
						numbers[index] = 2;
						numbers[pure_index3] = 2;
						numbers[pure_index2] = 2;
						break;
					}
				}
			}
			if (foundNeighbor == YES) {
				foundNeighbor = NO;
				[self printArray: n];
				continue;
			}
			for (k = -1; k <= 1; k+=2) {
				if ([[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] == group)	{	// check if top and bottom neighbors are definite candidates for grouping
					counter++;											// increment group counter for that group
					NSLog(@"counter: %i", counter);
					// test to see if one possible neighbor is found
					if (counter == (group - 1) && [[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] == group) {
						NSLog(@"found first neighbor for group of 3");
						real_index2 = convertIndexes((index + (n * k)), n);
						pure_index2 = (index + (n * k));
						NSLog(@"pure_index2: %i", pure_index2);
						NSLog(@"retesting for neighbors of pure_index2...");

						// now retest for the neighbor we just found left and right
						for (j = -1; j <= 1; j+=2) {
							NSLog(@"testing... pure_index3 at %i", pure_index2 + j);
							if ([[[array objectAtIndex: (pure_index2 / n)] objectAtIndex: ((pure_index2 % n) + j)] integerValue] == group)	{	// check if left and right neighbors are definite candidates for grouping
								NSLog(@"Success at this index");
								counter++;									// increment group counter for that group
								real_index3 = convertIndexes((pure_index2 + j), n);
								pure_index3 = pure_index2 + j;
								break;
							}
							else
								NSLog(@"Fail at this index, retesting");
						}
						if (counter == group) {
							// store boxView references in cage groups
							real_index1 = convertIndexes(index, n);
							cage_group = [NSMutableArray arrayWithCapacity: 3];
							[cage_group addObject: [boxes objectAtIndex: real_index1]];
							[cage_group addObject: [boxes objectAtIndex: real_index2]];
							[cage_group addObject: [boxes objectAtIndex: real_index3]];
							[cages addObject: cage_group];
							foundNeighbor = YES;
							
							NSLog(@"Turn the following coordinates to 0");
							NSLog(@"[%i , %i]", (index / n), (index % n));
							NSLog(@"[%i , %i]", (pure_index2 / n), (index % n));
							NSLog(@"[%i , %i]", (pure_index2 / n), (pure_index3 % n));
								  
							[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
							[[array objectAtIndex: (pure_index2 / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
							[[array objectAtIndex: (pure_index2 / n)] replaceObjectAtIndex: (pure_index3 % n) withObject: zero];	// remove data from array
							
							// 2 - numbers are DONE completely
							numbers[index] = 2;
							numbers[pure_index2] = 2;
							numbers[pure_index3] = 2;
							
							NSLog(@"Found completed group");
							NSLog(@"pure_index1: %i", index);
							NSLog(@"pure_index2: %i", pure_index2);
							NSLog(@"pure_index3: %i", pure_index3);
							NSLog(@"real_index1: %i", real_index1);
							NSLog(@"real_index2: %i", real_index2);
							NSLog(@"real_index3: %i", real_index3);							
							break;
						}
						// retest for the neighbor we just found up and down
						else {
							for (j = -1; j <= 1; j+=2) {
								NSLog(@"testing... pure_index3 at %i", pure_index2 + (n * j));
								if ([[[array objectAtIndex: ((pure_index2 / n) + j)] objectAtIndex: (pure_index2 % n)] integerValue] == group && ((pure_index2 / n) + j != index / n))	{	// check if top and bottom neighbors are definite candidates for grouping
									NSLog(@"Success at this index");
									counter++;									// increment group counter for that group
									real_index3 = convertIndexes((pure_index2 + (n * j)), n);
									pure_index3 = pure_index2 + (n * j);
									break;
								}
								else
									NSLog(@"Fail at this index, retesting");
							}
							if (counter == group) {
								// store boxView references in cage groups
								real_index1 = convertIndexes(index, n);
								cage_group = [NSMutableArray arrayWithCapacity: 3];
								[cage_group addObject: [boxes objectAtIndex: real_index1]];
								[cage_group addObject: [boxes objectAtIndex: real_index2]];
								[cage_group addObject: [boxes objectAtIndex: real_index3]];
								[cages addObject: cage_group];
								foundNeighbor = YES;
								
								[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
								[[array objectAtIndex: (pure_index2 / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
								[[array objectAtIndex: (pure_index3 / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
								
								NSLog(@"Turn the following coordinates to 0");
								NSLog(@"[%i , %i]", (index / n), (index % n));
								NSLog(@"[%i , %i]", (pure_index2 / n), (index % n));
								NSLog(@"[%i , %i]", (pure_index3 / n), (index % n));
								
								
								// 2 - numbers are DONE completely
								numbers[index] = 2;
								numbers[pure_index2] = 2;
								numbers[pure_index3] = 2;
								
								NSLog(@"Found completed group");
								NSLog(@"pure_index1: %i", index);
								NSLog(@"pure_index2: %i", pure_index2);
								NSLog(@"pure_index3: %i", pure_index3);
								NSLog(@"real_index1: %i", real_index1);
								NSLog(@"real_index2: %i", real_index2);
								NSLog(@"real_index3: %i", real_index3);				
								break;
							}
						}
					}
					// test to see if group can be locked
					else if (counter == group && [[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] == group) {
						NSLog(@"counter: %i", counter);
						// convert to the proper indexes
						real_index1 = convertIndexes(index, n);
						real_index3 = convertIndexes((index + (n * k)), n);
						pure_index3 = (index + (n * k));
						
						NSLog(@"index: %i", index);
						NSLog(@"index + (n * i): %i", index + (n * k));
						NSLog(@"index + (n * i): %i", pure_index2);
						NSLog(@"real_index1: %i", real_index1);
						NSLog(@"real_index2: %i", real_index2);
						NSLog(@"real_index3: %i", real_index3);
						
						// store boxView references in cage groups
						cage_group = [NSMutableArray arrayWithCapacity: 3];
						[cage_group addObject: [boxes objectAtIndex: real_index1]];
						[cage_group addObject: [boxes objectAtIndex: real_index2]];
						[cage_group addObject: [boxes objectAtIndex: real_index3]];
						[cages addObject: cage_group];
						foundNeighbor = YES;
						
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (pure_index3 / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array

						// 2 - numbers are DONE completely
						numbers[index] = 2;
						numbers[pure_index3] = 2;
						numbers[pure_index2] = 2;
						break;
					}
				}
			}	
			if (foundNeighbor == YES) {
				foundNeighbor = NO;
				[self printArray: n];
				continue;
			}
			// if no groupings were made check for other FORCED groupings
			NSLog(@"TESTING FOR FORCED GROUPS*******************");
			counter = 1;
			for (k = -1; k <= 1; k+=2) {
				if ([[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] >= (group - 1))	{	// check if left and right neighbors are definite candidates for grouping
					counter++;											// increment group counter for that group
					NSLog(@"counter: %i", counter);
					// test to see if one possible neighbor is found
					if (counter == (group - 1) && [[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] >= (group - 1)) {
						NSLog(@"found first neighbor for group of 3");
						real_index2 = convertIndexes((index + k), n);
						pure_index2 = index + k;
						NSLog(@"pure_index2: %i", pure_index2);
						NSLog(@"retesting for neighbors of pure_index2...");
						// now retest for the neighbor we just found left and right
						for (j = -1; j <= 1; j+=2) {
							NSLog(@"testing... pure_index3 at %i", pure_index2 + j);
							if ([[[array objectAtIndex: (pure_index2 / n)] objectAtIndex: ((pure_index2 % n) + j)] integerValue] >= (group - 1) && ((pure_index2 % n) + j != index % n))	{	// check if left and right neighbors are definite candidates for grouping
								NSLog(@"Success at this index");
								counter++;									// increment group counter for that group
								real_index3 = convertIndexes((pure_index2 + j), n);
								pure_index3 = pure_index2 + j;
								break;
							}
							else
								NSLog(@"Fail at this index, retesting");
						}
						if (counter == group) {
							// store boxView references in cage groups
							real_index1 = convertIndexes(index, n);
							cage_group = [NSMutableArray arrayWithCapacity: 3];
							[cage_group addObject: [boxes objectAtIndex: real_index1]];
							[cage_group addObject: [boxes objectAtIndex: real_index2]];
							[cage_group addObject: [boxes objectAtIndex: real_index3]];
							[cages addObject: cage_group];
							foundNeighbor = YES;
							
							NSLog(@"Turn the following coordinates to 0");
							NSLog(@"[%i , %i]", (index / n), (index % n));
							NSLog(@"[%i , %i]", (index / n), (pure_index2 % n));
							NSLog(@"[%i , %i]", (index / n), (pure_index3 % n));
							
							[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
							[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
							[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index3 % n) withObject: zero];	// remove data from array
							
							// 2 - numbers are DONE completely
							numbers[index] = 2;
							numbers[pure_index2] = 2;
							numbers[pure_index3] = 2;
							
							NSLog(@"Found completed group");
							NSLog(@"pure_index1: %i", index);
							NSLog(@"pure_index2: %i", pure_index2);
							NSLog(@"pure_index3: %i", pure_index3);
							NSLog(@"real_index1: %i", real_index1);
							NSLog(@"real_index2: %i", real_index2);
							NSLog(@"real_index3: %i", real_index3);
							break;
						}
						// retest for the neighbor we just found up and down
						else {
							for (j = -1; j <= 1; j+=2) {
								NSLog(@"testing... pure_index3 at %i", pure_index2 + (n * j));
								if ([[[array objectAtIndex: ((pure_index2 / n) + j)] objectAtIndex: (pure_index2 % n)] integerValue] >= (group - 1))	{	// check if top and bottom neighbors are definite candidates for grouping
									NSLog(@"Success at this index");
									counter++;									// increment group counter for that group
									real_index3 = convertIndexes((pure_index2 + (n * j)), n);
									pure_index3 = pure_index2 + (n * j);
									break;
								}
								else
									NSLog(@"Fail at this index, retesting");
							}
							if (counter == group) {
								// store boxView references in cage groups
								real_index1 = convertIndexes(index, n);
								cage_group = [NSMutableArray arrayWithCapacity: 3];
								[cage_group addObject: [boxes objectAtIndex: real_index1]];
								[cage_group addObject: [boxes objectAtIndex: real_index2]];
								[cage_group addObject: [boxes objectAtIndex: real_index3]];
								[cages addObject: cage_group];
								foundNeighbor = YES;
								
								[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
								[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
								[[array objectAtIndex: (pure_index3 / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
								
								NSLog(@"Turn the following coordinates to 0");
								NSLog(@"[%i , %i]", (index / n), (index % n));
								NSLog(@"[%i , %i]", (index / n), (pure_index2 % n));
								NSLog(@"[%i , %i]", (pure_index3), (pure_index2 % n));
								
								// 2 - numbers are DONE completely
								numbers[index] = 2;
								numbers[pure_index2] = 2;
								numbers[pure_index3] = 2;
								
								NSLog(@"Found completed group");
								NSLog(@"pure_index1: %i", index);
								NSLog(@"pure_index2: %i", pure_index2);
								NSLog(@"pure_index3: %i", pure_index3);
								NSLog(@"real_index1: %i", real_index1);
								NSLog(@"real_index2: %i", real_index2);
								NSLog(@"real_index3: %i", real_index3);
								break;
							}
						}
					}
					// test to see if group can be locked
					else if (counter == group && [[[array objectAtIndex: (index / n)] objectAtIndex: ((index % n) + k)] integerValue] >= (group - 1)) {
						NSLog(@"counter: %i", counter);
						// convert to the proper indexes
						real_index1 = convertIndexes(index, n);
						real_index3 = convertIndexes((index + k), n);
						pure_index3 = (index + k);
						
						NSLog(@"index: %i", index);
						NSLog(@"index + i: %i", index + k);
						NSLog(@"index + i: %i", pure_index2);
						NSLog(@"real_index1: %i", real_index1);
						NSLog(@"real_index2: %i", real_index2);
						NSLog(@"real_index3: %i", real_index3);
						
						// store boxView references in cage groups
						cage_group = [NSMutableArray arrayWithCapacity: 3];
						[cage_group addObject: [boxes objectAtIndex: real_index1]];
						[cage_group addObject: [boxes objectAtIndex: real_index2]];
						[cage_group addObject: [boxes objectAtIndex: real_index3]];
						[cages addObject: cage_group];
						foundNeighbor = YES;
						
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index3 % n) withObject: zero];	// remove data from array
						
						// 2 - numbers are DONE completely
						numbers[index] = 2;
						numbers[pure_index3] = 2;
						numbers[pure_index2] = 2;
						break;
					}
				}
			}
			if (foundNeighbor == YES) {
				foundNeighbor = NO;
				[self printArray: n];
				continue;
			}
			for (k = -1; k <= 1; k+=2) {
				if ([[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] >= (group - 1))	{	// check if top and bottom neighbors are definite candidates for grouping
					counter++;											// increment group counter for that group
					NSLog(@"counter: %i", counter);
					// test to see if one possible neighbor is found
					if (counter == (group - 1) && [[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] >= (group - 1)) {
						NSLog(@"found first neighbor for group of 3");
						real_index2 = convertIndexes((index + (n * k)), n);
						pure_index2 = (index + (n * k));
						NSLog(@"pure_index2: %i", pure_index2);
						NSLog(@"retesting for neighbors of pure_index2...");
						
						// now retest for the neighbor we just found left and right
						for (j = -1; j <= 1; j+=2) {
							NSLog(@"testing... pure_index3 at %i", pure_index2 + j);
							if ([[[array objectAtIndex: (pure_index2 / n)] objectAtIndex: ((pure_index2 % n) + j)] integerValue] >= (group - 1))	{	// check if left and right neighbors are definite candidates for grouping
								NSLog(@"Success at this index");
								counter++;									// increment group counter for that group
								real_index3 = convertIndexes((pure_index2 + j), n);
								pure_index3 = pure_index2 + j;
								break;
							}
							else
								NSLog(@"Fail at this index, retesting");
						}
						if (counter == group) {
							// store boxView references in cage groups
							real_index1 = convertIndexes(index, n);
							cage_group = [NSMutableArray arrayWithCapacity: 3];
							[cage_group addObject: [boxes objectAtIndex: real_index1]];
							[cage_group addObject: [boxes objectAtIndex: real_index2]];
							[cage_group addObject: [boxes objectAtIndex: real_index3]];
							[cages addObject: cage_group];
							foundNeighbor = YES;
							
							NSLog(@"Turn the following coordinates to 0");
							NSLog(@"[%i , %i]", (index / n), (index % n));
							NSLog(@"[%i , %i]", (index / n), (pure_index2 % n));
							NSLog(@"[%i , %i]", (pure_index2 / n), (index % n));
							
							[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
							[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
							[[array objectAtIndex: (pure_index2 / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
							
							// 2 - numbers are DONE completely
							numbers[index] = 2;
							numbers[pure_index2] = 2;
							numbers[pure_index3] = 2;
							
							NSLog(@"Found completed group");
							NSLog(@"pure_index1: %i", index);
							NSLog(@"pure_index2: %i", pure_index2);
							NSLog(@"pure_index3: %i", pure_index3);
							NSLog(@"real_index1: %i", real_index1);
							NSLog(@"real_index2: %i", real_index2);
							NSLog(@"real_index3: %i", real_index3);							
							break;
						}
						// retest for the neighbor we just found up and down
						else {
							for (j = -1; j <= 1; j+=2) {
								NSLog(@"testing... pure_index3 at %i", pure_index2 + (n * j));
								if ([[[array objectAtIndex: ((pure_index2 / n) + j)] objectAtIndex: (pure_index2 % n)] integerValue] >= (group - 1) && ((pure_index2 / n) + j != index / n))	{	// check if top and bottom neighbors are definite candidates for grouping
									NSLog(@"Success at this index");
									counter++;									// increment group counter for that group
									real_index3 = convertIndexes((pure_index2 + (n * j)), n);
									pure_index3 = pure_index2 + (n * j);
									break;
								}
								else
									NSLog(@"Fail at this index, retesting");
							}
							if (counter == group) {
								// store boxView references in cage groups
								real_index1 = convertIndexes(index, n);
								cage_group = [NSMutableArray arrayWithCapacity: 3];
								[cage_group addObject: [boxes objectAtIndex: real_index1]];
								[cage_group addObject: [boxes objectAtIndex: real_index2]];
								[cage_group addObject: [boxes objectAtIndex: real_index3]];
								[cages addObject: cage_group];
								foundNeighbor = YES;
								NSLog(@"Turn the following coordinates to 0");
								NSLog(@"[%i , %i]", (index / n), (index % n));
								NSLog(@"[%i , %i]", (pure_index2 / n), (index % n));
								NSLog(@"[%i , %i]", (pure_index3 / n), (index % n));
								
								[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
								[[array objectAtIndex: (pure_index2 / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
								[[array objectAtIndex: (pure_index3 / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
								
								// 2 - numbers are DONE completely
								numbers[index] = 2;
								numbers[pure_index2] = 2;
								numbers[pure_index3] = 2;
								
								NSLog(@"Found completed group");
								NSLog(@"pure_index1: %i", index);
								NSLog(@"pure_index2: %i", pure_index2);
								NSLog(@"pure_index3: %i", pure_index3);
								NSLog(@"real_index1: %i", real_index1);
								NSLog(@"real_index2: %i", real_index2);
								NSLog(@"real_index3: %i", real_index3);				
								break;
							}
						}
					}
					// test to see if group can be locked
					else if (counter == group && [[[array objectAtIndex: ((index / n) + k)] objectAtIndex: (index % n)] integerValue] >= (group - 1)) {
						NSLog(@"counter: %i", counter);
						// convert to the proper indexes
						real_index1 = convertIndexes(index, n);
						real_index3 = convertIndexes((index + (n * k)), n);
						pure_index3 = (index + (n * k));
						
						NSLog(@"index: %i", index);
						NSLog(@"index + (n * i): %i", index + (n * k));
						NSLog(@"index + (n * i): %i", pure_index2);
						NSLog(@"real_index1: %i", real_index1);
						NSLog(@"real_index2: %i", real_index2);
						NSLog(@"real_index3: %i", real_index3);
						
						// store boxView references in cage groups
						cage_group = [NSMutableArray arrayWithCapacity: 3];
						[cage_group addObject: [boxes objectAtIndex: real_index1]];
						[cage_group addObject: [boxes objectAtIndex: real_index2]];
						[cage_group addObject: [boxes objectAtIndex: real_index3]];
						[cages addObject: cage_group];
						foundNeighbor = YES;
						
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (index / n)] replaceObjectAtIndex: (pure_index2 % n) withObject: zero];	// remove data from array
						[[array objectAtIndex: (pure_index3 / n)] replaceObjectAtIndex: (index % n) withObject: zero];	// remove data from array
						
						// 2 - numbers are DONE completely
						numbers[index] = 2;
						numbers[pure_index3] = 2;
						numbers[pure_index2] = 2;
						break;
					}
				}
			}
		}
		[self printArray: n];
	}
	// check for "leftovers" that did not get grouped
	for (i = 0; i <  size; i++) {
		// if leftover (ungrouped)
		if (numbers[i] == 1) {
			real_index1 = convertIndexes(i, n);
			// check all neighbors to form groups of 2
			// check left
			if (numbers[i - 1] == 1) {
				real_index2 = convertIndexes((i - 1), n);
				NSLog(@"PLACING BOX WITH INDEX %i into cage of 2 with % i", real_index1, real_index2);
				cage_group = [NSMutableArray arrayWithCapacity: 2];
				[cage_group addObject: [boxes objectAtIndex: real_index1]];
				[cage_group addObject: [boxes objectAtIndex: real_index2]];
				[cages addObject: cage_group];
				// remove data
				numbers[i] = 2;
				numbers[i - 1] = 2;
			}
			// check right
			else if (numbers[i + 1] == 1) {
				real_index2 = convertIndexes((i + 1), n);
				NSLog(@"PLACING BOX WITH INDEX %i into cage of 2 with % i", real_index1, real_index2);
				cage_group = [NSMutableArray arrayWithCapacity: 2];
				[cage_group addObject: [boxes objectAtIndex: real_index1]];
				[cage_group addObject: [boxes objectAtIndex: real_index2]];
				[cages addObject: cage_group];
				// remove data
				numbers[i] = 2;
				numbers[i + 1] = 2;
			}
			// check top
			else if (numbers[i - n] == 1) {
				real_index2 = convertIndexes((i - n), n);
				NSLog(@"PLACING BOX WITH INDEX %i into cage of 2 with % i", real_index1, real_index2);
				cage_group = [NSMutableArray arrayWithCapacity: 2];
				[cage_group addObject: [boxes objectAtIndex: real_index1]];
				[cage_group addObject: [boxes objectAtIndex: real_index2]];
				[cages addObject: cage_group];
				// remove data
				numbers[i] = 2;
				numbers[i - n] = 2;
			}
			else if (numbers[i + n] == 1) {
				real_index2 = convertIndexes((i + n), n);
				NSLog(@"PLACING BOX WITH INDEX %i into cage of 2 with % i", real_index1, real_index2);
				cage_group = [NSMutableArray arrayWithCapacity: 2];
				[cage_group addObject: [boxes objectAtIndex: real_index1]];
				[cage_group addObject: [boxes objectAtIndex: real_index2]];
				[cages addObject: cage_group];
				// remove data
				numbers[i] = 2;
				numbers[i + n] = 2;
			}
			// no neighbors so must go in single cage
			else {
				NSLog(@"PLACING BOX WITH INDEX %i into cage of 2 with % i", real_index1, real_index2);
				cage_group = [NSMutableArray arrayWithCapacity: 1];
				[cage_group addObject: [boxes objectAtIndex: real_index1]];
				[cages addObject: cage_group];
				numbers[i] = 2;
			}
		}
	}
	[self printArray: n];
	NSLog(@"AFTER LEFTOVERS ARE PROCESSES");
	printNumbers(numbers, size);
	return cages;
}
										   
int convertIndexes(int index, int size) {
	int real_index;
	if (size == 6) {				// 4 x 4 board
		if (index >= 7 && index <= 10)	
			real_index = index - 7;	
		else if (index >= 13 && index <= 16)
			real_index = index - 9;
		else if (index >= 19 && index <= 22)
			real_index = index - 11;
		else if (index >= 25 && index <= 28)
			real_index = index - 13;
	}
	else if (size == 7) {				// 5 X 5 board
		if (index >= 8 && index <= 12)	
			real_index = index - 8;	
		else if (index >= 15 && index <= 19)
			real_index = index - 10;
		else if (index >= 22 && index <= 26)
			real_index = index - 12;
		else if (index >= 29 && index <= 33)
			real_index = index - 14;
		else if (index >= 36 && index <= 40)
			real_index = index - 16;
	}
	else if (size == 8) {				// 6 X 6 board
		if (index >= 9 && index <= 14)	
			real_index = index - 9;	
		else if (index >= 17 && index <= 22)
			real_index = index - 11;
		else if (index >= 25 && index <= 30)
			real_index = index - 13;
		else if (index >= 33 && index <= 38)
			real_index = index - 15;
		else if (index >= 41 && index <= 46)
			real_index = index - 17;
		else if (index >= 49 && index <= 54)
			real_index = index - 19;
	}
	else if (size == 9) {				// 7 X 7 board
		if (index >= 10 && index <= 16)	
			real_index = index - 10;	
		else if (index >= 19 && index <= 25)
			real_index = index - 12;
		else if (index >= 28 && index <= 34)
			real_index = index - 14;
		else if (index >= 37 && index <= 43)
			real_index = index - 16;
		else if (index >= 46 && index <= 52)
			real_index = index - 18;
		else if (index >= 55 && index <= 61)
			real_index = index - 20;
		else if (index >= 64 && index <= 70)
			real_index = index - 22;
	}
	else if (size == 10) {				// 8 X 8 board
		if (index >= 11 && index <= 18)	
			real_index = index - 11;	
		else if (index >= 21 && index <= 28)
			real_index = index - 13;
		else if (index >= 31 && index <= 38)
			real_index = index - 15;
		else if (index >= 41 && index <= 48)
			real_index = index - 17;
		else if (index >= 51 && index <= 58)
			real_index = index - 19;
		else if (index >= 61 && index <= 68)
			real_index = index - 21;
		else if (index >= 71 && index <= 78)
			real_index = index - 23;
		else if (index >= 81 && index <= 88)
			real_index = index - 25;
	}
	else if (size == 11) {				// 9 X 9 board
		if (index >= 12 && index <= 20)	
			real_index = index - 12;	
		else if (index >= 23 && index <= 31)
			real_index = index - 14;
		else if (index >= 34 && index <= 42)
			real_index = index - 16;
		else if (index >= 45 && index <= 53)
			real_index = index - 18;
		else if (index >= 56 && index <= 64)
			real_index = index - 20;
		else if (index >= 67 && index <= 75)
			real_index = index - 22;
		else if (index >= 78 && index <= 86)
			real_index = index - 24;
		else if (index >= 89 && index <= 97)
			real_index = index - 26;
		else if (index >= 100 && index <= 108)
			real_index = index - 28;
	}
		return real_index;
}
void printNumbers (int a[], int size) {
	int i;
	//NSLog(@"Numbers[]:");
	NSLog(@"Numbers[]: ");
	for (i = 0; i < size; i++) {
		//System.out.print("*" + (i%5) + " ");
		if (i == 0)
			printf("%i ", a[i]);
		else if ((i + 1) % (int)sqrt(size) == 0) {
			printf("%i\n", a[i]);
			//System.out.print(numbers[i] + "\n");
			//printf("%i ", a[i]);
		}
		else
			printf("%i ", a[i]);
			//System.out.print(numbers[i] + " ");
	}
	//NSLog(@" ");
}
- (void) printArray: (NSInteger) size {
	int i;
	int j;
	NSLog(@"Array[]:");
	for (i = 0; i < size; i++) {
		for (j = 0; j < size; j++) {
			printf("%i ", [[[array objectAtIndex: i] objectAtIndex: j] integerValue]);
		}
		NSLog(@" ");
	}
	NSLog(@" ");
}
- (void) printCage {
	NSInteger i;
	NSInteger j;
	for (i = 0; i < [cage count]; i++) {
		printf("Cage %i: ", i);
		for (j = 0; j < [[cage objectAtIndex: i] count]; j++)
			NSLog(@"box with index: %i", [[[cage objectAtIndex:i] objectAtIndex: j] integerValue]);
	}	
}

@end