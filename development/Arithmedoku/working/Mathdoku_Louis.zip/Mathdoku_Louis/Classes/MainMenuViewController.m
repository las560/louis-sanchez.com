/**
 * MainMenuViewController.m
**/

#import "MainMenuViewController.h"

@implementation MainMenuViewController

@synthesize instructions;
@synthesize board;
@synthesize viewInstructions;
@synthesize playGame;

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  UIView *view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
  [view setBackgroundColor:[UIColor colorWithRed:0.0 green:0.123 blue:0.167 alpha:1.0]]; // cerulean
  
  instructions = [InstructionsViewController alloc];
  board = [BoardViewController alloc];
  
  viewInstructions = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [viewInstructions addTarget:self action:@selector(viewInstructions:) forControlEvents:UIControlEventTouchDown];
  [viewInstructions setTitle:@"Instructions" forState:UIControlStateNormal];
  [viewInstructions setFrame:CGRectMake(20.0, 420.0, 120.0, 40.0)];
  [view addSubview:viewInstructions];
  
  playGame = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [playGame addTarget:self action:@selector(playGame:) forControlEvents:UIControlEventTouchDown];
  [playGame setTitle:@"Play Game" forState:UIControlStateNormal];
  [playGame setFrame:CGRectMake(180.0, 420.0, 120.0, 40.0)];
  [view addSubview:playGame];
  
  [self setView:view];
  [view release];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
}

// Returns a Boolean value indicating whether the view controller supports the specified orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations.
  return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [instructions release];
  [board release];
  [viewInstructions release];
  [playGame release];
  [super dealloc];
}

//
- (IBAction)viewInstructions:(id)sender {
  [[self view] addSubview:[instructions view]];
}

//
- (IBAction)playGame:(id)sender {
  [[self view] addSubview:[board view]];
}

@end