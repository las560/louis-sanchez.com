/**
 * Cage.h
**/

#import <Foundation/Foundation.h>

@interface Cage : NSObject {
}

@end