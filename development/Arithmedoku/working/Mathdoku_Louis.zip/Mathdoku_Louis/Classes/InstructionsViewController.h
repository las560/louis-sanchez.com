/**
 * InstructionsViewController.h
**/

#import <UIKit/UIKit.h>

@interface InstructionsViewController : UIViewController {
}

- (IBAction)returnToMainMenu:(id)sender;

@end