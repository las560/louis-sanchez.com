/**
 * BoxView.h
**/

#import <UIKit/UIKit.h>

#define boxComponent 0
#define targetNumberComponent 1
#define operationComponent 2

struct Borders {
  BOOL north;
  BOOL south;
  BOOL east;
  BOOL west;
};
typedef struct Borders Borders;

@interface BoxView : UIView {
  UILabel *number;
  NSInteger boardIndex;
  NSInteger numberTarget;
  NSInteger mathOperation;
}

@property(nonatomic, retain) IBOutlet UILabel *number;
@property(nonatomic) NSInteger boardIndex;
@property(nonatomic) NSInteger numberTarget;
@property(nonatomic) NSInteger mathOperation;

- (id)initForBoardSize:(NSInteger)boardSize withIndex:(NSInteger)index andTargetNumber:(NSInteger)targetNumber andOperation:(NSInteger)operation andBorders:(Borders)borders;
- (CGRect)getFrameOfComponent:(NSInteger)component forBoardSize:(NSInteger)boardSize withIndex:(NSInteger)index;
- (UIImage *)scaleImage:(UIImage *)image toSize:(CGSize)size;
- (void) printBox;
Borders BordersMake(BOOL north, BOOL south, BOOL east, BOOL west);

@end