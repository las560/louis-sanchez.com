/**
 * InstructionsViewController.m
**/

#import "InstructionsViewController.h"

@implementation InstructionsViewController

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  UIView *view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
  [view setBackgroundColor:[UIColor colorWithRed:.064 green:.130 blue:.109 alpha:1.0]]; // viridian
    
  UIButton *mainMenu = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenu addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  [mainMenu setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenu setFrame:CGRectMake(20.0, 20.0, 120.0, 40.0)];
  [view addSubview:mainMenu];
  
  UILabel *instructions = [[UILabel alloc] initWithFrame:CGRectMake(20.0, 80.0, 280.0, 380.0)];
  [instructions setLineBreakMode:UILineBreakModeWordWrap];
  [instructions setNumberOfLines:0];
  [instructions setTextColor:[UIColor whiteColor]];
  [instructions setBackgroundColor:[UIColor colorWithWhite:0.0 alpha:0.0]];
  [instructions setFont:[UIFont boldSystemFontOfSize:14.0]];
  [instructions setText:@"     KenKen is a logic and arithmetic based puzzle game in which you fill a square grid of boxes with numbers. A board consists of n2 boxes, arranged in an n×n grid. Each box is filled with a number, from 1 to n, abiding by a few simple rules:\n\n     −	The numbers cannot repeat in any row or column.\n     −	The numbers in each heavily outlined set of boxes (cages) must combine (in any order) using the mathematical operation indicated to form the target number shown in the top corner of the cage.\n     −	Cages with only one box are just filled with the target number.\n     - A number can repeat within a cage as long as it is not in the same row or column."];
  [view addSubview:instructions];
  
  [self setView:view];
  [view release];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
}

// Returns a Boolean value indicating whether the view controller supports the specified orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations.
  return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
}

//
- (IBAction)returnToMainMenu:(id)sender {
  [[self view] removeFromSuperview];
}

@end