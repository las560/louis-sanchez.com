/**
 * MainMenuViewController.h
**/

#import <UIKit/UIKit.h>
#import "InstructionsViewController.h"
#import "BoardViewController.h"

@interface MainMenuViewController : UIViewController {
  InstructionsViewController *instructions;
  BoardViewController *board;
  UIButton *viewInstructions;
  UIButton *playGame;
}

@property(nonatomic, retain) InstructionsViewController *instructions;
@property(nonatomic, retain) BoardViewController *board;
@property(nonatomic, retain) UIButton *viewInstructions;
@property(nonatomic, retain) UIButton *playGame;

- (IBAction)viewInstructions:(id)sender;
- (IBAction)playGame:(id)sender;

@end