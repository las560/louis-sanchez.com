//
//  MainMenuViewController.m
//  iPhone_Final_Project
//
//  Created by scholar on 4/16/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "MainMenuViewController.h"

@implementation MainMenuViewController

@synthesize instructions;
@synthesize board;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}

- (IBAction) viewInstructions: (id) sender {
	//[UIView beginAnimations:Nil context:Nil];
	//[UIView setAnimationDuration:1.0];
	//[UIView setAnimationTransition:UIViewAnimationTransitionCurlDown forView:self.view cache:YES];
	//[self.view removeFromSuperview];
  [[self view] addSubview:[instructions view]];
	//[self.view addSubview: instructions.view];
	//[UIView commitAnimations];
	
}

- (IBAction) playGame: (id) sender {
	//[UIView beginAnimations:Nil context:Nil];
	//[UIView setAnimationDuration:1.0];
	//[UIView setAnimationTransition:UIViewAnimationTransitionCurlDown forView:self.view cache:YES];
	//[self.view removeFromSuperview];
	//[self.view addSubview: board.view];
	//[UIView commitAnimations];
  [[self view] addSubview:[board view]];
	
}

- (void)dealloc {
    [super dealloc];
	[board dealloc];
	[instructions dealloc];
}

@end
