//
//  BoardViewController.m
//  iPhone_Final_Project
//
//  Created by scholar on 4/16/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BoardViewController.h"

@implementation BoardViewController
@synthesize box1, numbersLeft;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[super viewDidLoad];
    //Borders borders = BordersMake(YES, YES, YES, YES);
	Borders borders;
	borders = BordersMake(YES, YES, YES, YES);
	[self randomizeBoard];
    NSString *num;
	// When this number in the loop is reached, the box created will be the SINGLE BOX IN THE BOARD
	int single_box = arc4random() % 16;

	for (int i = 0; i < 16; i++) {
		if (i < 4) { 
			num = [NSString stringWithFormat:@"%d", array[0][i]];
		}
		else if (i < 8) {
			num = [NSString stringWithFormat:@"%d", array[1][i-4]];
		}
		else if (i < 12) {
			num = [NSString stringWithFormat:@"%d", array[2][i-8]];
		}
		else if (i < 16) {
			num = [NSString stringWithFormat:@"%d", array[3][i-12]];
		}
		BoxView *box = [BoxView boxViewWithTargetNumber:num andOperation:@"+" andBorders:borders andFrame:CGRectMake(80 * (i % 4), 80 * (i / 4) + 1, 79, 79)];
		
		if (i == single_box) {
			Cage* cage = [Cage cageWithBox: box];
			[cage setNumbersLeft: ([cage numbersLeft] - 1)];
		}
		else {
			// if groupType == 0 , box belongs in a group of TWO
			// else if groupType == 1 , box belongs in a group of THREE
			
			int groupType = arc4random() % 2;
			if (groupType == 0) {
				
				// find a way to dynamically group and remember to decrement numbersLeft counter for THAT particular Cage
				
			}
			else if (groupType == 1) {
			
				// find a way to dynamically group and remember to decrement numbersLeft counter for THAT particular Cage
				
			}
		}
		
		[box setNumber:[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 79, 79)]];
		[[box number] setBackgroundColor:[UIColor colorWithWhite:0.0 alpha:0.0]];
		//[[box number] setFont:[[UIFont alloc] fontWithSize:16.0]];
		[[box number] setTextColor:[UIColor blackColor]];
		[[box number] setTextAlignment:UITextAlignmentCenter];
		[[box number] setUserInteractionEnabled:YES];
		[[box number] setText:num];
		[[box number] setHidden:NO];
		[box addSubview:[box number]];
		[[self view] addSubview:box];
	}		
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (IBAction) returnToMenu: (id) sender {
	[UIView beginAnimations:Nil context:Nil];
	[UIView setAnimationDuration:1.0];
	[UIView setAnimationTransition:UIViewAnimationTransitionCurlDown forView:self.view cache:YES];
	[self.view removeFromSuperview];
	[UIView commitAnimations];
}

- (void) randomizeBoard {
	// Set all elements in array to 0 (zero)
	for(int i = 0 ; i < 4 ; i++) {
		for(int j = 0 ; j < 4 ; j++) {
			array[i][j] = 0;
		}
	}	
	// Begin randomizing
	BOOL used = YES;
	int flag = 0;
	for( int i = 0 ; i < 4 ; i++) {
		for( int j = 0 ; j < 4 ; j++) {
			used = YES;
			while (used == YES) {
				// get random number that is non-zero
				int num = arc4random() % 5;
				while (num == 0)
					num = arc4random() % 5;
				// first check the entire row
				for (int column = 0 ; column < 4 ; column++) {
					// check to skip over selected cell
					if (column == j)
						continue;
					else if (array[i][column] == num) {
						flag = 0;
						break;
					}
					else
						flag = 1;
				}
				// check to see if loop was broken
				if (flag == 0)
					continue;
				// now check entire column
				for (int row = 0 ; row < 4; row++) {
					if (row == i)
						continue;
					else if (array[row][j] == num) {
						flag = 0;
						break;
					}
					else
						flag = 2;
				}
				if (flag == 0)
					continue;
				else {
					used = NO;
					array[i][j] = num;
					NSLog(@"%i ", array[i][j]);
				}
			}
		}
		NSLog(@"");
	}	
}

- (void) group {
	
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [super dealloc];
}

@end
