//
//  Cage.h
//  iPhone_Final_Project
//
//  Created by scholar on 4/26/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BoxView.h"


@interface Cage : NSObject {
	NSInteger numbersLeft;
	NSArray *group;
}

@property (nonatomic) NSInteger numbersLeft;
@property (nonatomic, retain) NSArray *group;



- (Cage*) initWithBox: (BoxView*) box1;
- (Cage*) initWithBox: (BoxView*) box1 andBox: (BoxView*) box2;
- (Cage*) initWithBox: (BoxView*) box1 andBox: (BoxView*) box2 andBox: (BoxView*) box3;
+ (Cage*) cageWithBox: (BoxView*) box1;
+ (Cage*) cageWithBox: (BoxView*) box1 andBox: (BoxView*) box2;
+ (Cage*) cageWithBox: (BoxView*) box1 andBox: (BoxView*) box2 andBox: (BoxView*) box3;


@end
