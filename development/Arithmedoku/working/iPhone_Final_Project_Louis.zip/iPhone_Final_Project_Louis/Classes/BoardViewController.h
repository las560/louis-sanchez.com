//
//  BoardViewController.h
//  iPhone_Final_Project
//
//  Created by scholar on 4/16/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#include <stdio.h>
#import <UIKit/UIKit.h>
#import "BoxView.h"
#import "Cage.h"


@interface BoardViewController : UIViewController {
	IBOutlet BoxView *box1;
	int array[4][4];
	NSInteger numbersLeft;	
}

@property (nonatomic, retain) IBOutlet BoxView *box1;
@property (nonatomic) NSInteger numbersLeft;

- (IBAction) returnToMenu: (id) sender;
- (void) randomizeBoard;
- (void) group;

@end
