//
//  iPhone_Final_ProjectAppDelegate.m
//  iPhone_Final_Project
//
//  Created by scholar on 4/16/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "iPhone_Final_ProjectAppDelegate.h"
#import "MainMenuViewController.h"

@implementation iPhone_Final_ProjectAppDelegate

@synthesize window;
@synthesize menu;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:menu.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [menu release];
    [window release];
    [super dealloc];
}


@end
