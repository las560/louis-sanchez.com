/**
 * BoxView.h
**/

#import "BoxView.h"

@implementation BoxView

@synthesize number;
@synthesize targetNumber;
@synthesize operation;
@synthesize borders;

Borders BordersMake(BOOL north, BOOL south, BOOL east, BOOL west) {
  Borders borders;
  borders.north = north;
  borders.south = south;
  borders.east = east;
  borders.west = west;
  return borders;
}

+ (BoxView *)boxViewWithTargetNumber:(NSString *)thisTargetNumber andOperation:(NSString *)thisOperation andBorders:(Borders)theseBorders andFrame:(CGRect)frame {    
	BoxView *boxView = [[BoxView alloc] initWithFrame:frame];
  NSLog(@"BoxView.m-- boxViewWithTargetNumber:andOperation:andBorders:andFrame:-- frame: (x:%f,y:%f),(w:%f,h:%f)", frame.origin.x, frame.origin.y, frame.size.width, frame.size.height);
	
  [boxView setBackgroundColor:[UIColor whiteColor]];
  
  //[boxView setBorders:theseBorders];
  /*
  UILabel *umber;
  
  [umber initWithFrame:frame];
  [umber setBackgroundColor:[UIColor colorWithWhite:0.0 alpha:0.0]];
  [umber setFont:[UIFont fontWithName:@"Times New Roman TimesNewRomanPSMT" size:14.0]];
  [umber setTextColor:[UIColor blackColor]];
  [umber setTextAlignment:UITextAlignmentCenter];
  [umber setUserInteractionEnabled:YES];
  [umber setText:thisTargetNumber];
  [umber setHidden:NO];
  
  [boxView setNumber:umber];
  //[[boxView view] addSubview:umber];
   
  
  NSLog(@"BoxView.m-- boxViewWithTargetNumber:andOperation:andBorders:andFrame:-- borders:(%d, %d, %d, %d)", borders.north, borders.south, borders.east, borders.west);
   */
  
	[boxView autorelease];
	return boxView;
}

- (void)dealloc {
  [number release];
  [targetNumber release];
  [operation release];
  [super dealloc];
}
@end