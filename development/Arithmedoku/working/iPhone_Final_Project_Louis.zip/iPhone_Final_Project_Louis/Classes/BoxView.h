/**
 * BoxView.h
**/

struct Borders {
  BOOL north;
  BOOL south;
  BOOL east;
  BOOL west;
};
typedef struct Borders Borders;

@interface BoxView : UIView {
  IBOutlet UILabel *number;
	UILabel *targetNumber;
	UILabel *operation;
  Borders borders;
}

@property(nonatomic, retain) IBOutlet UILabel *number;
@property(nonatomic, retain) UILabel *targetNumber;
@property(nonatomic, retain) UILabel *operation;
@property(nonatomic) Borders borders;

+ (BoxView *)boxViewWithTargetNumber:(NSString *)targetNumber andOperation:(NSString *)operation andBorders:(Borders)borders andFrame:(CGRect)frame;
Borders BordersMake(BOOL north, BOOL south, BOOL east, BOOL west);

@end