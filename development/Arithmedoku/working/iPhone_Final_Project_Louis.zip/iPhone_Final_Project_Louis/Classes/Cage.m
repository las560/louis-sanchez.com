//
//  Cage.m
//  iPhone_Final_Project
//
//  Created by scholar on 4/26/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Cage.h"


@implementation Cage
@synthesize numbersLeft, group;

// Create an instance of a Cage containing ONE box and return it 

- (Cage*) initWithBox: (BoxView*) box1 {
	Cage* cage1 = [Cage new];
	[cage1 setGroup: [NSArray arrayWithObject: box1]];
	[cage1 setNumbersLeft: 1];
	return cage1;
}

// Create an instance of a Cage containing TWO boxes and return it 

- (Cage*) initWithBox: (BoxView*) box1 andBox: (BoxView*) box2 {
	Cage* cage1 = [Cage new];
	[cage1 setGroup: [NSArray arrayWithObjects: box1, box2, Nil]];
	[cage1 setNumbersLeft: 2];
	return cage1;
}

// Create an instance of a Cage containing THREE boxes and return it 

- (Cage*) initWithBox: (BoxView*) box1 andBox: (BoxView*) box2 andBox: (BoxView*) box3 {
	Cage* cage1 = [Cage new];
	[cage1 setGroup: [NSArray arrayWithObjects: box1, box2, box3, Nil]];
	[cage1 setNumbersLeft: 3];
	return cage1;
}

// Initialize a Cage containing ONE box and return it 

+ (Cage*) cageWithBox: (BoxView*) box1 {
	Cage* cage1 = [cage1 initWithBox: box1];
	return cage1;
}

// Initialize a Cage containing TWO boxes and return it 

+ (Cage*) cageWithBox: (BoxView*) box1 andBox: (BoxView*) box2 {
	Cage* cage1 = [cage1 initWithBox: box1 andBox: box2];
	return cage1;
}

// Initialize a Cage containing THREE boxes and return it 

+ (Cage*) cageWithBox: (BoxView*) box1 andBox: (BoxView*) box2 andBox: (BoxView*) box3 {
	Cage* cage1 = [cage1 initWithBox: box1 andBox: box2 andBox: box3];
	return cage1;	
}

@end
