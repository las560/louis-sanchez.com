/**
 * BoardViewController.h
**/

#import <QuartzCore/QuartzCore.h>
#import "Generators.h"

@interface BoardViewController : UIViewController {
  Generators *generators;
  NSInteger boardSize;
  UIView *savedGameBoard;
  NSMutableArray *board;
  NSMutableArray *buttonsPortrait;
  NSMutableArray *buttonsLandscape;
  NSMutableArray *alertsPortrait;
  NSMutableArray *alertsLandscape;
}

@property(nonatomic, retain) Generators *generators;
@property(nonatomic) NSInteger boardSize;
@property(nonatomic, retain) UIView *savedGameBoard;
@property(nonatomic, retain) NSMutableArray *board;
@property(nonatomic, retain) NSMutableArray *buttonsPortrait;
@property(nonatomic, retain) NSMutableArray *buttonsLandscape;
@property(nonatomic, retain) NSMutableArray *alertsPortrait;
@property(nonatomic, retain) NSMutableArray *alertsLandscape;

- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize;
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame;
- (void)checkBoard;
- (IBAction)revealBoard:(UIButton *)button;
- (IBAction)clearBoard:(UIButton *)button;
- (IBAction)returnToMainMenu:(UIButton *)button;
- (void)saveBoard:(NSNotification *)notification;
- (void)didRotate:(NSNotification *)notification;

@end