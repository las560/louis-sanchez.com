/**
 * BoxView.m
**/

#import "BoxView.h"

@implementation BoxView

@synthesize boardSize;
@synthesize index;
@synthesize digit;
@synthesize number;
@synthesize targetNumber;
@synthesize operation;
@synthesize borders;
@synthesize touchOrigin;

// Returns the BoxView initialized with the given board size, index, number, target number, operation, and borders.
- (BoxView *)initForBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex andDigit:(NSInteger)aDigit andNumber:(NSInteger)aNumber andTargetNumber:(NSInteger)aTargetNumber andOperation:(NSInteger)anOperation andBorders:(Borders)someBorders {
  CGRect boxFrame = [self getBoxFrameForBoardSize:aBoardSize withIndex:anIndex];
  [self initWithFrame:boxFrame];
  [self setBackgroundColor:[UIColor whiteColor]];
  
  [self setBoardSize:aBoardSize];
  [self setIndex:anIndex];
  [self setDigit:aDigit];
  [self setNumber:[self getLabelForNumber:aNumber forBoardSize:aBoardSize withIndex:anIndex]];
  [self setTargetNumber:aTargetNumber];
  [self setOperation:anOperation];
  [self setBorders:someBorders];
  
  [self addSubview:number];
  [self addSubview:[self getLabelForTargetNumber:aTargetNumber andOperation:anOperation forBoardSize:aBoardSize withIndex:anIndex]];
  
  UIImageView *outline = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"outline_platinum.png"] toSize:CGSizeMake(boxFrame.size.width, boxFrame.size.height)]];
  [self addSubview:outline];
  
  if (someBorders.north) {
    UIImageView *north = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"border_black_north.png"] toSize:CGSizeMake(boxFrame.size.width, boxFrame.size.height)]];
    [self addSubview:north];
  }
  if (someBorders.south) {
    UIImageView *south = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"border_black_south.png"] toSize:CGSizeMake(boxFrame.size.width, boxFrame.size.height)]];
    [self addSubview:south];
  }
  if (someBorders.east) {
    UIImageView *east = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"border_black_east.png"] toSize:CGSizeMake(boxFrame.size.width, boxFrame.size.height)]];
    [self addSubview:east];
  }
  if (someBorders.west) {
    UIImageView *west = [[UIImageView alloc] initWithImage:[self scaleImage:[UIImage imageNamed:@"border_black_west.png"] toSize:CGSizeMake(boxFrame.size.width, boxFrame.size.height)]];;
    [self addSubview:west];
  }
  
  return self;
}

// Returns the frame for the box, given the board size and index.
- (CGRect)getBoxFrameForBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex {
  switch (aBoardSize) {
    case 4: return CGRectMake(80.0*(anIndex%4), 80.0*(anIndex/4), 80.0, 80.0); break;
    case 5: return CGRectMake(64.0*(anIndex%5), 64.0*(anIndex/5), 64.0, 64.0); break;
    case 6: return CGRectMake(53.0*(anIndex%6)+1.0, 53.0*(anIndex/6), 53.0, 53.0); break;
    case 7: return CGRectMake(45.0*(anIndex%7)+2.0, 45.0*(anIndex/7), 45.0, 45.0); break;
    case 8: return CGRectMake(40.0*(anIndex%8), 40.0*(anIndex/8), 40.0, 40.0); break;
    case 9: return CGRectMake(35.0*(anIndex%9)+2.0, 35.0*(anIndex/9), 35.0, 35.0); break;
    default: NSLog(@"Invalid board size, %d, found at: BoxView.m- getBoxFrameForBoardSize:withIndex:", aBoardSize); break;
  }
  return CGRectMake(0.0, 0.0, 0.0, 0.0);
}

// Returns the label for the number, given the number, board size, and index.
- (UILabel *)getLabelForNumber:(NSInteger)aNumber forBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex {
  CGRect frame;
  CGFloat fontSize;
  switch (aBoardSize) {
    case 4: frame = CGRectMake(0.0, 0.0, 80.0, 80.0); fontSize = 24.0; break;
    case 5: frame = CGRectMake(0.0, 0.0, 64.0, 64.0); fontSize = 22.0; break;
    case 6: frame = CGRectMake(0.0, 0.0, 53.0, 53.0); fontSize = 20.0; break;
    case 7: frame = CGRectMake(0.0, 0.0, 45.0, 45.0); fontSize = 18.0; break;
    case 8: frame = CGRectMake(0.0, 0.0, 40.0, 40.0); fontSize = 16.0; break;
    case 9: frame = CGRectMake(0.0, 0.0, 35.0, 35.0); fontSize = 14.0; break;
    default: NSLog(@"Invalid board size, %d, found at: BoxView.m- getLabelForNumber:forBoardSize:withIndex:", aBoardSize);
             frame = CGRectMake(0.0, 0.0, 0.0, 0.0); fontSize = 0.0; break;
  }
  
  UILabel *numberLabel = [[UILabel alloc] initWithFrame:frame];
  [numberLabel setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [numberLabel setFont:[UIFont systemFontOfSize:fontSize]];
  [numberLabel setTextAlignment:UITextAlignmentCenter];
  if (aNumber == NOTHING) {
    [numberLabel setText:@""];
  }
  else {
    [numberLabel setText:[NSString stringWithFormat:@"%d", aNumber]];
  }
  [numberLabel autorelease];
  return numberLabel;
}

// Returns the label for the target number and operation, given the target number, operation, board size, and index.
- (UILabel *)getLabelForTargetNumber:(NSInteger)aTargetNumber andOperation:(NSInteger)anOperation forBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex {
  NSString *targetNumberText = aTargetNumber == NOTHING ? @"" : [NSString stringWithFormat:@"%d", aTargetNumber];
  NSString *operationText;
  switch (anOperation) {
    case NOTHING: operationText = @""; break;
    case ADDITION: operationText = @"+"; break;
    case SUBTRACTION: operationText = @"−"; break;
    case MULTIPLICATION: operationText = @"×"; break;
    case DIVISION: operationText = @"÷"; break;
    default: NSLog(@"Invalid operation, %d, found at: BoxView.m- getLabelForTargetNumber:andOperation:forBoardSize:withIndex:", aBoardSize);
             operationText = @""; break;
  }
  NSString *targetNumberAndOperationText = [NSString stringWithFormat:@"%@%@", targetNumberText, operationText];
  
  CGRect frame;
  CGFloat fontSize;
  switch (aBoardSize) {
    case 4: frame = CGRectMake(4.0, 4.0, 60.0, 16.0); fontSize = 20.0; break;
    case 5: frame = CGRectMake(4.0, 4.0, 54.0, 14.0); fontSize = 18.0; break;
    case 6: frame = CGRectMake(4.0, 4.0, 48.0, 12.0); fontSize = 16.0; break;
    case 7: frame = CGRectMake(4.0, 4.0, 42.0, 10.0); fontSize = 14.0; break;
    case 8: frame = CGRectMake(4.0, 4.0, 36.0, 10.0); fontSize = [targetNumberAndOperationText length] <= 5 ? 12.0 : 10.0; break;
    case 9: frame = CGRectMake(4.0, 4.0, 30.0, 8.0); fontSize = [targetNumberAndOperationText length] <= 5 ? 10.0 : 8.0; break;
    default: NSLog(@"Invalid board size, %d, found at: BoxView- getLabelForTargetNumber:andOperation:forBoardSize:withIndex:", aBoardSize);
             frame = CGRectMake(0.0, 0.0, 0.0, 0.0); fontSize = 0.0; break;
  }
  
  UILabel *targetNumberAndOperationLabel = [[UILabel alloc] initWithFrame:frame];
  [targetNumberAndOperationLabel setBackgroundColor:[UIColor colorWithWhite:0.0 alpha:0.0]];
  [targetNumberAndOperationLabel setFont:[UIFont systemFontOfSize:fontSize]];
  [targetNumberAndOperationLabel setLineBreakMode:UILineBreakModeClip];
  [targetNumberAndOperationLabel setText:targetNumberAndOperationText];
  [targetNumberAndOperationLabel autorelease];
  return targetNumberAndOperationLabel;
}

// Returns the given image scaled to the given size.
- (UIImage *)scaleImage:(UIImage *)image toSize:(CGSize)size {
  UIGraphicsBeginImageContext(size);
  [image drawInRect:CGRectMake(0.0, 0.0, size.width, size.height)];
  UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
  UIGraphicsEndImageContext();
  [scaledImage autorelease];
  return scaledImage;
}

// Returns a Borders structure filled in with the border values provided.
Borders BordersMake(BOOL north, BOOL south, BOOL east, BOOL west) {
  Borders borders;
  borders.north = north;
  borders.south = south;
  borders.east = east;
  borders.west = west;
  return borders;
}

// Changes the number to the given value.
- (void)changeNumberTo:(NSInteger)aNumber {
  if (aNumber == NOTHING) {
    [number setText:@""];
  }
  else {
    [number setText:[NSString stringWithFormat:@"%d", aNumber]];
  }
}

// Returns the displacement between the given point and the touchOrigin.
- (double)displacementFromTouchOrigin:(CGPoint)point {
  double x = pow(point.x - touchOrigin.x, 2.0);
  double y = pow(point.y - touchOrigin.y, 2.0);
  return sqrt(x + y);
}

// Tells the receiver when one or more fingers touch down in a view or window.
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
  UITouch *touch = [[event allTouches] anyObject];
  CGPoint location = [touch locationInView:[[touch view] superview]];
  touchOrigin = CGPointMake(location.x, location.y);
  
  if ([touch tapCount] == 2) {
    NSString *clearBoxSoundPath = [[NSBundle mainBundle] pathForResource:@"beep_very-light" ofType:@"wav"];
    SystemSoundID clearBoxSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:clearBoxSoundPath], &clearBoxSound);
    AudioServicesPlaySystemSound(clearBoxSound);
    [clearBoxSoundPath release];
    
    [number setText:@""];
  }
  else if ([touch tapCount] == 3) {
    NSString *revealBoxSoundPath = [[NSBundle mainBundle] pathForResource:@"crank" ofType:@"wav"];
    SystemSoundID revealBoxSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:revealBoxSoundPath], &revealBoxSound);
    AudioServicesPlaySystemSound(revealBoxSound);
    [revealBoxSoundPath release];
    
    [number setText:[NSString stringWithFormat:@"%d", digit]];
  }
  else {
    [number setText:@"1"];
  }
}

// Tells the receiver when one or more fingers associated with an event move within a view or window.
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
  UITouch *touch = [[event allTouches] anyObject];
  CGPoint location = [touch locationInView:[[touch view] superview]];
  
  double displacement = [self displacementFromTouchOrigin:CGPointMake(location.x, location.y)];
  NSInteger aDigit = displacement/(320/boardSize*.5);
  if (aDigit > boardSize) {
    aDigit = boardSize;
  }
  if (aDigit != 0) {
    [number setText:[NSString stringWithFormat:@"%d", aDigit]];
  }
}

// Tells the receiver when one or more fingers are raised from a view or window.
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
  UITouch *touch = [[event allTouches] anyObject];
  CGPoint location = [touch locationInView:[[touch view] superview]];
  location = location;
  
  // Need to implement warning system. The call to it would be here.
}

// Returns a string that represents the contents of the receiving class.
- (NSString *)description {
	return [NSString stringWithFormat:@"%d %d %d %d %d %d %d %d", digit, [[number text] integerValue], targetNumber, operation, borders.north, borders.south, borders.east, borders.west];
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
  [number release];
}

@end