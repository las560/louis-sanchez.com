/**
 * Generators.h
**/

#import "BoxView.h"
#import "Cage.h"

@interface Generators : NSObject {
}

- (NSMutableArray *)generateBoardWithBoardSize:(NSInteger)boardSize;
- (NSMutableArray *)generateGridWithBoardSize:(NSInteger)boardSize;
- (NSMutableArray *)generateCagesWithGrid:(NSMutableArray *)grid withBoardSize:(NSInteger)boardSize;
- (NSMutableArray *)generateBoardWithGrid:(NSMutableArray *)grid andCages:(NSMutableArray *)cages;
- (NSMutableArray *)rotateArray:(NSMutableArray *)array thisManyTimes:(NSInteger)times;

@end