/**
 * Generators.m
**/

#import "Generators.h"

@implementation Generators

//
- (NSMutableArray *)generateBoardWithBoardSize:(NSInteger)boardSize {
  NSMutableArray *grid = [self generateGridWithBoardSize:boardSize];
  //NSMutableArray *cages = [self generateCagesWithGrid:grid withBoardSize:boardSize];
  //return [self generateBoardWithGrid:grid andCages:cages];
  return grid;
}

//
- (NSMutableArray *)generateGridWithBoardSize:(NSInteger)boardSize {
  NSMutableArray *digits = [NSMutableArray arrayWithObjects:nil];
  NSMutableArray *shifts = [NSMutableArray arrayWithObjects:nil];
  for (NSInteger digit = 1; digit <= boardSize; digit++) {
    [digits addObject:[NSNumber numberWithInteger:digit]];
    [shifts addObject:[NSNumber numberWithInteger:digit]];
  }
  [shifts removeLastObject];
  
  NSMutableArray *row = [NSMutableArray arrayWithObjects:nil];
  for (NSInteger index = 0; index < boardSize; index++) {
    NSInteger digit = arc4random()%[digits count];
    [row addObject:[digits objectAtIndex:digit]];
    [digits removeObjectAtIndex:digit];
  }
  
  NSMutableArray *grid = [NSMutableArray arrayWithObjects:nil];
  [grid addObjectsFromArray:row];
  for (NSInteger shift = 0; shift < boardSize-1; shift++) {
    NSMutableArray *shiftedRow = [NSMutableArray arrayWithArray:row];
    NSInteger times = arc4random()%[shifts count];
    [grid addObjectsFromArray:[self rotateArray:shiftedRow thisManyTimes:[[shifts objectAtIndex:times] integerValue]]];
    [shifts removeObjectAtIndex:times];
  }
  return grid;
}

//
- (NSMutableArray *)generateCagesWithGrid:(NSMutableArray *)grid withBoardSize:(NSInteger)boardSize {
  return [NSMutableArray arrayWithObjects:nil];
}

//
- (NSMutableArray *)generateBoardWithGrid:(NSMutableArray *)grid andCages:(NSMutableArray *)cages {
  return [NSMutableArray arrayWithObjects:nil];
}

//
- (NSMutableArray *)rotateArray:(NSMutableArray *)array thisManyTimes:(NSInteger)times {
  if (times < 0) {
    for (NSInteger count = 0; count < times; count++) {
      [array insertObject:[array lastObject] atIndex:0];
      [array removeLastObject];
    }
  }
  else if (times > 0) {
    for (NSInteger count = 0; count < times; count++) {
      [array addObject:[array objectAtIndex:0]];
      [array removeObjectAtIndex:0];
    }
  }
  return array;
}

@end