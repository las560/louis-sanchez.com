/**
 * AboutViewController.m
**/

#import "AboutViewController.h"

@implementation AboutViewController

@synthesize pages;
@synthesize currentPage;

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  
  [self setPages:[[NSMutableArray alloc] initWithObjects:nil]];
  
  [[self view] setFrame:[[UIScreen mainScreen] applicationFrame]];
  [[self view] setBackgroundColor:[UIColor colorWithRed:64/255.0 green:130/255.0 blue:109/255.0 alpha:1.0]]; // viridian
  
  UIButton *mainMenu = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenu setFrame:CGRectMake(10.0, 10.0, 100.0, 30.0)];
  [mainMenu setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenu addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  [[self view] addSubview:mainMenu];
  
  UIButton *nextPage = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [nextPage setFrame:CGRectMake(210.0, 440.0, 100.0, 30.0)];
  [nextPage setTitle:@"Next Page" forState:UIControlStateNormal];
  [nextPage addTarget:self action:@selector(displayNextPage:) forControlEvents:UIControlEventTouchDown];
  [[self view] addSubview:nextPage];
  
  UILabel *authors = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 40.0, 300.0, 420.0)];
  [authors setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [authors setFont:[UIFont boldSystemFontOfSize:20.0]];
  [authors setLineBreakMode:UILineBreakModeWordWrap];
  [authors setNumberOfLines:0];
  [authors setTextAlignment:UITextAlignmentCenter];
  [authors setTextColor:[UIColor whiteColor]];
  [authors setText:@"Arithmedoku was created by:\n\nSalvatore DiLeo and\nLouis Sanchez"];
  [pages addObject:authors];
  
  [self setCurrentPage:0];
  [[self view] addSubview:[pages objectAtIndex:currentPage]];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
}

// Displays the next page, wrapping around if the last page displayed.
- (IBAction)displayNextPage:(UIButton *)button {
  NSString *flipPageSoundPath = [[NSBundle mainBundle] pathForResource:@"crank" ofType:@"wav"];
  SystemSoundID flipPageSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:flipPageSoundPath], &flipPageSound);
  AudioServicesPlaySystemSound(flipPageSound);
  [flipPageSoundPath release];
  
  [[pages objectAtIndex:currentPage] removeFromSuperview];
  currentPage = currentPage+1 >= [pages count] ? 0 : currentPage+1;
  [[self view] addSubview:[pages objectAtIndex:currentPage]];
}

// Removes the the AboutViewController's view from its superview, thus returning to the main menu.
- (IBAction)returnToMainMenu:(UIButton *)button {
  NSString *closeWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"window-transition_close" ofType:@"wav"];
  SystemSoundID closeWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:closeWindowSoundPath], &closeWindowSound);
  AudioServicesPlaySystemSound(closeWindowSound);
  [closeWindowSoundPath release];
  
  [[self view] removeFromSuperview];
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
  [pages release];
}

@end