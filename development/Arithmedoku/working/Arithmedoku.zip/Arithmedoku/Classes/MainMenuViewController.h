/**
 * MainMenuViewController.h
**/

#import "AboutViewController.h"
#import "InstructionsViewController.h"
#import "BoardViewController.h"

@interface MainMenuViewController : UIViewController {
  UIView *boardSizes;
}

@property(nonatomic, retain) UIView *boardSizes;

- (IBAction)about:(UIButton *)button;
- (IBAction)viewInstructions:(UIButton *)button;
- (IBAction)playGame:(UIButton *)button;

@end