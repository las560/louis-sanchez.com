/**
 * InstructionsViewController.m
**/

#import "InstructionsViewController.h"

@implementation InstructionsViewController

@synthesize pages;
@synthesize currentPage;

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  
  [self setPages:[[NSMutableArray alloc] initWithObjects:nil]];
  
  [[self view] setFrame:[[UIScreen mainScreen] applicationFrame]];
  [[self view] setBackgroundColor:[UIColor colorWithRed:172/255.0 green:225/255.0 blue:175/255.0 alpha:1.0]]; // celadon
    
  UIButton *mainMenu = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenu setFrame:CGRectMake(10.0, 10.0, 100.0, 30.0)];
  [mainMenu setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenu addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  [[self view] addSubview:mainMenu];
  
  UIButton *nextPage = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [nextPage setFrame:CGRectMake(210.0, 440.0, 100.0, 30.0)];
  [nextPage setTitle:@"Next Page" forState:UIControlStateNormal];
  [nextPage addTarget:self action:@selector(displayNextPage:) forControlEvents:UIControlEventTouchDown];
  [[self view] addSubview:nextPage];
  
  UILabel *rules = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 40.0, 300.0, 420.0)];
  [rules setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [rules setFont:[UIFont boldSystemFontOfSize:15.0]];
  [rules setLineBreakMode:UILineBreakModeWordWrap];
  [rules setNumberOfLines:0];
  [rules setTextColor:[UIColor blackColor]];
  [rules setText:@"     Arithmedoku is a fun arithmetic and logic based puzzle game in which you fill an n×n grid of boxes with the digits 1 through n, abiding by a few simple rules:\n\n     • The digits cannot repeat in any row or column.\n     • The digits in each heavily outlined set of boxes (cages) must combine (in any order) using the mathematical operation indicated to form the target number shown in the top corner.\n     • Cages with only one box are just filled with the target number.\n     • A number can repeat within a cage as long as it is not in the same row or column."];
  [pages addObject:rules];
  
  UILabel *controls = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 40.0, 300.0, 420.0)];
  [controls setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [controls setFont:[UIFont boldSystemFontOfSize:15.0]];
  [controls setLineBreakMode:UILineBreakModeWordWrap];
  [controls setNumberOfLines:0];
  [controls setTextColor:[UIColor blackColor]];
  [controls setText:@"     To enter a digit simply touch a box, which starts it at 1, and slide your finger in any direction to increase or decrease the digit. Then, lift your finger to enter the digit shown.\n\n     You have the options of revealing the board or clearing the board at any time, although you will be presented with a confirmation window. To reveal an individual box, triple-tap it. To clear an individual box, double-tap it.\n\n     If you cannot finish your current game, just hit the home button to quit the app. Your board will automatically be saved. The next time you start Arithmedoku, your game will automatically load and display."];
  [pages addObject:controls];
  
  [self setCurrentPage:0];
  [[self view] addSubview:[pages objectAtIndex:currentPage]];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
}

// Displays the next page, wrapping around if the last page displayed.
- (IBAction)displayNextPage:(UIButton *)button {
  NSString *flipPageSoundPath = [[NSBundle mainBundle] pathForResource:@"crank" ofType:@"wav"];
  SystemSoundID flipPageSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:flipPageSoundPath], &flipPageSound);
  AudioServicesPlaySystemSound(flipPageSound);
  [flipPageSoundPath release];
  
  [[pages objectAtIndex:currentPage] removeFromSuperview];
  currentPage = currentPage+1 >= [pages count] ? 0 : currentPage+1;
  [[self view] addSubview:[pages objectAtIndex:currentPage]];
}

// Removes the the InstructionsViewController's view from its superview, thus returning to the main menu.
- (IBAction)returnToMainMenu:(UIButton *)button {
  NSString *closeWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"window-transition_close" ofType:@"wav"];
  SystemSoundID closeWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:closeWindowSoundPath], &closeWindowSound);
  AudioServicesPlaySystemSound(closeWindowSound);
  [closeWindowSoundPath release];
  
  [[self view] removeFromSuperview];
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
  [pages release];
}

@end