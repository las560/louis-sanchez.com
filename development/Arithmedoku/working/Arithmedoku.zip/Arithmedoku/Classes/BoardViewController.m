/**
 * BoardViewController.m
**/

#import "BoardViewController.h"

@implementation BoardViewController

@synthesize generators;
@synthesize boardSize;
@synthesize savedGameBoard;
@synthesize board;
@synthesize buttonsPortrait;
@synthesize buttonsLandscape;
@synthesize alertsPortrait;
@synthesize alertsLandscape;

// Returns the BoardViewController initialized with the given board size.
- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize {
  [super init];
  [self setGenerators:[[Generators alloc] init]];
  [self setBoardSize:aBoardSize];
  [self setSavedGameBoard:nil];
  [self setBoard:[generators generateBoardWithBoardSize:boardSize]];
  return self;
}

// Returns the BoardViewController initialized with the given saved game board.
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame {
  [super init];
  [self setGenerators:[[Generators alloc] init]];
  //[self setSavedGameBoard:[[UIView alloc] initWithFrame:CGRectMake(0.0, 80.0, 320.0, 320.0)]];
  [self setSavedGameBoard:[[UIView alloc] initWithFrame:CGRectMake(80.0, 80.0, 320.0, 320.0)]];
  [self setBoardSize:[[savedGame objectAtIndex:0] integerValue]];
  [self setBoard:[[NSMutableArray alloc] initWithObjects:nil]];
  [board addObject:[NSString stringWithFormat:@"%d", boardSize]];
  [savedGameBoard setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  
  for (NSInteger index = 1; index < boardSize*boardSize+1; index++) {
    NSArray *boxData = [NSArray arrayWithArray:[[savedGame objectAtIndex:index] componentsSeparatedByString:@" "]];
    NSInteger digit = [[boxData objectAtIndex:0] integerValue];
    NSInteger number = [[boxData objectAtIndex:1] integerValue];
    NSInteger targetNumber = [[boxData objectAtIndex:2] integerValue];
    NSInteger operation = [[boxData objectAtIndex:3] integerValue];
    Borders borders = BordersMake([[boxData objectAtIndex:4] boolValue], [[boxData objectAtIndex:5] boolValue], [[boxData objectAtIndex:6] boolValue], [[boxData objectAtIndex:7] boolValue]);
    BoxView *box = [[BoxView alloc] initForBoardSize:boardSize withIndex:(index-1) andDigit:digit andNumber:number andTargetNumber:targetNumber andOperation:operation andBorders:borders];
    [savedGameBoard addSubview:box];
    [board addObject:box];
  }
  return self;
}

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  
  [self setButtonsPortrait:[NSMutableArray arrayWithObjects:nil]];
  [self setButtonsLandscape:[NSMutableArray arrayWithObjects:nil]];
  [self setAlertsPortrait:[NSMutableArray arrayWithObjects:nil]];
  [self setAlertsLandscape:[NSMutableArray arrayWithObjects:nil]];
  
  [[self view] setFrame:CGRectMake(-80.0, 0.0, 480.0, 480.0)];
  [[self view] setBackgroundColor:[UIColor colorWithRed:150/255.0 green:120/255.0 blue:182/255.0 alpha:1.0]]; // lavender
  
  
  UIButton *mainMenu = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenu setFrame:CGRectMake(100.0, 20.0, 120.0, 40.0)];
  [mainMenu setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenu setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.0] forState:UIControlStateNormal];
  [mainMenu addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  UILabel *mainMenuTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 120.0, 40.0)];
  [mainMenuTitle setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [mainMenuTitle setFont:[UIFont boldSystemFontOfSize:14.0]];
  [mainMenuTitle setLineBreakMode:UILineBreakModeWordWrap];
  [mainMenuTitle setNumberOfLines:0];
  [mainMenuTitle setTextAlignment:UITextAlignmentCenter];
  [mainMenuTitle setTextColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  [mainMenuTitle setText:@"Main Menu"];
  
  NSData *mainMenuBuffer = [NSKeyedArchiver archivedDataWithRootObject:mainMenu];
  NSData *mainMenuTitleBuffer = [NSKeyedArchiver archivedDataWithRootObject:mainMenuTitle];
  
  UIButton *mainMenuLandscape = [NSKeyedUnarchiver unarchiveObjectWithData:mainMenuBuffer];
  [mainMenuLandscape setFrame:CGRectMake(10.0, 100.0, 60.0, 80.0)];
  UILabel *mainMenuLandscapeTitle = [[UIButton alloc] init];
  mainMenuLandscapeTitle = [NSKeyedUnarchiver unarchiveObjectWithData:mainMenuTitleBuffer];
  [mainMenuLandscapeTitle setFrame:CGRectMake(0.0, 0.0, 60.0, 80.0)];
  [mainMenuLandscape addSubview:mainMenuLandscapeTitle];
  [buttonsLandscape addObject:mainMenuLandscape];
  
  [mainMenu addSubview:mainMenuTitle];
  [buttonsPortrait addObject:mainMenu];
  
  
  UIButton *revealBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [revealBoard setFrame:CGRectMake(100.0, 420.0, 120.0, 40.0)];
  [revealBoard setTitle:@"Reveal Board" forState:UIControlStateNormal];
  [revealBoard setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.0] forState:UIControlStateNormal];
  [revealBoard addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  UILabel *revealBoardTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 120.0, 40.0)];
  [revealBoardTitle setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [revealBoardTitle setFont:[UIFont boldSystemFontOfSize:14.0]];
  [revealBoardTitle setLineBreakMode:UILineBreakModeWordWrap];
  [revealBoardTitle setNumberOfLines:0];
  [revealBoardTitle setTextAlignment:UITextAlignmentCenter];
  [revealBoardTitle setTextColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  [revealBoardTitle setText:@"Reveal Board"];
  
  NSData *revealBoardBuffer = [NSKeyedArchiver archivedDataWithRootObject:revealBoard];
  NSData *revealBoardTitleBuffer = [NSKeyedArchiver archivedDataWithRootObject:revealBoardTitle];
  
  UIButton *revealBoardLandscape = [NSKeyedUnarchiver unarchiveObjectWithData:revealBoardBuffer];
  [revealBoardLandscape setFrame:CGRectMake(10.0, 300.0, 60.0, 80.0)];
  UILabel *revealBoardLandscapeTitle = [NSKeyedUnarchiver unarchiveObjectWithData:revealBoardTitleBuffer];
  [revealBoardLandscapeTitle setFrame:CGRectMake(0.0, 0.0, 60.0, 80.0)];
  [revealBoardLandscape addSubview:revealBoardLandscapeTitle];
  [buttonsLandscape addObject:revealBoardLandscape];
  
  [revealBoard addSubview:revealBoardTitle];
  [buttonsPortrait addObject:revealBoard];
  
  
  UIButton *clearBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [clearBoard setFrame:CGRectMake(260.0, 20.0, 120.0, 40.0)];
  [clearBoard setTitle:@"Clear Board" forState:UIControlStateNormal];
  [clearBoard setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.0] forState:UIControlStateNormal];
  [clearBoard addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  UILabel *clearBoardTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 120.0, 40.0)];
  [clearBoardTitle setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [clearBoardTitle setFont:[UIFont boldSystemFontOfSize:14.0]];
  [clearBoardTitle setLineBreakMode:UILineBreakModeWordWrap];
  [clearBoardTitle setNumberOfLines:0];
  [clearBoardTitle setTextAlignment:UITextAlignmentCenter];
  [clearBoardTitle setTextColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  [clearBoardTitle setText:@"Clear Board"];
  
  NSData *clearBoardBuffer = [NSKeyedArchiver archivedDataWithRootObject:clearBoard];
  NSData *clearBoardTitleBuffer = [NSKeyedArchiver archivedDataWithRootObject:clearBoardTitle];
  
  UIButton *clearBoardLandscape = [NSKeyedUnarchiver unarchiveObjectWithData:clearBoardBuffer];
  [clearBoardLandscape setFrame:CGRectMake(410.0, 100.0, 60.0, 80.0)];
  UILabel *clearBoardLandscapeTitle = [NSKeyedUnarchiver unarchiveObjectWithData:clearBoardTitleBuffer];
  [clearBoardLandscapeTitle setFrame:CGRectMake(0.0, 0.0, 60.0, 80.0)];
  [clearBoardLandscape addSubview:clearBoardLandscapeTitle];
  [buttonsLandscape addObject:clearBoardLandscape];
  
  [clearBoard addSubview:clearBoardTitle];
  [buttonsPortrait addObject:clearBoard];
  
  
  for (NSInteger button = 0; button < [buttonsPortrait count]; button++) {
    [[self view] addSubview:[buttonsPortrait objectAtIndex:button]];
  }
  

  UIView *revealBoardAlert = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 480.0, 480.0)];
  [revealBoardAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]]; // vermillion
  
  UILabel *confirmReveal = [[UILabel alloc] initWithFrame:CGRectMake(90.0, 10.0, 300.0, 300.0)];
  [confirmReveal setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirmReveal setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirmReveal setLineBreakMode:UILineBreakModeWordWrap];
  [confirmReveal setNumberOfLines:4];
  [confirmReveal setTextAlignment:UITextAlignmentCenter];
  [confirmReveal setTextColor:[UIColor blackColor]];
  [confirmReveal setText:@"Are you sure you want to reveal the board?\n\nYou CANNOT undo this action!"];
  [revealBoardAlert addSubview:confirmReveal];
  
  UIButton *yesReveal = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yesReveal setFrame:CGRectMake(100.0, 240.0, 120.0, 40.0)];
  [yesReveal setTitle:@"YES" forState:UIControlStateNormal];
  [yesReveal addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [revealBoardAlert addSubview:yesReveal];
  
  UIButton *cancelReveal = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [cancelReveal setFrame:CGRectMake(260.0, 240.0, 120.0, 40.0)];
  [cancelReveal setTitle:@"CANCEL" forState:UIControlStateNormal];
  [cancelReveal addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [revealBoardAlert addSubview:cancelReveal];
  
  [alertsPortrait addObject:revealBoardAlert];
  
  
  UIView *clearBoardAlert = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 480.0, 480.0)];
  [clearBoardAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]]; // vermillion
  
  UILabel *confirmClear = [[UILabel alloc] initWithFrame:CGRectMake(90.0, 10.0, 300.0, 300.0)];
  [confirmClear setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirmClear setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirmClear setLineBreakMode:UILineBreakModeWordWrap];
  [confirmClear setNumberOfLines:4];
  [confirmClear setTextAlignment:UITextAlignmentCenter];
  [confirmClear setTextColor:[UIColor blackColor]];
  [confirmClear setText:@"Are you sure you want to clear the board?\n\nYou CANNOT undo this action!"];
  [clearBoardAlert addSubview:confirmClear];
  
  UIButton *yesClear = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yesClear setFrame:CGRectMake(100.0, 240.0, 120.0, 40.0)];
  [yesClear setTitle:@"YES" forState:UIControlStateNormal];
  [yesClear addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [clearBoardAlert addSubview:yesClear];
  
  UIButton *noClear = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [noClear setFrame:CGRectMake(260.0, 240.0, 120.0, 40.0)];
  [noClear setTitle:@"CANCEL" forState:UIControlStateNormal];
  [noClear addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [clearBoardAlert addSubview:noClear];
  
  [alertsPortrait addObject:clearBoardAlert];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
  
  [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRotate:) name:UIDeviceOrientationDidChangeNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveBoard:) name:UIApplicationWillTerminateNotification object:nil];
  
  if (savedGameBoard != nil) {
    [[self view] addSubview:savedGameBoard];
  }
  else {
    //UIView *aBoard = [[UIView alloc] initWithFrame:CGRectMake(0.0, 80.0, 320.0, 320.0)];
    UIView *aBoard = [[UIView alloc] initWithFrame:CGRectMake(80.0, 80.0, 320.0, 320.0)];
    
    for (NSInteger index = 1; index < boardSize*boardSize+1; index++) {
      NSInteger digit = 3;
      NSInteger number = 4;
      NSInteger targetNumber = 5;
      NSInteger operation = 1;
      Borders borders = BordersMake(YES, YES, YES, YES);
      BoxView *box = [[BoxView alloc] initForBoardSize:boardSize withIndex:(index-1) andDigit:digit andNumber:number andTargetNumber:targetNumber andOperation:operation andBorders:borders];
      [board addObject:box];
      [aBoard addSubview:box];
    }
    [[self view] addSubview:aBoard];
  }
}

//
- (void)checkBoard {
}

// Brings up an alert window regarding revealing the board. It waits for the user's input.
- (IBAction)revealBoard:(UIButton *)button {
  if ([button currentTitle] == @"Reveal Board") {
    NSString *alertSoundPath = [[NSBundle mainBundle] pathForResource:@"error-beep_deep" ofType:@"wav"];
    SystemSoundID alertSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:alertSoundPath], &alertSound);
    AudioServicesPlaySystemSound(alertSound);
    [alertSoundPath release];
    
    [[self view] addSubview:[alertsPortrait objectAtIndex:0]];
  }
  else if ([button currentTitle] == @"YES") {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_01" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    for (NSInteger index = 1; index < boardSize*boardSize+1; index++) {
      [[[board objectAtIndex:index] number] setText:[NSString stringWithFormat:@"%d", [[board objectAtIndex:index] digit]]];
    }
    
    [[alertsPortrait objectAtIndex:0] removeFromSuperview];
  }
  else {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_02" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    [[alertsPortrait objectAtIndex:0] removeFromSuperview];
  }
}

// Brings up an alert window regarding clearing the board. It waits for the user's input.
- (IBAction)clearBoard:(UIButton *)button {
  if ([button currentTitle] == @"Clear Board") {
    NSString *alertSoundPath = [[NSBundle mainBundle] pathForResource:@"error-beep_deep" ofType:@"wav"];
    SystemSoundID alertSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:alertSoundPath], &alertSound);
    AudioServicesPlaySystemSound(alertSound);
    [alertSoundPath release];
    
    [[self view] addSubview:[alertsPortrait objectAtIndex:1]];
  }
  else if ([button currentTitle] == @"YES") {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_01" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    for (NSInteger index = 1; index < boardSize*boardSize+1; index++) {
      [[[board objectAtIndex:index] number] setText:@""];
    }
    
    [[alertsPortrait objectAtIndex:1] removeFromSuperview];
  }
  else {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_02" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    [[alertsPortrait objectAtIndex:1] removeFromSuperview];
  }
}

// Removes the instructions view, thus returning to the main menu.
- (IBAction)returnToMainMenu:(UIButton *)button {
  NSString *closeWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"window-transition_close" ofType:@"wav"];
  SystemSoundID closeWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:closeWindowSoundPath], &closeWindowSound);
  AudioServicesPlaySystemSound(closeWindowSound);
  [closeWindowSoundPath release];
  
  [[self view] removeFromSuperview];
}

//
- (void)didRotate:(NSNotification *)notification {
  NSString *rotateWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"swish" ofType:@"wav"];
  SystemSoundID rotateWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:rotateWindowSoundPath], &rotateWindowSound);
  AudioServicesPlaySystemSound(rotateWindowSound);
  [rotateWindowSoundPath release];
  
  UIDeviceOrientation orientation = [[notification object] orientation];
  
  if (orientation == UIDeviceOrientationLandscapeLeft) {
    [[self view] setTransform:CGAffineTransformMakeRotation(M_PI / 2.0)];
    for (NSInteger buttons = 0; buttons < [buttonsPortrait count]; buttons++) {
      [[buttonsPortrait objectAtIndex:buttons] removeFromSuperview];
      [[self view] addSubview:[buttonsLandscape objectAtIndex:buttons]];
    }
  }
  else if (orientation == UIDeviceOrientationLandscapeRight) {
    [[self view] setTransform:CGAffineTransformMakeRotation(M_PI / -2.0)];
    for (NSInteger buttons = 0; buttons < [buttonsPortrait count]; buttons++) {
      [[buttonsPortrait objectAtIndex:buttons] removeFromSuperview];
      [[self view] addSubview:[buttonsLandscape objectAtIndex:buttons]];
    }
  }
  else if (orientation == UIDeviceOrientationPortraitUpsideDown) {
    [[self view] setTransform:CGAffineTransformMakeRotation(M_PI)];
    for (NSInteger buttons = 0; buttons < [buttonsLandscape count]; buttons++) {
      [[buttonsLandscape objectAtIndex:buttons] removeFromSuperview];
      [[self view] addSubview:[buttonsPortrait objectAtIndex:buttons]];
    }
  }
  else if (orientation == UIDeviceOrientationPortrait) {
    [[self view] setTransform:CGAffineTransformMakeRotation(0.0)];
    for (NSInteger buttons = 0; buttons < [buttonsLandscape count]; buttons++) {
      [[buttonsLandscape objectAtIndex:buttons] removeFromSuperview];
      [[self view] addSubview:[buttonsPortrait objectAtIndex:buttons]];
    }
  }
  
  /*
  // Rotates the view.
  CGAffineTransform transform = CGAffineTransformMakeRotation(3.14159/2);
  self.view.transform = transform;
  
  // Repositions and resizes the view.
  CGRect contentRect = CGRectMake(-80, 80, 480, 320);
  self.view.bounds = contentRect;
  */
}

// Saves the current board.
- (void)saveBoard:(NSNotification *)notification {
  NSString *savedGamePath = [[NSBundle mainBundle] pathForResource:@"SavedGame" ofType:@"txt"];
  NSString *boardData = [board componentsJoinedByString:@"\n"];
  [boardData writeToFile:savedGamePath atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
  [[NSNotificationCenter defaultCenter] removeObserver:self];
  [generators release];
  [savedGameBoard release];
  [board release];
  [buttonsPortrait release];
  [buttonsLandscape release];
  [alertsPortrait release];
  [alertsLandscape release];
}

@end
