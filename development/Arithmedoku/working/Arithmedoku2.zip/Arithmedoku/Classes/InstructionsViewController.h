/**
 * InstructionsViewController.h
**/

#import <AudioToolbox/AudioToolbox.h>
#import <UIKit/UIKit.h>

@interface InstructionsViewController : UIViewController {
  UILabel *rules;
  UILabel *instructions;
}

@property(nonatomic, retain) UILabel *rules;
@property(nonatomic, retain) UILabel *instructions;

- (IBAction)displayNextPage:(UIButton *)button;
- (IBAction)returnToMainMenu:(UIButton *)button;

@end