/**
 * Cage.h
**/

#import <Foundation/Foundation.h>

@interface Cage : NSObject {
  NSMutableArray *cage;
}

@property(nonatomic, retain) NSMutableArray *cage;

- (Cage *)initWithMembers:(NSMutableArray *)members;

@end