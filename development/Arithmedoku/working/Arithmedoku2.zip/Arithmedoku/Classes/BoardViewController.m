/**
 * BoardViewController.m
**/

#import "BoardViewController.h"

@implementation BoardViewController

@synthesize generators;
@synthesize boardSize;
@synthesize savedGameBoard;
@synthesize board;
@synthesize revealBoardAlert;
@synthesize clearBoardAlert;

// Returns the BoardViewController initialized with the given board size.
- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize {
  [super init];
  [self setGenerators:[[Generators alloc] init]];
  [self setBoardSize:aBoardSize];
  [self setSavedGameBoard:nil];
  //[self setBoard:[generators generateBoardWithBoardSize:boardSize]];
  [generators generateBoardWithBoardSize:boardSize];
  return self;
}

// Returns the BoardViewController initialized with the given saved game board.
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame {
  [super init];
  [self setGenerators:[[Generators alloc] init]];
  [self setSavedGameBoard:[[UIView alloc] initWithFrame:CGRectMake(0.0, 80.0, 320.0, 320.0)]];
  [self setBoardSize:[[savedGame objectAtIndex:0] integerValue]];
  [self setBoard:[[NSMutableArray alloc] initWithObjects:nil]];
  [board addObject:[NSString stringWithFormat:@"%d", boardSize]];
  [savedGameBoard setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  
  for (NSInteger index = 1; index < boardSize*boardSize+1; index++) {
    NSArray *boxData = [NSArray arrayWithArray:[[savedGame objectAtIndex:index] componentsSeparatedByString:@" "]];
    NSInteger digit = [[boxData objectAtIndex:0] integerValue];
    NSInteger number = [[boxData objectAtIndex:1] integerValue];
    NSInteger targetNumber = [[boxData objectAtIndex:2] integerValue];
    NSInteger operation = [[boxData objectAtIndex:3] integerValue];
    Borders borders = BordersMake([[boxData objectAtIndex:4] boolValue], [[boxData objectAtIndex:5] boolValue], [[boxData objectAtIndex:6] boolValue], [[boxData objectAtIndex:7] boolValue]);
    BoxView *box = [[BoxView alloc] initForBoardSize:boardSize withIndex:(index-1) andDigit:digit andNumber:number andTargetNumber:targetNumber andOperation:operation andBorders:borders];
    [savedGameBoard addSubview:box];
    [board addObject:box];
  }
  return self;
}

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  [[self view] setFrame:[[UIScreen mainScreen] applicationFrame]];
  [[self view] setBackgroundColor:[UIColor colorWithRed:150/255.0 green:120/255.0 blue:182/255.0 alpha:1.0]]; // lavender
  
  UIButton *mainMenu = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenu addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  [mainMenu setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenu setFrame:CGRectMake(20.0, 20.0, 120.0, 40.0)];
  [[self view] addSubview:mainMenu];
  
  UIButton *revealBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [revealBoard addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [revealBoard setTitle:@"Reveal Board" forState:UIControlStateNormal];
  [revealBoard setFrame:CGRectMake(20.0, 420.0, 120.0, 40.0)];
  [[self view] addSubview:revealBoard];
  
  UIButton *clearBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [clearBoard addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [clearBoard setTitle:@"Clear Board" forState:UIControlStateNormal];
  [clearBoard setFrame:CGRectMake(180.0, 20.0, 120.0, 40.0)];
  [[self view] addSubview:clearBoard];
  

  [self setRevealBoardAlert:[[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]]];
  [revealBoardAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]]; // vermillion
  
  UILabel *confirmReveal = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 10.0, 300.0, 300.0)];
  [confirmReveal setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirmReveal setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirmReveal setLineBreakMode:UILineBreakModeWordWrap];
  [confirmReveal setNumberOfLines:4];
  [confirmReveal setTextAlignment:UITextAlignmentCenter];
  [confirmReveal setTextColor:[UIColor blackColor]];
  [confirmReveal setText:@"Are you sure you want to reveal the board?\n\nYou CANNOT undo this action!"];
  [revealBoardAlert addSubview:confirmReveal];
  
  UIButton *yesReveal = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yesReveal addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [yesReveal setTitle:@"YES" forState:UIControlStateNormal];
  [yesReveal setFrame:CGRectMake(20.0, 240.0, 120.0, 40.0)];
  [revealBoardAlert addSubview:yesReveal];
  
  UIButton *cancelReveal = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [cancelReveal addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [cancelReveal setTitle:@"CANCEL" forState:UIControlStateNormal];
  [cancelReveal setFrame:CGRectMake(180.0, 240.0, 120.0, 40.0)];
  [revealBoardAlert addSubview:cancelReveal];
  
  
  [self setClearBoardAlert:[[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]]];
  [clearBoardAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]]; // vermillion
  
  UILabel *confirmClear = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 10.0, 300.0, 300.0)];
  [confirmClear setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirmClear setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirmClear setLineBreakMode:UILineBreakModeWordWrap];
  [confirmClear setNumberOfLines:4];
  [confirmClear setTextAlignment:UITextAlignmentCenter];
  [confirmClear setTextColor:[UIColor blackColor]];
  [confirmClear setText:@"Are you sure you want to clear the board?\n\nYou CANNOT undo this action!"];
  [clearBoardAlert addSubview:confirmClear];
  
  UIButton *yesClear = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yesClear addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [yesClear setTitle:@"YES" forState:UIControlStateNormal];
  [yesClear setFrame:CGRectMake(20.0, 240.0, 120.0, 40.0)];
  [clearBoardAlert addSubview:yesClear];
  
  UIButton *noClear = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [noClear addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [noClear setTitle:@"CANCEL" forState:UIControlStateNormal];
  [noClear setFrame:CGRectMake(180.0, 240.0, 120.0, 40.0)];
  [clearBoardAlert addSubview:noClear];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
  
  NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter addObserver:self selector:@selector(saveBoard:) name:UIApplicationWillTerminateNotification object:nil];
  
  if (savedGameBoard != nil) {
    [[self view] addSubview:savedGameBoard];
  }
  else {
    for (NSInteger index = 1; index < boardSize*boardSize+1; index++) {
      [[self view] addSubview:[board objectAtIndex:index]];
    }
  }
}

//
- (void)checkBoard {
}

// Brings up an alert window regarding revealing the board. It waits for the user's input.
- (IBAction)revealBoard:(UIButton *)button {
  if ([button currentTitle] == @"Reveal Board") {
    NSString *alertSoundPath = [[NSBundle mainBundle] pathForResource:@"error-beep_deep" ofType:@"wav"];
    SystemSoundID alertSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:alertSoundPath], &alertSound);
    AudioServicesPlaySystemSound(alertSound);
    [alertSoundPath release];
    
    [[self view] addSubview:revealBoardAlert];
  }
  else if ([button currentTitle] == @"YES") {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_01" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    for (NSInteger index = 1; index < boardSize*boardSize+1; index++) {
      [[[board objectAtIndex:index] number] setText:[NSString stringWithFormat:@"%d", [[board objectAtIndex:index] digit]]];
    }
    [revealBoardAlert removeFromSuperview];
  }
  else {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_02" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    [revealBoardAlert removeFromSuperview];
  }
}

// Brings up an alert window regarding clearing the board. It waits for the user's input.
- (IBAction)clearBoard:(UIButton *)button {
  if ([button currentTitle] == @"Clear Board") {
    NSString *alertSoundPath = [[NSBundle mainBundle] pathForResource:@"error-beep_deep" ofType:@"wav"];
    SystemSoundID alertSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:alertSoundPath], &alertSound);
    AudioServicesPlaySystemSound(alertSound);
    [alertSoundPath release];
    
    [[self view] addSubview:clearBoardAlert];
  }
  else if ([button currentTitle] == @"YES") {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_01" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    for (NSInteger index = 1; index < boardSize*boardSize+1; index++) {
      [[[board objectAtIndex:index] number] setText:@""];
    }
    [clearBoardAlert removeFromSuperview];
  }
  else {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_02" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    [clearBoardAlert removeFromSuperview];
  }
}

// Removes the instructions view, thus returning to the main menu.
- (IBAction)returnToMainMenu:(UIButton *)button {
  NSString *closeWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"window-transition_close" ofType:@"wav"];
  SystemSoundID closeWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:closeWindowSoundPath], &closeWindowSound);
  AudioServicesPlaySystemSound(closeWindowSound);
  [closeWindowSoundPath release];
  
  [[self view] removeFromSuperview];
}

// Saves the current board.
- (void)saveBoard:(NSNotification *)notification {
  NSString *savedGamePath = [[NSBundle mainBundle] pathForResource:@"SavedGame" ofType:@"txt"];
  NSString *boardData = [board componentsJoinedByString:@"\n"];
  [boardData writeToFile:savedGamePath atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
  [[NSNotificationCenter defaultCenter] removeObserver:self];
  [generators release];
  [savedGameBoard release];
  [board release];
  [revealBoardAlert release];
  [clearBoardAlert release];
}

@end
