//
//  untitled.m
//  Arithmedoku
//
//  Created by scholar on 5/7/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "untitled.h"


@implementation untitled

@end
