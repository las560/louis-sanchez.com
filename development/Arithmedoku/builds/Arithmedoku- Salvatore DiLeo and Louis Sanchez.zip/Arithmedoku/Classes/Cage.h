/**
 * Cage.h
**/

#import <Foundation/Foundation.h>

@interface Cage : NSObject {
  NSMutableArray *cages;
  NSMutableArray *allBoxes;
  NSMutableArray *array;
  NSMutableArray *cage_group;
	
  BOOL foundNeighbor;
  BOOL left_right;
}

@property(nonatomic) BOOL foundNeighbor;
@property(nonatomic) BOOL left_right;
@property (nonatomic, retain) NSMutableArray *cages;
@property (nonatomic, retain) NSMutableArray *allBoxes;
@property (nonatomic, retain) NSMutableArray *array;

int convertIndexes(int index, int size);
void printNumbers(int a[], int size);
- (void) initWithSize: (NSInteger) generatorBoardSize;
- (void) createBoardSimulatorForSize: (NSInteger) n withBordersSetTo: (NSNumber*) zero andInsideSetTo: (NSNumber*) one;
- (void) createHorizontalGroupOfTwoWithIndex: (NSInteger)index andSize: (NSInteger)n andNeighbor: (NSInteger)k andSetTo: (NSNumber*) zero;
- (void) createVerticalGroupOfTwoWithIndex: (NSInteger)index andSize: (NSInteger)n andNeighbor: (NSInteger)k andSetTo: (NSNumber*) zero;
- (void) createOutsideHorizontalGroupOfThreeWithIndex: (NSInteger)index andPureIndex: (NSInteger)pure_index2 andPureIndex: (NSInteger)pure_index3 andRealIndex: (NSInteger)real_index2 andRealIndex: (NSInteger)real_index3 andSize: (NSInteger)n andSetTo: (NSNumber*) zero;
- (void) createOutsideLType1GroupOfThreeWithIndex: (NSInteger)index andPureIndex: (NSInteger)pure_index2 andPureIndex: (NSInteger)pure_index3 andRealIndex: (NSInteger)real_index2 andRealIndex: (NSInteger)real_index3 andSize: (NSInteger)n andSetTo: (NSNumber*) zero;
- (void) createInsideHorizontalGroupOfThreeWithIndex: (NSInteger)index andPureIndex: (NSInteger)pure_index2 andPureIndex: (NSInteger)pure_index3 andRealIndex: (NSInteger)real_index2 andRealIndex:(NSInteger)real_index3 andSize: (NSInteger)n andNeighbor: (NSInteger)k andSetTo: (NSNumber*) zero;
- (void) createOutsideLType2GroupOfThreeWithIndex: (NSInteger)index andPureIndex: (NSInteger)pure_index2 andPureIndex: (NSInteger)pure_index3 andRealIndex: (NSInteger)real_index2 andRealIndex: (NSInteger)real_index3 andSize: (NSInteger)n andSetTo: (NSNumber*) zero;
- (void) createOutsideVerticalGroupOfThreeWithIndex: (NSInteger)index andPureIndex: (NSInteger)pure_index2 andPureIndex: (NSInteger)pure_index3 andRealIndex: (NSInteger)real_index2 andRealIndex: (NSInteger)real_index3 andSize: (NSInteger)n andSetTo: (NSNumber*) zero;
- (void) createInsideLOrInsideVerticalGroupOfThreeOfType: (BOOL)left_right withIndex: (NSInteger)index andPureIndex: (NSInteger)pure_index2 andPureIndex: (NSInteger)pure_index3 andRealIndex: (NSInteger)real_index2 andRealIndex: (NSInteger)real_index3 andSize: (NSInteger)n andSetTo: (NSNumber*) zero;
- (void) printCage;
- (void) printArray: (NSInteger) size;
- (NSMutableArray*) create_Groupings_For_Cages_With_BoardSize: (int) size;

@end