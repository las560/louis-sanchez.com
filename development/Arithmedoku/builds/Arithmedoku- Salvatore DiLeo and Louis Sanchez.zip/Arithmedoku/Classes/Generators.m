/**
 * Generators.m
**/

#import "Generators.h"

@implementation Generators

//
- (NSMutableArray *)generateBoardWithBoardSize:(NSInteger)boardSize {
  NSMutableArray *grid = [self generateGridWithBoardSize:boardSize];
  return [self generateCagesWithGrid:grid withBoardSize:boardSize];
}

//
- (NSMutableArray *)generateGridWithBoardSize:(NSInteger)boardSize {
  NSMutableArray *digits = [NSMutableArray arrayWithObjects:nil];
  NSMutableArray *shifts = [NSMutableArray arrayWithObjects:nil];
  for (NSInteger digit = 1; digit <= boardSize; digit++) {
    [digits addObject:[NSNumber numberWithInteger:digit]];
    [shifts addObject:[NSNumber numberWithInteger:digit]];
  }
  [shifts removeLastObject];
  
  NSMutableArray *row = [NSMutableArray arrayWithObjects:nil];
  for (NSInteger index = 0; index < boardSize; index++) {
    NSInteger digit = arc4random()%[digits count];
    [row addObject:[digits objectAtIndex:digit]];
    [digits removeObjectAtIndex:digit];
  }
  
  NSMutableArray *grid = [NSMutableArray arrayWithObjects:nil];
  [grid addObjectsFromArray:row];
  for (NSInteger shift = 0; shift < boardSize-1; shift++) {
    NSMutableArray *shiftedRow = [NSMutableArray arrayWithArray:row];
    NSInteger times = arc4random()%[shifts count];
    [grid addObjectsFromArray:[self rotateArray:shiftedRow thisManyTimes:[[shifts objectAtIndex:times] integerValue]]];
    [shifts removeObjectAtIndex:times];
  }
  return grid;
}

//
- (NSMutableArray *)generateCagesWithGrid:(NSMutableArray *)grid withBoardSize:(NSInteger)boardSize {
  NSMutableArray *board = [[NSMutableArray alloc] initWithObjects:nil];
  
  Cage *cage = [Cage new];
  [cage initWithSize: boardSize+2];
  
  [cage create_Groupings_For_Cages_With_BoardSize:boardSize+2];  
  
  BOOL north, south, east, west;
  int holder;
  for (NSInteger index = 0; index < pow((double)boardSize, 2.0); index++) {
    north = YES; south = YES; east = YES; west = YES;
    NSArray *arr;
    for (int i = 0; i < [[cage cages] count]; i++) {
      NSArray *arr2 = [[cage cages] objectAtIndex:i];
      for (int j = 0; j < [arr2 count]; j++) {
        if ([[arr2 objectAtIndex:j] integerValue] == index) {
          arr = [NSArray arrayWithArray:arr2];
          holder = j;
        }
      }
    }
    
    if ([arr containsObject:[NSNumber numberWithInteger:index-boardSize]]) {
      north = NO;
    }
    if ([arr containsObject:[NSNumber numberWithInteger:index+boardSize]]) {
      south = NO;
    }
    if ([arr containsObject:[NSNumber numberWithInteger:index+1]]) {
      east = NO;
    }
    if ([arr containsObject:[NSNumber numberWithInteger:index-1]]) {
      west = NO;
    }
    
    BoxView *box;
    NSInteger op;
    NSInteger first;
    NSInteger second;
    NSInteger third;
    NSInteger targetNum;
    // test for first member in the cage
    if ([[arr objectAtIndex: holder] isEqualTo: [arr objectAtIndex: 0]]) {
      //printf("%i is equal to %i\n", [[arr objectAtIndex: holder] integerValue], [[arr objectAtIndex: 0] integerValue]);
      // generate target number and operator	
      if ([arr count] == 1) {
        box = [[BoxView alloc] initForBoardSize:boardSize withIndex:index andDigit:[[grid objectAtIndex:index] integerValue] andNumber:NOTHING andTargetNumber:[[grid objectAtIndex: [[arr objectAtIndex: 0] integerValue]] integerValue] andOperation:NOTHING andBorders:BordersMake(north, south, east, west) andViewController:nil];
      }
      else if ([arr count] == 2) {	
        // can generate addition/subtraction/multiplication/division
        op = (arc4random() % 4) + 1;
        first = [[grid objectAtIndex: [[arr objectAtIndex: 0] integerValue]] integerValue]; 
        second = [[grid objectAtIndex: [[arr objectAtIndex: 1] integerValue]] integerValue];
        
        //printf("op = %i\n", op);
        //printf("first = %i\n", first);
        //printf("second = %i\n", second);
        if (op == 1)
          targetNum = first + second;		
        else if (op == 2) {
          if (first > second)
            targetNum = first - second;
          else
            targetNum = second - first;
        }
        else if (op == 3) 
          targetNum = first * second;		
        else if (op == 4) {
          // test if division is possible.  sometimes it might not be
          if (first % second == 0) {
            targetNum = first / second;
            //printf("%i \% %i = %i\n", first, second, (first%second));
            //printf("%i / %i = %i\n", first, second, targetNum);
          }
          else if (second % first == 0) {
            targetNum = second / first;
            //printf("%i \% %i = %i\n", second, first, (second%first));
            //printf("%i / %i = %i\n", second, first, targetNum);
          }
          // division is not possible: redo algorithm excluding division
          else {
            op = (arc4random() % 3) + 1;
            //printf("second op = %i\n", op);
            if (op == 1)
              targetNum = first + second;			
            else if (op == 2) {
              if (first > second)
                targetNum = first - second;
              else
                targetNum = second - first;
            }
            else if (op == 3)
              targetNum = first * second;	
          }
        }
        box = [[BoxView alloc] initForBoardSize:boardSize withIndex:index andDigit:[[grid objectAtIndex:index] integerValue] andNumber:NOTHING andTargetNumber:targetNum andOperation:op andBorders:BordersMake(north, south, east, west) andViewController:nil];
      }
      else if ([arr count] == 3) {
        // can only generate addition and multiplication
        op = (arc4random() % 2);
        if (op == 0)
          op = 1;			// additiion
        else if (op == 1)	// multiplication
          op = 3;
        if (op == 1) {
          first = [[grid objectAtIndex: [[arr objectAtIndex: 0] integerValue]] integerValue]; 
          second = [[grid objectAtIndex: [[arr objectAtIndex: 1] integerValue]] integerValue];
          third = [[grid objectAtIndex: [[arr objectAtIndex: 2] integerValue]] integerValue];
          targetNum = first + second + third;		
        }
        else if (op == 3) {
          first = [[grid objectAtIndex: [[arr objectAtIndex: 0] integerValue]] integerValue]; 
          second = [[grid objectAtIndex: [[arr objectAtIndex: 1] integerValue]] integerValue];
          third = [[grid objectAtIndex: [[arr objectAtIndex: 2] integerValue]] integerValue];
          targetNum = first * second * third;		
        }
        box = [[BoxView alloc] initForBoardSize:boardSize withIndex:index andDigit:[[grid objectAtIndex:index] integerValue] andNumber:NOTHING andTargetNumber:targetNum andOperation:op andBorders:BordersMake(north, south, east, west) andViewController:nil];
      }
    }
    else {
      box = [[BoxView alloc] initForBoardSize:boardSize withIndex:index andDigit:[[grid objectAtIndex:index] integerValue] andNumber:NOTHING andTargetNumber:NOTHING andOperation:0 andBorders:BordersMake(north, south, east, west) andViewController:nil];
    }
    
    [board addObject:box];
    
  }
  
  
  return board;
}

//
- (NSMutableArray *)rotateArray:(NSMutableArray *)array thisManyTimes:(NSInteger)times {
  if (times < 0) {
    for (NSInteger count = 0; count < times; count++) {
      [array insertObject:[array lastObject] atIndex:0];
      [array removeLastObject];
    }
  }
  else if (times > 0) {
    for (NSInteger count = 0; count < times; count++) {
      [array addObject:[array objectAtIndex:0]];
      [array removeObjectAtIndex:0];
    }
  }
  return array;
}

@end