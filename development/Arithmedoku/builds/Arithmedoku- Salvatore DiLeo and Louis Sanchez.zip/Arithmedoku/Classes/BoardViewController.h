/**
 * BoardViewController.h
**/

#import <QuartzCore/QuartzCore.h>
#import "Generators.h"

@interface BoardViewController : UIViewController {
  UIView *savedGameBoard;
  Generators *generators;
  NSInteger boardSize;
  NSMutableArray *board;
  NSMutableArray *buttonsPortrait;
  NSMutableArray *buttonsLandscape;
  NSMutableArray *alertsPortrait;
  NSMutableArray *alertsLandscape;
}

@property(nonatomic, retain) UIView *savedGameBoard;
@property(nonatomic, retain) Generators *generators;
@property(nonatomic) NSInteger boardSize;
@property(nonatomic, retain) NSMutableArray *board;
@property(nonatomic, retain) NSMutableArray *buttonsPortrait;
@property(nonatomic, retain) NSMutableArray *buttonsLandscape;
@property(nonatomic, retain) NSMutableArray *alertsPortrait;
@property(nonatomic, retain) NSMutableArray *alertsLandscape;

- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize;
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame;
- (IBAction)revealBoard:(UIButton *)button;
- (IBAction)clearBoard:(UIButton *)button;
- (IBAction)returnToMainMenu:(UIButton *)button;
- (void)checkForViolations:(NSInteger)index;
- (void)timerFireMethod:(NSTimer *)theTimer;
- (void)checkForCompletion;
- (void)didRotate:(NSNotification *)notification;
- (void)saveBoard:(NSNotification *)notification;

@end