/**
 * BoardViewController.m
**/

#import "BoardViewController.h"

@implementation BoardViewController

@synthesize savedGameBoard;
@synthesize generators;
@synthesize boardSize;
@synthesize board;
@synthesize buttonsPortrait;
@synthesize buttonsLandscape;
@synthesize alertsPortrait;
@synthesize alertsLandscape;

// Returns the BoardViewController initialized with the given board size.
- (BoardViewController *)initWithBoardSize:(NSInteger)aBoardSize {
  [super init];
  
  [self setSavedGameBoard:nil];
  [self setGenerators:[[Generators alloc] init]];
  [self setBoardSize:aBoardSize];
  [self setBoard:[generators generateBoardWithBoardSize:boardSize]];
  for (NSInteger index = 0; index < boardSize*boardSize; index++) {
    [[board objectAtIndex:index] setViewController:self];
  }
  
  return self;
}

// Returns the BoardViewController initialized with the given saved game board.
- (BoardViewController *)initWithSavedGame:(NSArray *)savedGame {
  [super init];
    
  [self setSavedGameBoard:[[UIView alloc] initWithFrame:CGRectMake(80.0, 80.0, 320.0, 320.0)]];
  [self setBoardSize:[[savedGame objectAtIndex:0] integerValue]];
  [self setBoard:[[NSMutableArray alloc] initWithObjects:nil]];
  [savedGameBoard setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  
  for (NSInteger index = 1; index <= boardSize*boardSize; index++) {
    NSArray *boxData = [NSArray arrayWithArray:[[savedGame objectAtIndex:index] componentsSeparatedByString:@" "]];
    NSInteger digit = [[boxData objectAtIndex:0] integerValue];
    NSInteger number = [[boxData objectAtIndex:1] integerValue];
    NSInteger targetNumber = [[boxData objectAtIndex:2] integerValue];
    NSInteger operation = [[boxData objectAtIndex:3] integerValue];
    Borders borders = BordersMake([[boxData objectAtIndex:4] boolValue], [[boxData objectAtIndex:5] boolValue], [[boxData objectAtIndex:6] boolValue], [[boxData objectAtIndex:7] boolValue]);
    BoxView *box = [[BoxView alloc] initForBoardSize:boardSize withIndex:(index-1) andDigit:digit andNumber:number andTargetNumber:targetNumber andOperation:operation andBorders:borders andViewController:self];
    [board addObject:box];
    [savedGameBoard addSubview:box];
  }
  
  return self;
}

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  
  [self setButtonsPortrait:[NSMutableArray arrayWithObjects:nil]];
  [self setButtonsLandscape:[NSMutableArray arrayWithObjects:nil]];
  [self setAlertsPortrait:[NSMutableArray arrayWithObjects:nil]];
  [self setAlertsLandscape:[NSMutableArray arrayWithObjects:nil]];
  
  [[self view] setFrame:CGRectMake(-80.0, 0.0, 480.0, 480.0)];
  [[self view] setBackgroundColor:[UIColor colorWithRed:150/255.0 green:120/255.0 blue:182/255.0 alpha:1.0]]; // lavender
  
  UIButton *mainMenu = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenu setFrame:CGRectMake(100.0, 20.0, 120.0, 40.0)];
  [mainMenu setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenu setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.0] forState:UIControlStateNormal];
  [mainMenu addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  UILabel *mainMenuTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 120.0, 40.0)];
  [mainMenuTitle setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [mainMenuTitle setFont:[UIFont boldSystemFontOfSize:14.0]];
  [mainMenuTitle setLineBreakMode:UILineBreakModeWordWrap];
  [mainMenuTitle setNumberOfLines:0];
  [mainMenuTitle setTextAlignment:UITextAlignmentCenter];
  [mainMenuTitle setTextColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  [mainMenuTitle setText:@"Main Menu"];
  [mainMenu addSubview:mainMenuTitle];
  [buttonsPortrait addObject:mainMenu];

  UIButton *mainMenuLandscape = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [mainMenuLandscape setFrame:CGRectMake(10.0, 100.0, 60.0, 80.0)];
  [mainMenuLandscape setTitle:@"Main Menu" forState:UIControlStateNormal];
  [mainMenuLandscape setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.0] forState:UIControlStateNormal];
  [mainMenuLandscape addTarget:self action:@selector(returnToMainMenu:) forControlEvents:UIControlEventTouchDown];
  UILabel *mainMenuLandscapeTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 60.0, 80.0)];
  [mainMenuLandscapeTitle setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [mainMenuLandscapeTitle setFont:[UIFont boldSystemFontOfSize:14.0]];
  [mainMenuLandscapeTitle setLineBreakMode:UILineBreakModeWordWrap];
  [mainMenuLandscapeTitle setNumberOfLines:0];
  [mainMenuLandscapeTitle setTextAlignment:UITextAlignmentCenter];
  [mainMenuLandscapeTitle setTextColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  [mainMenuLandscapeTitle setText:@"Main Menu"];
  [mainMenuLandscape addSubview:mainMenuLandscapeTitle];
  [buttonsLandscape addObject:mainMenuLandscape];
  
  UIButton *revealBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [revealBoard setFrame:CGRectMake(100.0, 420.0, 120.0, 40.0)];
  [revealBoard setTitle:@"Reveal Board" forState:UIControlStateNormal];
  [revealBoard setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.0] forState:UIControlStateNormal];
  [revealBoard addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  UILabel *revealBoardTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 120.0, 40.0)];
  [revealBoardTitle setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [revealBoardTitle setFont:[UIFont boldSystemFontOfSize:14.0]];
  [revealBoardTitle setLineBreakMode:UILineBreakModeWordWrap];
  [revealBoardTitle setNumberOfLines:0];
  [revealBoardTitle setTextAlignment:UITextAlignmentCenter];
  [revealBoardTitle setTextColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  [revealBoardTitle setText:@"Reveal Board"];
  [revealBoard addSubview:revealBoardTitle];
  [buttonsPortrait addObject:revealBoard];
  
  UIButton *revealBoardLandscape = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [revealBoardLandscape setFrame:CGRectMake(10.0, 300.0, 60.0, 80.0)];
  [revealBoardLandscape setTitle:@"Reveal Board" forState:UIControlStateNormal];
  [revealBoardLandscape setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.0] forState:UIControlStateNormal];
  [revealBoardLandscape addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  UILabel *revealBoardLandscapeTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 60.0, 80.0)];
  [revealBoardLandscapeTitle setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [revealBoardLandscapeTitle setFont:[UIFont boldSystemFontOfSize:14.0]];
  [revealBoardLandscapeTitle setLineBreakMode:UILineBreakModeWordWrap];
  [revealBoardLandscapeTitle setNumberOfLines:0];
  [revealBoardLandscapeTitle setTextAlignment:UITextAlignmentCenter];
  [revealBoardLandscapeTitle setTextColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  [revealBoardLandscapeTitle setText:@"Reveal Board"];
  [revealBoardLandscape addSubview:revealBoardLandscapeTitle];
  [buttonsLandscape addObject:revealBoardLandscape];
  
  UIButton *clearBoard = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [clearBoard setFrame:CGRectMake(260.0, 20.0, 120.0, 40.0)];
  [clearBoard setTitle:@"Clear Board" forState:UIControlStateNormal];
  [clearBoard setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.0] forState:UIControlStateNormal];
  [clearBoard addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  UILabel *clearBoardTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 120.0, 40.0)];
  [clearBoardTitle setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [clearBoardTitle setFont:[UIFont boldSystemFontOfSize:14.0]];
  [clearBoardTitle setLineBreakMode:UILineBreakModeWordWrap];
  [clearBoardTitle setNumberOfLines:0];
  [clearBoardTitle setTextAlignment:UITextAlignmentCenter];
  [clearBoardTitle setTextColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  [clearBoardTitle setText:@"Clear Board"];
  [clearBoard addSubview:clearBoardTitle];
  [buttonsPortrait addObject:clearBoard];
  
  UIButton *clearBoardLandscape = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [clearBoardLandscape setFrame:CGRectMake(410.0, 100.0, 60.0, 80.0)];
  [clearBoardLandscape setTitle:@"Clear Board" forState:UIControlStateNormal];
  [clearBoardLandscape setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.0] forState:UIControlStateNormal];
  [clearBoardLandscape addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  UILabel *clearBoardLandscapeTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 60.0, 80.0)];
  [clearBoardLandscapeTitle setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [clearBoardLandscapeTitle setFont:[UIFont boldSystemFontOfSize:14.0]];
  [clearBoardLandscapeTitle setLineBreakMode:UILineBreakModeWordWrap];
  [clearBoardLandscapeTitle setNumberOfLines:0];
  [clearBoardLandscapeTitle setTextAlignment:UITextAlignmentCenter];
  [clearBoardLandscapeTitle setTextColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  [clearBoardLandscapeTitle setText:@"Clear Board"];
  [clearBoardLandscape addSubview:clearBoardLandscapeTitle];
  [buttonsLandscape addObject:clearBoardLandscape];
  
  for (NSInteger button = 0; button < [buttonsPortrait count]; button++) {
    [[self view] addSubview:[buttonsPortrait objectAtIndex:button]];
  }
  
  UIView *revealBoardAlert = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 480.0, 480.0)];
  [revealBoardAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]]; // vermillion
  UILabel *confirmReveal = [[UILabel alloc] initWithFrame:CGRectMake(90.0, 10.0, 300.0, 300.0)];
  [confirmReveal setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirmReveal setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirmReveal setLineBreakMode:UILineBreakModeWordWrap];
  [confirmReveal setNumberOfLines:4];
  [confirmReveal setTextAlignment:UITextAlignmentCenter];
  [confirmReveal setTextColor:[UIColor blackColor]];
  [confirmReveal setText:@"Are you sure you want to reveal the board?\n\nYou CANNOT undo this action!"];
  [revealBoardAlert addSubview:confirmReveal];
  UIButton *yesReveal = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yesReveal setFrame:CGRectMake(100.0, 240.0, 120.0, 40.0)];
  [yesReveal setTitle:@"YES" forState:UIControlStateNormal];
  [yesReveal addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [revealBoardAlert addSubview:yesReveal];
  UIButton *cancelReveal = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [cancelReveal setFrame:CGRectMake(260.0, 240.0, 120.0, 40.0)];
  [cancelReveal setTitle:@"CANCEL" forState:UIControlStateNormal];
  [cancelReveal addTarget:self action:@selector(revealBoard:) forControlEvents:UIControlEventTouchDown];
  [revealBoardAlert addSubview:cancelReveal];
  [alertsPortrait addObject:revealBoardAlert];
  
  UIView *clearBoardAlert = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 480.0, 480.0)];
  [clearBoardAlert setBackgroundColor:[UIColor colorWithRed:244/255.0 green:196/255.0 blue:48/255.0 alpha:1.0]]; // vermillion
  UILabel *confirmClear = [[UILabel alloc] initWithFrame:CGRectMake(90.0, 10.0, 300.0, 300.0)];
  [confirmClear setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [confirmClear setFont:[UIFont boldSystemFontOfSize:20.0]];
  [confirmClear setLineBreakMode:UILineBreakModeWordWrap];
  [confirmClear setNumberOfLines:4];
  [confirmClear setTextAlignment:UITextAlignmentCenter];
  [confirmClear setTextColor:[UIColor blackColor]];
  [confirmClear setText:@"Are you sure you want to clear the board?\n\nYou CANNOT undo this action!"];
  [clearBoardAlert addSubview:confirmClear];
  UIButton *yesClear = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [yesClear setFrame:CGRectMake(100.0, 240.0, 120.0, 40.0)];
  [yesClear setTitle:@"YES" forState:UIControlStateNormal];
  [yesClear addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [clearBoardAlert addSubview:yesClear];
  UIButton *noClear = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [noClear setFrame:CGRectMake(260.0, 240.0, 120.0, 40.0)];
  [noClear setTitle:@"CANCEL" forState:UIControlStateNormal];
  [noClear addTarget:self action:@selector(clearBoard:) forControlEvents:UIControlEventTouchDown];
  [clearBoardAlert addSubview:noClear];
  [alertsPortrait addObject:clearBoardAlert];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
  
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRotate:) name:UIDeviceOrientationDidChangeNotification object:[UIDevice currentDevice]];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveBoard:) name:UIApplicationWillTerminateNotification object:nil];
  
  if ([[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeLeft || [[UIDevice currentDevice] orientation] == UIDeviceOrientationLandscapeRight) {
    [self didRotate:[NSNotification notificationWithName:UIDeviceOrientationDidChangeNotification object:[UIDevice currentDevice]]];    
  }
  
  if (savedGameBoard != nil) {
    [[self view] addSubview:savedGameBoard];
  }
  else {
    UIView *aBoard = [[UIView alloc] initWithFrame:CGRectMake(80.0, 80.0, 320.0, 320.0)];
    for (NSInteger index = 0; index < boardSize*boardSize; index++) {
      [aBoard addSubview:[board objectAtIndex:index]];
    }
    [[self view] addSubview:aBoard];
  }
}

// Brings up an alert window regarding revealing the board. It waits for the user's input.
- (IBAction)revealBoard:(UIButton *)button {
  if ([button currentTitle] == @"Reveal Board") {
    NSString *alertSoundPath = [[NSBundle mainBundle] pathForResource:@"error-beep_deep" ofType:@"wav"];
    SystemSoundID alertSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:alertSoundPath], &alertSound);
    AudioServicesPlaySystemSound(alertSound);
    [alertSoundPath release];
    
    [[self view] addSubview:[alertsPortrait objectAtIndex:0]];
  }
  else if ([button currentTitle] == @"YES") {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_01" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    for (NSInteger index = 0; index < boardSize*boardSize; index++) {
      [[[board objectAtIndex:index] number] setText:[NSString stringWithFormat:@"%d", [[board objectAtIndex:index] digit]]];
    }
    
    [[alertsPortrait objectAtIndex:0] removeFromSuperview];
  }
  else {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_02" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    [[alertsPortrait objectAtIndex:0] removeFromSuperview];
  }
}

// Brings up an alert window regarding clearing the board. It waits for the user's input.
- (IBAction)clearBoard:(UIButton *)button {
  if ([button currentTitle] == @"Clear Board") {
    NSString *alertSoundPath = [[NSBundle mainBundle] pathForResource:@"error-beep_deep" ofType:@"wav"];
    SystemSoundID alertSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:alertSoundPath], &alertSound);
    AudioServicesPlaySystemSound(alertSound);
    [alertSoundPath release];
    
    [[self view] addSubview:[alertsPortrait objectAtIndex:1]];
  }
  else if ([button currentTitle] == @"YES") {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_01" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    for (NSInteger index = 0; index < boardSize*boardSize; index++) {
      [[[board objectAtIndex:index] number] setText:@""];
    }
    
    [[alertsPortrait objectAtIndex:1] removeFromSuperview];
  }
  else {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_02" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
    
    [[alertsPortrait objectAtIndex:1] removeFromSuperview];
  }
}

// Removes the BoardViewController's view, thus returning to the main menu.
- (IBAction)returnToMainMenu:(UIButton *)button {
  NSString *closeWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"window-transition_close" ofType:@"wav"];
  SystemSoundID closeWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:closeWindowSoundPath], &closeWindowSound);
  AudioServicesPlaySystemSound(closeWindowSound);
  [closeWindowSoundPath release];
  
  [[self view] removeFromSuperview];
}

// Warns the user if his last entered number violates one of the game's basic rules.
- (void)checkForViolations:(NSInteger)index {
  BOOL violation = NO;
  NSInteger offender;
  
  for (NSInteger neighbor = (index%boardSize)+1; neighbor < boardSize; neighbor++) {
    if ([[[[board objectAtIndex:neighbor+(boardSize*(index/boardSize))] number] text] integerValue] == [[[[board objectAtIndex:index] number] text] integerValue]) {
      violation = YES;
      offender = neighbor+(boardSize*(index/boardSize));
    }
  }
  for (NSInteger neighbor = (index%boardSize)-1; neighbor >= 0; neighbor--) {
    if ([[[[board objectAtIndex:neighbor+(boardSize*(index/boardSize))] number] text] integerValue] == [[[[board objectAtIndex:index] number] text] integerValue]) {
      violation = YES;
      offender = neighbor+(boardSize*(index/boardSize));
    }
  }
  for (NSInteger neighbor = index-boardSize; neighbor >= 0; neighbor -= boardSize) {
    if ([[[[board objectAtIndex:neighbor] number] text] integerValue] == [[[[board objectAtIndex:index] number] text] integerValue]) {
      violation = YES;
      offender = neighbor;
    }
  }
  for (NSInteger neighbor = index+boardSize; neighbor < boardSize*boardSize; neighbor += boardSize) {
    if ([[[[board objectAtIndex:neighbor] number] text] integerValue] == [[[[board objectAtIndex:index] number] text] integerValue]) {
      violation = YES;
      offender = neighbor;
    }
  }
  
  if (violation) {
    NSString *violationSoundPath = [[NSBundle mainBundle] pathForResource:@"error-beep_light" ofType:@"wav"];
    SystemSoundID violationSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:violationSoundPath], &violationSound);
    AudioServicesPlaySystemSound(violationSound);
    [violationSoundPath release];
    
    UIView *flash = [[UIView alloc] initWithFrame:[[self view] frame]];
    [flash setBackgroundColor:[UIColor colorWithRed:227/255.0 green:66/255.0 blue:52/255.0 alpha:1.0]]; // vermillion
    [[self view] addSubview:flash];
        
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(timerFireMethod:) userInfo:nil repeats:YES];
    [timer setFireDate:[NSDate dateWithTimeIntervalSinceNow:0.1]];
  }
}

// Timer fire method.
- (void)timerFireMethod:(NSTimer *)theTimer {
  [[[[self view] subviews] lastObject] removeFromSuperview];
  [theTimer invalidate];
}

// Checks to see if the user solved the board.
- (void)checkForCompletion {
	BOOL flag = YES;
	for (NSInteger index = 0; index < boardSize*boardSize; index++) {
		if ([[[[board objectAtIndex:index] number] text] integerValue] != [[board objectAtIndex:index] digit]) {
			flag = NO;
		}
	}
	if (flag) {
		NSString *victorySoundPath = [[NSBundle mainBundle] pathForResource:@"applause_light" ofType:@"wav"];
		SystemSoundID victorySound;
		AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:victorySoundPath], &victorySound);
		AudioServicesPlaySystemSound(victorySound);
		[victorySoundPath release];
	}
}

// Properly adapts the view to the new orientation.
- (void)didRotate:(NSNotification *)notification {
  NSString *rotateWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"swish" ofType:@"wav"];
  SystemSoundID rotateWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:rotateWindowSoundPath], &rotateWindowSound);
  AudioServicesPlaySystemSound(rotateWindowSound);
  [rotateWindowSoundPath release];
  
  UIDeviceOrientation orientation = [[notification object] orientation];
  
  if (orientation == UIDeviceOrientationLandscapeLeft) {
    [[self view] setTransform:CGAffineTransformMakeRotation(M_PI / 2.0)];
    for (NSInteger button = 0; button < [buttonsPortrait count]; button++) {
      [[buttonsPortrait objectAtIndex:button] removeFromSuperview];
      [[self view] addSubview:[buttonsLandscape objectAtIndex:button]];
    }
    for (NSInteger alert = 0; alert < [alertsPortrait count]; alert++) {
      if ([[alertsPortrait objectAtIndex:alert] superview] != nil) {
        [[self view] bringSubviewToFront:[alertsPortrait objectAtIndex:alert]];
      }
    }
  }
  else if (orientation == UIDeviceOrientationLandscapeRight) {
    [[self view] setTransform:CGAffineTransformMakeRotation(M_PI / -2.0)];
    for (NSInteger button = 0; button < [buttonsPortrait count]; button++) {
      [[buttonsPortrait objectAtIndex:button] removeFromSuperview];
      [[self view] addSubview:[buttonsLandscape objectAtIndex:button]];
    }
    for (NSInteger alert = 0; alert < [alertsPortrait count]; alert++) {
      if ([[alertsPortrait objectAtIndex:alert] superview] != nil) {
        [[self view] bringSubviewToFront:[alertsPortrait objectAtIndex:alert]];
      }
    }
  }
  else if (orientation == UIDeviceOrientationPortraitUpsideDown) {
    [[self view] setTransform:CGAffineTransformMakeRotation(M_PI)];
    for (NSInteger button = 0; button < [buttonsLandscape count]; button++) {
      [[buttonsLandscape objectAtIndex:button] removeFromSuperview];
      [[self view] addSubview:[buttonsPortrait objectAtIndex:button]];
    }
    for (NSInteger alert = 0; alert < [alertsPortrait count]; alert++) {
      if ([[alertsPortrait objectAtIndex:alert] superview] != nil) {
        [[self view] bringSubviewToFront:[alertsPortrait objectAtIndex:alert]];
      }
    }
  }
  else if (orientation == UIDeviceOrientationPortrait) {
    [[self view] setTransform:CGAffineTransformMakeRotation(0.0)];
    for (NSInteger button = 0; button < [buttonsLandscape count]; button++) {
      [[buttonsLandscape objectAtIndex:button] removeFromSuperview];
      [[self view] addSubview:[buttonsPortrait objectAtIndex:button]];
    }
    for (NSInteger alert = 0; alert < [alertsPortrait count]; alert++) {
      if ([[alertsPortrait objectAtIndex:alert] superview] != nil) {
        [[self view] bringSubviewToFront:[alertsPortrait objectAtIndex:alert]];
      }
    }
  }
}

// Saves the current board.
- (void)saveBoard:(NSNotification *)notification {
  NSString *savedGamePath = [[NSBundle mainBundle] pathForResource:@"SavedGame" ofType:@"txt"];
  NSString *boardData = [board componentsJoinedByString:@"\n"];
  NSString *savedGameData = [NSString stringWithFormat:@"%d\n%@", boardSize, boardData];
  [savedGameData writeToFile:savedGamePath atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [super dealloc];
  [[NSNotificationCenter defaultCenter] removeObserver:self name:UIDeviceOrientationDidChangeNotification object:[UIDevice currentDevice]];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillTerminateNotification object:nil];
  [savedGameBoard release];
  [generators release];
  [board release];
  [buttonsPortrait release];
  [buttonsLandscape release];
  [alertsPortrait release];
  [alertsLandscape release];
}

@end