/**
 * InstructionsViewController.h
**/

#import <AudioToolbox/AudioToolbox.h>

@interface InstructionsViewController : UIViewController {
  NSMutableArray *pages;
  NSInteger currentPage;
}

@property(nonatomic, retain) NSMutableArray *pages;
@property(nonatomic) NSInteger currentPage;

- (IBAction)displayNextPage:(UIButton *)button;
- (IBAction)returnToMainMenu:(UIButton *)button;

@end