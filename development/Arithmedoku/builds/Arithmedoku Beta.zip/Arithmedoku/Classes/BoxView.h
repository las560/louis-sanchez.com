/**
 * BoxView.h
**/

#import <AudioToolbox/AudioToolbox.h>
#import <math.h>
#import <UIKit/UIKit.h>
@class BoardViewController;

#define NOTHING 0
#define ADDITION 1
#define SUBTRACTION 2
#define MULTIPLICATION 3
#define DIVISION 4

struct Borders {
  BOOL north;
  BOOL south;
  BOOL east;
  BOOL west;
};
typedef struct Borders Borders;

@interface BoxView : UIView {
  NSInteger boardSize;
  NSInteger index;
  NSInteger digit;
  UILabel *number;
  NSInteger targetNumber;
  NSInteger operation;
  Borders borders;
  BoardViewController *viewController;
  CGPoint touchOrigin;
}

@property(nonatomic) NSInteger boardSize;
@property(nonatomic) NSInteger index;
@property(nonatomic) NSInteger digit;
@property(nonatomic, retain) IBOutlet UILabel *number;
@property(nonatomic) NSInteger targetNumber;
@property(nonatomic) NSInteger operation;
@property(nonatomic) Borders borders;
@property(nonatomic, retain) BoardViewController *viewController;
@property(nonatomic) CGPoint touchOrigin;

- (BoxView *)initForBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex andDigit:(NSInteger)aDigit andNumber:(NSInteger)aNumber andTargetNumber:(NSInteger)aTargetNumber andOperation:(NSInteger)anOperation andBorders:(Borders)someBorders andViewController:(BoardViewController *)aViewController;
- (CGRect)getBoxFrameForBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex;
- (UILabel *)getLabelForNumber:(NSInteger)aNumber forBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex;
- (UILabel *)getLabelForTargetNumber:(NSInteger)aTargetNumber andOperation:(NSInteger)anOperation forBoardSize:(NSInteger)aBoardSize withIndex:(NSInteger)anIndex;
- (UIImage *)scaleImage:(UIImage *)image toSize:(CGSize)size;
- (void)changeNumberTo:(NSInteger)aNumber;
- (double)displacementFromTouchOrigin:(CGPoint)point;
Borders BordersMake(BOOL north, BOOL south, BOOL east, BOOL west);

@end