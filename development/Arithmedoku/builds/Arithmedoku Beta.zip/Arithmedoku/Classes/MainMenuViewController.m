/**
 * MainMenuViewController.m
**/

#import "MainMenuViewController.h"

@implementation MainMenuViewController

@synthesize boardSizes;

// Creates the view that the controller manages.
- (void)loadView {
  [super loadView];
  
  [[self view] setFrame:[[UIScreen mainScreen] applicationFrame]];
  [[self view] setBackgroundColor:[UIColor colorWithRed:0/255.0 green:123/255.0 blue:167/255.0 alpha:1.0]]; // cerulean
  
  UIImageView *logo = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, 320.0, 320.0)];
  [logo setImage:[UIImage imageNamed:@"logo_medium.png"]];
  [[self view] addSubview:logo];
  
  UILabel *authors = [[UILabel alloc] initWithFrame:CGRectMake(60.0, 330.0, 200.0, 60.0)];
  [authors setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [authors setFont:[UIFont boldSystemFontOfSize:24.0]];
  [authors setLineBreakMode:UILineBreakModeWordWrap];
  [authors setNumberOfLines:2];
  [authors setTextAlignment:UITextAlignmentCenter];
  [authors setTextColor:[UIColor whiteColor]];
  [authors setText:@"Salvatore DiLeo Louis Sanchez"];
  [[self view] addSubview:authors];
  
  UIButton *about = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [about setFrame:CGRectMake(5.0, 400.0, 100.0, 30.0)];
  [about setTitle:@"About" forState:UIControlStateNormal];
  [about addTarget:self action:@selector(about:) forControlEvents:UIControlEventTouchDown];
  [[self view] addSubview:about];
  
  UIButton *viewInstructions = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [viewInstructions setFrame:CGRectMake(110.0, 400.0, 100.0, 30.0)];
  [viewInstructions setTitle:@"Instructions" forState:UIControlStateNormal];
  [viewInstructions addTarget:self action:@selector(viewInstructions:) forControlEvents:UIControlEventTouchDown];
  [[self view] addSubview:viewInstructions];
  
  UIButton *playGame = [UIButton buttonWithType:UIButtonTypeRoundedRect];
  [playGame setFrame:CGRectMake(215.0, 400.0, 100.0, 30.0)];
  [playGame setTitle:@"Play Game" forState:UIControlStateNormal];
  [playGame addTarget:self action:@selector(playGame:) forControlEvents:UIControlEventTouchDown];
  [[self view] addSubview:playGame];
  
  [self setBoardSizes:[[UIView alloc] initWithFrame:CGRectMake(15.0, 440.0, 290.0, 30.0)]];
  [boardSizes setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  
  UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 80.0, 30.0)];
  [label setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.0]];
  [label setFont:[UIFont boldSystemFontOfSize:14.0]];
  [label setLineBreakMode:UILineBreakModeClip];
  [label setText:@"Board size:"];
  [label setTextColor:[UIColor whiteColor]];
  [boardSizes addSubview:label];
  
  for (NSInteger boardSize = 4; boardSize <= 9; boardSize++) {
    UIButton *size = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [size setFrame:CGRectMake(85.0+((boardSize-4)*35.0), 0.0, 30.0, 30.0)];
    [size setTitle:[NSString stringWithFormat:@"%d×%d", boardSize, boardSize] forState:UIControlStateNormal];
    [size addTarget:self action:@selector(playGame:) forControlEvents:UIControlEventTouchDown];
    [boardSizes addSubview:size];
  }
  
  [boardSizes setHidden:YES];
  [[self view] addSubview:boardSizes];
}

// Called after the controller’s view is loaded into memory.
- (void)viewDidLoad {
  [super viewDidLoad];
  
  NSString *savedGamePath = [[NSBundle mainBundle] pathForResource:@"SavedGame" ofType:@"txt"];
  NSString *savedGameData = [NSString stringWithContentsOfFile:savedGamePath];
  NSArray *savedGame = [NSArray arrayWithArray:[savedGameData componentsSeparatedByString:@"\n"]];
  NSInteger boardSize = [[savedGame objectAtIndex:0] integerValue];
  
  if (boardSize != 0) {
    BoardViewController *board = [[BoardViewController alloc] initWithSavedGame:savedGame];
    [[self view] addSubview:[board view]];
  }
}

// Displays the "About" window.
- (IBAction)about:(UIButton *)button {
  NSString *openWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"window-transition_open" ofType:@"wav"];
  SystemSoundID openWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:openWindowSoundPath], &openWindowSound);
  AudioServicesPlaySystemSound(openWindowSound);
  [openWindowSoundPath release];
  
  [boardSizes setHidden:YES];
  AboutViewController *about = [[AboutViewController alloc] init];
  [[self view] addSubview:[about view]];
}

// Displays the game's instructions.
- (IBAction)viewInstructions:(UIButton *)button {
  NSString *openWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"window-transition_open" ofType:@"wav"];
  SystemSoundID openWindowSound;
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:openWindowSoundPath], &openWindowSound);
  AudioServicesPlaySystemSound(openWindowSound);
  [openWindowSoundPath release];
  
  [boardSizes setHidden:YES];
  InstructionsViewController *instructions = [[InstructionsViewController alloc] init];
  [[self view] addSubview:[instructions view]];
}

// Reveals the possible selections for the board size.
- (IBAction)playGame:(UIButton *)button {
  if ([button currentTitle] == @"Play Game") {
    NSString *buttonSoundPath = [[NSBundle mainBundle] pathForResource:@"soft-tap_01" ofType:@"wav"];
    SystemSoundID buttonSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:buttonSoundPath], &buttonSound);
    AudioServicesPlaySystemSound(buttonSound);
    [buttonSoundPath release];
  
    [boardSizes setHidden:NO];
  }
  else {
    NSString *openWindowSoundPath = [[NSBundle mainBundle] pathForResource:@"window-transition_open" ofType:@"wav"];
    SystemSoundID openWindowSound;
    AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:openWindowSoundPath], &openWindowSound);
    AudioServicesPlaySystemSound(openWindowSound);
    [openWindowSoundPath release];
    
    [boardSizes setHidden:YES];
    NSInteger boardSize = [[[button currentTitle] substringToIndex:1] integerValue];
    BoardViewController *board = [[BoardViewController alloc] initWithBoardSize:boardSize];
    [[self view] addSubview:[board view]];
    NSLog(@"MAIN MENU BOARD: %d", [board retainCount]);
  }
}

// Sent to the view controller when the application receives a memory warning.
- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
  // Release anything that's not essential, such as cached data.
}

// Deallocates the memory occupied by the receiver.
- (void)dealloc {
  [boardSizes release];
  [super dealloc];
}

@end